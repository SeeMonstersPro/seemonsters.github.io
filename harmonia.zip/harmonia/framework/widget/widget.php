<?php


	require_once('flickr.php');
	require_once('recentpost.php');






