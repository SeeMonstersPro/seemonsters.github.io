<?php get_header(); ?>    
    <main id="main" class="site-main">

        <?php if(have_posts()):
            while ( have_posts() ) : the_post();

                $vc = get_post_meta(get_the_ID(), '_wpb_vc_js_status', true);
                if($vc == true){
                    get_template_part( 'template-parts/content', 'studio' );
                }else{
                    echo '<div class="container page-without-vc">';
                        get_template_part( 'template-parts/content', 'studio' );
                    echo '</div>';
                }

            endwhile;
        else :
            echo '<div class="container">';
                get_template_part( 'template-parts/content', 'none' );
            echo '</div>';
        endif;
        ?>

    </main>

<?php
get_footer();
