<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package filmic
 */

$fw_page_layout = ( function_exists('fw_ext_sidebars_get_current_position') ) ? fw_ext_sidebars_get_current_position() : 'right';

$class = $full_layout = '';
$col = 'col-lg-9';

if($fw_page_layout == null){
    $fw_page_layout = 'right';
}

if($fw_page_layout == 'left'){
    $class = 'blog-sidebar-left';
}

if($fw_page_layout == 'full' || !is_active_sidebar( 'sidebar-blog' )){
    $col = 'col-lg-12';
    $class = 'blog-no-sidebar';
}

get_header(); ?>

	<div class="container">	
		<div class="row <?php echo esc_attr($class); ?>">
			<section id="primary" class="content-area <?php echo esc_attr($col); ?>">
				<main id="main" class="site-main">

				<?php while ( have_posts() ) : the_post();

					get_template_part( 'template-parts/content', 'single' );

					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;

				endwhile; ?>

				</main>
			</section>

            <?php /*sidebar*/ ?>
            <?php
				// Sidebar.
				filmic_get_sidebar( 'sidebar-blog', $fw_page_layout );
			?>
		</div>
	</div>

<?php get_footer();
