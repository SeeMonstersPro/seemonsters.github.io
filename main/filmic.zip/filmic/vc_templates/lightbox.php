<?php
  $atts = vc_map_get_attributes( $this->getShortcode(), $atts );
  extract( $atts );
  
  $class_to_filter = vc_shortcode_custom_css_class( $inline_css, ' ' ) . $this->getExtraClass( $class );

  $all_class = apply_filters( 
    VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
    $class_to_filter,
    $this->settings['base'], $atts
  );

  $img = wp_get_attachment_image_src($atts['img'], 'full');
  $image_alt = filmic_img_alt( $atts['img'], esc_html__( 'Video thumbnail', 'filmic' ) );

  wp_enqueue_style( 'filmic-lity-css', get_template_directory_uri() . '/css/lity.min.css', false );
  wp_enqueue_script( 'filmic-lity-js', get_template_directory_uri() . '/js/lity.min.js', array('jquery'), '1.0', true );
?> 

<div class="sc-lightbox <?php echo esc_attr($all_class); ?>">
  <?php if ( $img ) : ?>
  <img src="<?php echo esc_url( $img[0] );  ?>" alt="<?php echo esc_attr( $image_alt ); ?>">
  <?php endif; ?>

  <div class="sc-lightbox__content">
  <?php if ( $title ) : ?>
    <h1 class="sc-lightbox__title t-small t-uppercase"><?php echo esc_html($title); ?></h1>
  <?php endif; ?>  

  <?php if ( $subtitle ) : ?>
    <h2 class="sc-lightbox__subtitle"><?php echo esc_html($subtitle); ?></h2>
  <?php endif; ?>  

    <a href="<?php echo esc_url( $video_url ); ?>" class="sc-lightbox__link" data-lity>
      <span class="<?php echo esc_attr( $font_icon ); ?> sc-lightbox__icon"></span>
    </a>
  </div><!-- .sc-lightbox__content -->  
</div>