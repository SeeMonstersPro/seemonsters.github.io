<?php
  $atts = vc_map_get_attributes( $this->getShortcode(), $atts );
  extract( $atts );
  
  $class_to_filter = vc_shortcode_custom_css_class( $inline_css, ' ' ) . $this->getExtraClass( $class );
  $all_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->settings['base'], $atts );

  $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

  $args = array(
    'ignore_sticky_posts' => 1,
    'orderby' => $orderby,
    'order' => $order,
    'posts_per_page' => $posts,
    'paged' => $paged
  );

  $column = $style != 'list' ? 'sc-blog-col-' . $columns : '';
  $entry_flex = $thumbnail == 'left' ? 'entry-flex' : '';
  $entry_time_secondary = $style == 'custom' ? 'entry-time--secondary' : '';
  $the_query = new WP_Query( $args );

  

  if ( $the_query->have_posts() ) :
    echo '<div class="sc-blog-' . esc_attr( $style ) . ' ' . esc_attr( $column ) . '' . esc_attr( $all_class ) . '">';
    while ( $the_query->have_posts() ) :
      $the_query->the_post();
?>
  <div class="entry-single">
    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
      <div class="entry-primary <?php echo esc_attr( $entry_flex ); ?>">
        
        <?php if ( has_post_thumbnail() ) : ?>
        <div class="entry-thumbnail">
          <a href="<?php the_permalink(); ?>">
            <?php the_post_thumbnail(); ?>
          </a>
          <?php if ( $thumbnail == 'left' ) : ?>
          <a class="entry-time entry-time--secondary entry-time--absolute" href="<?php the_permalink(); ?>">
            <span class="entry-date"><?php echo get_the_date('d'); ?></span>
            <span class="entry-month t-small t-uppercase"><?php echo get_the_date('M'); ?></span>
          </a><!-- entry-time -->
          <?php endif; ?>
        </div><!-- .entry-thumbnail -->
        <?php endif; ?>

        <div class="entry-container">
        <?php if ( $thumbnail == 'top' ) : ?>
          <a class="entry-time <?php echo esc_attr( $entry_time_secondary ); ?>" href="<?php the_permalink(); ?>">
            <span class="entry-date"><?php echo get_the_date('d'); ?></span>
            <span class="entry-month t-small t-uppercase"><?php echo get_the_date('M'); ?></span>
          </a><!-- .entry-time -->
        <?php endif; ?>

          <div class="entry-wrapper">
            <header class="entry-header">
              <div class="entry-categories t-small">
                <?php the_category( ', ' ) ?>
              </div><!-- .entry-categories -->
              <?php
                the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
              ?>
            </header><!-- .entry-header -->

          <?php if ( $style !== 'grid' ) : ?>
            <div class="entry-excerpt">
              <?php echo wp_trim_words( get_the_content(), 18 ); ?>
            </div>
          <?php 
            else:
              filmic_grid_excerpt();
            endif; 
          ?>

          </div><!-- .entry-wrapper -->
        </div><!-- .entry-container -->
      </div><!-- .entry-primary -->
    </article>
  </div><!-- .entry-single -->
<?php
  endwhile;
  if ( $pagination == 'yes' ) :
    filmic_paging( $the_query );
  endif;
    
  echo '</div>';

  else: 
    get_template_part( 'template-parts/content', 'none' ); 
  endif;
  wp_reset_postdata();
?>