<?php
// @codingStandardsIgnoreStart
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$class_to_filter = vc_shortcode_custom_css_class( $inline_css, ' ' ) . $this->getExtraClass( $class );

$all_class = apply_filters(
    VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
    $class_to_filter,
    $this->settings['base'],
    $atts
);

/**/
if( empty( $total ) ) return;
$total = ( int ) $total;

if ( get_query_var( 'paged' ) ) {
    $paged = get_query_var( 'paged' );
}elseif ( get_query_var( 'page' ) ) {
    $paged = get_query_var( 'page' );
}else {
    $paged = 1;
}

$args = array(
	'post_type'           => 'ht-project',
	'post_status'         => 'publish',
	'ignore_sticky_posts' => 1,
	'posts_per_page'      => -1,
	'orderby'             => $orderby,
	'order'               => $order,   
	'paged'               => $paged
);

/*post data - convert to array*/
$data_post = explode( ', ', $data_post );
$data_cat = explode( ', ', $data_cat );

if( 'cat' == $source  && ! empty( $data_cat[0] ) ) {/*query post by category slug*/
    $args['tax_query'] = array(
        array(
            'taxonomy' => 'ht-project-category',
            'field' => 'slug',
            'terms' => $data_cat
        )
    );
    $args['posts_per_page'] = $total;
}elseif( 'post' == $source && ! empty( $data_post[0] ) ) {/*query post by slug*/
    $args['post_name__in'] = $data_post;
}elseif( empty( $data_cat[0] ) && empty( $data_post[0] ) ) {
    $args['posts_per_page'] = $total;
}

wp_enqueue_style( 'filmic-lity-css', get_template_directory_uri() . '/css/lity.min.css' );
wp_enqueue_script( 'filmic-lity-js', get_template_directory_uri() . '/js/lity.min.js', array( 'jquery' ), false, true );

$query = new WP_Query( $args );

$column = 'zigzag' != $style ? 'sc-project-col-' . $column : '';/*column*/
$style = 'project-' . $style;/*style*/

if( 'project-grid-nogap' == $style && 'yes' == $overlay )
    $style = 'project-grid-nogap with-overlay';

/*FOR CAROUSEL STYLE*/

$id = uniqid( 'id-' );
$slick_data = '';

if( 'project-carousel' == $style ):

    wp_enqueue_style(
        'filmic-slick-css',
        get_template_directory_uri() . '/css/slick.css',
        false
    );
    wp_enqueue_style(
        'filmic-slick-theme-css',
        get_template_directory_uri() . '/css/slick-theme.css',
        false
    );
    wp_enqueue_script(
        'filmic-slick-js',
        get_template_directory_uri() . '/js/slick.min.js',
        array('jquery'),
        null,
        true
    );

    /*slick init*/
    wp_add_inline_script(
        'filmic-slick-js',
        "jQuery('#{$id}').slick();",
        'after'
    );

    /*slick options*/
    $arrows = 'yes' == $arrows ? true : false;
    $dots = 'yes' == $dots ? true : false;

    $options = array(
        "slidesToShow" => 1,
        "slidesToScroll" => 1,
        "infinite" => false,
        "arrows" => $arrows,
        "dots" => $dots,
        "adaptiveHeight" => true
    );

    /*slick-data*/
    $slick_data = "data-slick='" . json_encode( $options ) . "'";
endif;

/*//FOR CAROUSEL STYLE*/

if( $query->have_posts() ):

    echo '<div id="'. esc_attr( $id ) .'" class="sc-project '. esc_attr( $style . ' ' . $column . ' ' . $all_class ) . '" '. $slick_data .'>';

        while( $query->have_posts() ):
            $query->the_post();
            $trailer = function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( get_the_ID(), 'trailer') : ''; 
            $description = function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( get_the_ID(), 'description' ) : '';

            if( 'project-carousel' == $style ){
                $btn_link = function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( get_the_ID(), 'btn_link', '#') : '#';
                $btn_label = function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( get_the_ID(), 'btn_label') : '';
                $info = function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( get_the_ID(), 'infomation') : '';
            }

            ?>
             
            <div class="sc-project-item">

                <div class="project-head">
                    <a href="<?php the_permalink(); ?>">
                        <?php the_post_thumbnail( 'full'); ?>
                    </a>
                    <?php if( ! empty( $trailer ) ) { ?>
                        <a class="project-trailer-btn" data-lity href="<?php echo esc_url( $trailer ); ?>"><?php esc_html_e( 'Watch Trailer', 'filmic' ); ?></a>
                    <?php } ?>
                </div>

                <div class="project-sum">
                    <?php echo get_the_term_list( get_the_ID(), 'ht-project-category', '<span class="sc-project-cat">', ', ', '</span>' ); ?>
                    <h3 class="sc-project-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <?php
                        if( 'project-carousel' == $style && ! empty( $info ) ){
                            echo '<dl class="project-carousel-info">';
                                foreach( $info as $key ){
                                    echo '<dt>';
                                        echo esc_html( $key['pro_name'] );
                                    echo '</dt>';
                                    echo '<dd>';
                                        echo esc_html( $key['pro_value'] );
                                    echo '</dd>';
                                }
                            echo '</dl>';
                        }

                        if( 'project-zigzag' == $style || 'project-carousel' == $style ){
                            echo '<p>' . $description . '</p>';
                        }

                        if( 'project-grid' != $style ){
                            echo '<a class="project-nogap-arrow" href="'. get_the_permalink() .'"></a>';
                        }

                        if( 'project-grid-nogap with-overlay' == $style ){
                            echo '<a class="project-permalink" href="'. get_the_permalink() .'"></a>';
                        }

                        /*CAROUSEL STYLE*/
                        if( ! empty( $trailer ) ) {
                            echo '<a class="project-trailer-normal-btn" data-lity href="'. esc_url( $trailer ) .'">'. esc_html__( 'Watch Trailer', 'filmic' ) .'</a>';
                        }

                        if( 'project-carousel' == $style && ( ! empty( $btn_link ) && ! empty( $btn_label ) ) ):
                            echo '<a class="project-buy-btn" href="'. esc_url( $btn_link ) .'">'. esc_html( $btn_label ) .'</a>';
                        endif;
                    ?>
                </div>
            </div>

        <?php
        endwhile;
        wp_reset_postdata();

    echo '</div>';

endif;