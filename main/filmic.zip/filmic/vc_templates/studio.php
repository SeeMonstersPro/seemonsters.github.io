<?php
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$class_to_filter = vc_shortcode_custom_css_class( $inline_css, ' ' ) . $this->getExtraClass( $class );

$all_class = apply_filters(
    VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
    $class_to_filter,
    $this->settings['base'], $atts
);

/**/
if(empty($total)) return;
$total = (int) $total;

$gap = (int) $gap;

if ( get_query_var('paged') ) {
    $paged = get_query_var('paged');
}elseif ( get_query_var('page') ){
    $paged = get_query_var('page');
}else {
    $paged = 1;
}

$args = array(
    'post_type' => 'ht-studio',
    'post_status' => 'publish',
    'ignore_sticky_posts' => 1,        
    'orderby' => $orderby,
    'order' => $order,   
    'paged' => $paged,
    'posts_per_page' => $total
);

$query = new WP_Query($args);

if($query->have_posts()){
    echo '<div class="sc-studio swiper-container">';
        echo '<div class="swiper-wrapper">';
            while($query->have_posts()){
                $query->the_post();
                echo '<div class="studio-item swiper-slide">';
                    echo '<a href="'. get_permalink() .'">' . get_the_post_thumbnail(get_the_ID(), 'full' ) . '</a>';
                    echo '<h4><a href="'. get_permalink() .'">' . get_the_title() . '</a></h4>';
                    if ( has_excerpt() ) the_excerpt();
                echo '</div>';
            }
        echo '</div>';
        echo '<div class="swiper-scrollbar swiper-scrollbar"></div>';
        wp_reset_postdata();
    echo '</div>';
}

wp_enqueue_script( 'filmic-swiper', get_template_directory_uri() . '/js/swiper.min.js', array('jquery'), false, true );
wp_enqueue_style( 'filmic-swiper-style', get_template_directory_uri() . '/css/swiper.min.css');
wp_add_inline_script(
    'filmic-swiper',
    "var swiper = new Swiper('.swiper-container', {
        slidesPerView: {$column},
        watchSlidesVisibility: true,
        spaceBetween: {$gap},
        scrollbar: {
            el: '.swiper-scrollbar',
            draggable: true
        },
        breakpoints: {
            767: {
                slidesPerView: 1
            },
            991: {
                slidesPerView: 2
            }
        }
    });",
    $position = 'after' );
?>