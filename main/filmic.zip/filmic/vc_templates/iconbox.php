<?php
   $atts = vc_map_get_attributes( $this->getShortcode(), $atts );
   extract( $atts );
   
   $class_to_filter = vc_shortcode_custom_css_class( $inline_css, ' ' ) . $this->getExtraClass( $class );
 
   $all_class = apply_filters( 
     VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
     $class_to_filter,
     $this->settings['base'], $atts
   );

   $link = vc_build_link( $link );
   $img = wp_get_attachment_image_src($atts['use_image'], 'full');
   $image_alt = filmic_img_alt( $atts['use_image'], esc_html__( 'Image Icon', 'filmic' ) );
?>

<div class="sc-iconbox">
  <div class="sc-iconbox__icon">
    <?php if ( $icon_type == 'icon_font' ) : ?>

    <span class="<?php echo esc_attr( $use_icon ); ?>" style="font-size: <?php echo esc_attr( $icon_font_size ); ?>px; color: <?php echo esc_attr( $icon_font_color ); ?>"></span>

    <?php else : ?>

    <img src="<?php echo esc_url( $img[0] ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>">

    <?php endif; ?>
  </div>

  <h3 class="sc-iconbox__title"><?php echo esc_html($title) ?></h3>
  <div class="sc-iconbox__desc"><?php echo esc_html($description); ?></div>

  <?php if ( $link ) : ?>
  <a href="<?php echo esc_url( $link['url'] ); ?>" class="sc-iconbox__link"><?php echo esc_html( $link['title'] ); ?><span class="ion-ios-arrow-thin-right read-more-icon"></span></a>
  <?php endif; ?>
</div>