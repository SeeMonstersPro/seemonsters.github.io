<?php
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$class_to_filter = vc_shortcode_custom_css_class( $inline_css, ' ' ) . $this->getExtraClass( $class );
$all_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $this->settings['base'], $atts );

$image_ids = explode( ',', $images );

filmic_slick_js();
?>


<div class="sc-carousel">
  <?php
    
    foreach( $image_ids as $image_id ){
      $images = wp_get_attachment_image_src( $image_id, 'full' );
      $images_alt = filmic_img_alt( $image_id, esc_html__( 'Carousel Image', 'filmic' ) );
      $output .='<img src="'. $images[0] .'" alt="' . $images_alt . '">';
    }

    echo wp_kses_post($output);

  ?>
</div><!-- .sc-carousel -->