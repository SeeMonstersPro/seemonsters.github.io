<?php
   $atts = vc_map_get_attributes( $this->getShortcode(), $atts );
   extract( $atts );
   
   $class_to_filter = vc_shortcode_custom_css_class( $inline_css, ' ' ) . $this->getExtraClass( $class );
 
   $all_class = apply_filters( 
     VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
     $class_to_filter,
     $this->settings['base'], $atts
   );
?>

<div class="sc-counter">
	<h2 class="sc-counter__number"><?php echo esc_html( $number ); ?></h2>
	<h3 class="sc-counter__description"><?php echo esc_html( $description ); ?></h3>
</div><!-- .sc-counter -->

<?php
  wp_enqueue_script( 'filmic-waypoints', get_template_directory_uri() . '/js/jquery.waypoints.min.js', array('jquery'), '1.0', true );
  wp_enqueue_script( 'filmic-counterup', get_template_directory_uri() . '/js/jquery.counterup.min.js', array('jquery'), '1.0', true );
?>