<?php
   $atts = vc_map_get_attributes( $this->getShortcode(), $atts );
   extract( $atts );
   
   $class_to_filter = vc_shortcode_custom_css_class( $inline_css, ' ' ) . $this->getExtraClass( $class );
 
   $all_class = apply_filters( 
     VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
     $class_to_filter,
     $this->settings['base'], $atts
   );
   $values = (array) vc_param_group_parse_atts( $values );
?>


<ul class="sc-timeline">
<?php
  foreach ( $values as $value ) {
?>
  <li class="timeline">
    <span class="timeline__year"><?php echo esc_html($value['year']); ?></span>
    <?php if ( $value['title'] ) : ?>
    <h2 class="timeline__title"><?php echo esc_html($value['title']); ?></h2>
    <?php endif; ?>
    <div class="timeline__desc"><?php echo esc_html($value['description']); ?></div>
  </li>
<?php          
  }
?>
</ul><!-- .sc-timeline -->