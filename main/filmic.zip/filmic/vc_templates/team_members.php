<?php
  $atts = vc_map_get_attributes( $this->getShortcode(), $atts );
  extract( $atts );
  
  $class_to_filter = vc_shortcode_custom_css_class( $inline_css, ' ' ) . $this->getExtraClass( $class );

  $all_class = apply_filters( 
    VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
    $class_to_filter,
    $this->settings['base'], $atts
  );

  $img_layout_1 = wp_get_attachment_image_src($atts['image'], 'filmic-740x540-thumbnail-list');
  $img_layout_2 = wp_get_attachment_image_src($atts['image'], 'thumbnail');
  $img_layout_3 = wp_get_attachment_image_src($atts['image'], 'full');
  $image_alt = filmic_img_alt( $atts['image'], esc_html__( 'Member Image', 'filmic' ) );
?>

<?php if ( $layout_type == 'layout_1' ) : ?>

<div class="team-members container">
  <div class="team-members-layout-1 row">
    <div class="team-members__images col-md-6">
      <img src="<?php echo esc_url( $img_layout_1[0] ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>">
    </div><!-- .team-members__images -->

    <div class="team-members__content col-md-6">
      <h3 class="team-members__name"><?php echo esc_html( $name ); ?></h3>
      <span class="team-members__position"><?php echo esc_html( $position ); ?></span>
      <div class="team-members__desc"><?php echo esc_html( $description ); ?></div>
      <ul class="team-members_links">
        <?php if( ! empty( $facebook ) ): ?>
            <li><a href="<?php echo esc_url( $facebook ); ?>"><span class="ion-social-facebook"></span></a></li>
        <?php endif; ?>
        
        <?php if( ! empty( $twitter ) ): ?>
        <li><a href="<?php echo esc_url( $twitter ); ?>"><span class="ion-social-twitter"></span></a></li>
        <?php endif; ?>

        <?php if( ! empty( $instagram ) ): ?>
        <li><a href="<?php echo esc_url( $instagram ); ?>"><span class="ion-social-instagram"></span></a></li>
        <?php endif; ?>
      </ul>
    </div><!-- .team-members__content -->
  </div><!-- .team-memebers-layout-1 -->
</div><!-- .team-members -->

<?php elseif ( $layout_type == 'layout_2' ) : ?>

<div class="team-members">
  <div class="team-members-layout-2">
    <div class="team-members__images">
      <img src="<?php echo esc_url( $img_layout_2[0] ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>">
    </div><!-- .team-members__images -->
    
    <div class="team-members__content">
      <h3 class="team-members__name"><?php echo esc_html( $name ); ?></h3>
      <span class="team-members__position"><?php echo esc_html( $position ); ?></span>
    </div><!-- .team-member__content -->
  </div><!-- .team-member-layout-2 -->
</div><!-- .team-members -->

<?php else : ?>

<div class="team-members">
  <div class="team-members-layout-3">
    <div class="team-members__images">
      <img src="<?php echo esc_url( $img_layout_3[0] ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>">
    </div><!-- .team-members__images -->

    <div class="team-members__content">
      <h3 class="team-members__name"><?php echo esc_html( $name ); ?></h3>
      <span class="team-members__position"><?php echo esc_html( $position ); ?></span>
    </div><!-- .team-members__content -->
  </div><!-- .team-members-layout-3 -->
</div><!-- .team-members -->

<?php endif; ?>
