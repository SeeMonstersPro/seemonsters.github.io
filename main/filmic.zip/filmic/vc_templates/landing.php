<?php
   $atts = vc_map_get_attributes( $this->getShortcode(), $atts );
   extract( $atts );
   
   $class_to_filter = vc_shortcode_custom_css_class( $inline_css, ' ' ) . $this->getExtraClass( $class );
 
   $all_class = apply_filters( 
     VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
     $class_to_filter,
     $this->settings['base'], $atts
   );

   $thumbnail = wp_get_attachment_image_src( $atts['thumbnail'], 'full' );
   $thumbnail_alt = filmic_img_alt( $atts['thumbnail'], esc_html__( 'Thumbnail', 'filmic' ) );
   $link = vc_build_link( $link );
?>

<div class="sc-demo">
    <div class="sc-demo__thumbnail">
        <div class="sc-demo__overlay"></div>
        <a href="<?php echo esc_url( $link['url'] ); ?>" class="t-uppercase sc-demo__cta"><?php echo esc_html( $link['title'] ); ?></a>
        <img src="<?php echo esc_url( $thumbnail[0] ); ?>" alt="<?php esc_attr( $thumbnail_alt ); ?>">
    </div>
    <div class="t-small t-uppercase sc-demo__title"><a href="<?php echo esc_url( $link['url'] ); ?>"><?php echo esc_html( $title ); ?></a></div>
</div><!-- .sc-demo -->