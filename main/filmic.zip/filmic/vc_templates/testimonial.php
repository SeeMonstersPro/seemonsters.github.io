<?php
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$class_to_filter = vc_shortcode_custom_css_class( $inline_css, ' ' ) . $this->getExtraClass( $class );

$all_class = apply_filters( 
  VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,
  $class_to_filter,
  $this->settings['base'], $atts
);

filmic_slick_js();

$args = new WP_Query( array(
  'post_type' => 'ht-testimonial',
  'posts_per_page' => -1
) );

if ($args->have_posts() ): 
  echo '<div class="sc-testimonial sc-testimonial-' . esc_attr( $style ) . '">';
  while ( $args->have_posts() ) :
    $args->the_post();

    $name = function_exists('fw_get_db_post_option') ? fw_get_db_post_option( get_the_ID(), 'name' ) : '';
    $position = function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( get_the_ID(), 'position' ) : '';
?>
  <div class="sc-testimonial__slide">
    <div class="sc-testimonial__content"><?php the_content(); ?></div>

    <div class="sc-testimonial__detail">
    <?php if ( has_post_thumbnail() ) : ?>
      <div class="sc-testimonial__image">
        <?php the_post_thumbnail( 'thumbnail' ); ?>
      </div>
    <?php endif; ?>

      <div class="sc-testimonial__desc">
        <h3 class="sc-testimonial__name"><?php echo esc_html( $name ); ?></h3>
        <span class="sc-testimonial__position"><?php echo esc_html( $position ); ?></span>
      </div>
    </div><!-- .sc-testimonial__detail -->
  </div><!-- .sc-testimonial__slide -->

<?php
  endwhile;

  wp_reset_postdata();

  echo '</div>';

endif;