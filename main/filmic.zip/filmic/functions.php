<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

define( 'FILMIC_VERSION', '1.0' );
define( 'FILMIC_DIR' , get_template_directory().'/' );
define( 'FILMIC_URI' , get_template_directory_uri().'/' );

/*Theme Includes*/
require FILMIC_DIR .'inc/init.php';

/*TGM Plugin Activation*/
require FILMIC_DIR . 'tgm-plugin/recommend_plugins.php';

/*Recommend the Kirki plugin*/
require FILMIC_DIR . 'inc/include-kirki.php';

/*Load the Kirki Fallback class*/
require FILMIC_DIR . 'inc/kirki-fallback.php';

/*Customizer additions.*/
require FILMIC_DIR . 'inc/customizer.php';

/*ELEMENTOR*/
require FILMIC_DIR . 'inc/elementor.php';

/*VC include*/
if ( class_exists( 'WPBakeryVisualComposerAbstract' ) ) {
    function filmic_require_VC() {
        get_template_part('inc/vc', 'include');
    }
    add_action( 'init', 'filmic_require_VC', 2 );
}
