<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package filmic
 */

if ( is_active_sidebar( 'sidebar-shop' ) && is_shop() ) {
	?>
	<div class="col-lg-3">
		<aside id="secondary" class="widget-area" role="complementary">
			<?php dynamic_sidebar( 'sidebar-shop' ); ?>
		</aside>
	</div>
	
	<?php
}elseif ( is_active_sidebar( 'sidebar-blog') && !is_woocommerce() ) {
	?>
	<aside id="secondary" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 'sidebar-blog' ); ?>
	</aside>
	<?php
}
?>


