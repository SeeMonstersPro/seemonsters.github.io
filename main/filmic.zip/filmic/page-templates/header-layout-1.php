<?php
/*page slider revolution*/
$header = function_exists('fw_get_db_post_option') ? fw_get_db_post_option(get_the_ID(), 'page_header_layout') : array();
if(isset($header['gadget']) && $header['gadget'] == 'layout-1' && isset($header['layout-1']['rev_slider']['gadget']) && $header['layout-1']['rev_slider']['gadget'] == 'yes'){
    $alias = $header['layout-1']['rev_slider']['yes']['slider'];
    if($alias != '0'){
        echo do_shortcode('[rev_slider alias="'.$alias.'"]');
    }
}


?>

<header id="masthead" class="site-header header-layout-1<?php echo ( 1 == get_theme_mod( 'sticky_menu' ) ? ' header-sticky' : '' ); ?>" itemscope itemtype="http://schema.org/WPHeader">
    <?php filmic_edit_location('hd1');/*header edit location*/ ?>
    <div class="site-header__container">
        <div class="container">
            <div class="site-header__content">
                <div class="site-branding">
                    <?php filmic_logo_image();/*logo*/ ?>
                </div>

                <?php /*primary menu*/ ?>
                <nav id="site-navigation" class="main-navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
                    <?php if(has_nav_menu('primary')):
                        wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'site-header__menu', 'container' => 'ul' ) );
                    else: ?>
                        <a class="add-menu" href="<?php echo esc_url( get_admin_url() . 'nav-menus.php' ); ?>"><?php esc_html_e( 'Add Menu', 'filmic' ); ?></a>
                    <?php endif; ?>

                </nav>

                <?php /*right menu*/ ?>
                <?php echo filmic_right_header_layout(); ?>

            </div>
        </div>
    </div>
</header>
<?php
    if ( ! class_exists( 'WPBakeryVisualComposerAbstract' ) ) {
        get_template_part('page-templates/page', 'header');/* breadcrumbs */
    }
?>