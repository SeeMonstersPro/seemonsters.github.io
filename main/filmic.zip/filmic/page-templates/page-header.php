<?php
// @codingStandardsIgnoreStart
/**
 * Displaying the page template infor
 */

/*Customizer/Metabox variable*/
$c_bread = get_theme_mod('c_bread', true);
$c_bread_nav = get_theme_mod('c_bread_display', true);

/*page id*/
$pid = get_queried_object_id();
$p_bread = (function_exists('fw_get_db_post_option')) ? fw_get_db_post_option($pid, 'p_bread') : true;

/*Kirki customizer option*/
$c_header_bg = get_theme_mod( 'c_header_bg', 'bg_color' );
$c_header_bg_color = get_theme_mod( 'c_header_bg_color' , '#0b6070' );
$c_header_bg_image = get_theme_mod( 'c_header_bg_image' , false );
$img = wp_get_attachment_image_src($c_header_bg_image, 'full');

/*set default value*/
$final_bread_display = $c_bread;

$gadget = '';
$final_bread_style = array();

/*bread title*/
$bread_title = get_the_title( $pid );

/*blog title*/
$blog_title = get_theme_mod('c_blog_title', 'Blog');

/*bread text align*/
$bread_align = get_theme_mod('c_bread_align', 'center');

if(function_exists('FW')){
    if(is_page() || is_single() || is_home()){
        /*variables*/
        $gadget = $p_bread['gadget'];

        /*page header value*/
        if(isset($gadget) && $gadget != 'default'){
            if($gadget == 'custom'){
                $final_bread_display = true;
            }else{
                $final_bread_display = false;
            }
        }

        /*Override value if enable custom page header*/
        if(isset($gadget) && $gadget == 'custom'){

            /*bread title*/
            $bread_title = !empty($p_bread['custom']['p_bread_title']) ? $p_bread['custom']['p_bread_title'] : $bread_title;

            /*bread align*/
            $bread_align = $p_bread['custom']['p_bread_align'];

            /*bread bg*/
            $p_bread_bg = isset($p_bread['custom']['p_bread_bg']) ? $p_bread['custom']['p_bread_bg'] : '';

            if(isset($p_bread_bg['gadget']) && $p_bread_bg['gadget'] == 'color_bg'){
                $final_bread_style[] = 'background:' . $p_bread_bg['color_bg']['color_bg_data'];
            }else{
                if(!empty($p_bread_bg['img_bg']['img_bg_data'])):
                    $final_bread_style[] = 'background-image:url(' . $p_bread_bg['img_bg']['img_bg_data']['url'] . ')';
                endif;
            }
        }
    }
}

/*output breadcrumbs style*/
$final_bread_style = !empty($final_bread_style) ? 'style="' . implode('; ', $final_bread_style) . '"' : '';

/*not display on 404 page*/
if(!is_404() && $final_bread_display == true): ?>
    <nav class="theme-breadcrumb flw" <?php echo wp_kses_post($final_bread_style); ?>>
        <?php filmic_edit_location('bread');/*page-header edit location*/ ?>
        <div class="container">
            <div class="bread flw text-<?php echo esc_attr($bread_align); ?>">
                <?php /*page title*/ ?>
                <h1 class="bread-title">
                <?php
                    filmic_page_header_title($bread_title);
                ?></h1>
                <?php /*breadcrumbs*/
                    if (function_exists('fw_ext_breadcrumbs') && $c_bread_nav == 1) {
                        fw_ext_breadcrumbs();
                } ?>
            </div>
        </div>
    </nav>
<?php endif;