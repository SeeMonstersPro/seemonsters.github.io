<?php
/**
 * Template Name: Blank Page Template
 */

get_header('no-content'); ?>
	<div class="blank-page flw">
		<div class="container">
			<?php
				while ( have_posts() ) : the_post();
					get_template_part('template-parts/content', 'page');
				endwhile;
			?>
		</div>
	</div>	
<?php get_footer('no-content'); ?>