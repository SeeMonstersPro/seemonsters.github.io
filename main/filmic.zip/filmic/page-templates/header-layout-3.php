<?php
/*info content*/
$info = get_theme_mod('hd3_info',
'<ul>
<li><a href="tel:+012123456" style="color: #ffffff">(+01)-212-3456</a></li>
<li><a href="mailto:info@jamesburton.com" style="color: #8f8f8f">info@jamesburton.com</a></li>
</ul>');
?>

<header id="masthead" class="site-header header-layout-3<?php echo ( 1 == get_theme_mod( 'sticky_menu' ) ? ' header-sticky' : '' ); ?>" itemscope itemtype="http://schema.org/WPHeader">
    <?php filmic_edit_location('hd3');/*header edit location*/ ?>
    <div class="site-header__container">
        <div class="container">
            <div class="site-header__content">
                <div class="site-branding">
                    <?php filmic_logo_image();/*logo*/ ?>
                </div>

                <?php if(!empty($info)):/*infomation*/ ?>
                    <div class="head-info-block"><?php echo wp_kses_decode_entities($info); ?></div>
                <?php endif; ?>

                <div class="toggle-menu">
                    <span class="toggle-menu__circle"></span>
                    <a href="#" class="toggle-menu__link js-menu-link">
                        <span class="toggle-menu__icon">
                            <span class="toggle-menu__line toggle-menu__line-1"></span>
                            <span class="toggle-menu__line toggle-menu__line-2"></span>
                            <span class="toggle-menu__line toggle-menu__line-3"></span>
                        </span>
                    </a>
                </div><!-- .toggle-menu -->

                <div class="menu-overlay">
                    <div class="menu-overlay__container">
                        <nav itemscope itemtype="http://schema.org/SiteNavigationElement">
                            <?php if(has_nav_menu('primary')):
                                wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'menu-main', 'container' => 'ul' ) );
                            else: ?>
                                <a class="add-menu" href="<?php echo esc_url( get_admin_url() . 'nav-menus.php' ); ?>"><?php esc_html_e( 'Add Menu', 'filmic' ); ?></a>
                            <?php endif; ?>
                        </nav>
                    </div><!-- .menu-overlay__container -->
                </div><!-- .menu-overlay -->
            </div>
        </div>
    </div>
</header>
<?php
    if ( ! class_exists( 'WPBakeryVisualComposerAbstract' ) ) {
        get_template_part('page-templates/page', 'header');/* breadcrumbs */
    }
?>