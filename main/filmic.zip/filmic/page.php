<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package filmic
 */

get_header(); ?>
<?php get_template_part('page-templates/page', 'header');/* breadcrumbs */ ?>


	<main id="main" class="site-main" role="main">

		<?php if(have_posts()):
    		while ( have_posts() ) : the_post();

                $vc = get_post_meta(get_the_ID(), '_wpb_vc_js_status', true);
                if($vc == true){
                    get_template_part( 'template-parts/content', 'page' );
                }else{
                    echo '<div class="container page-without-vc">';
                        get_template_part( 'template-parts/content', 'page' );

                    if ( comments_open() || get_comments_number() ) {
                        comments_template();
                    }

                    echo '</div>';
                }

    		endwhile;
        else :
            echo '<div class="container">';
                get_template_part( 'template-parts/content', 'none' );
            echo '</div>';
        endif;
		?>

	</main>

<?php
get_footer();
