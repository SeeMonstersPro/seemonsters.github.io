<?php
// @codingStandardsIgnoreStart
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package filmic
 */

$blog_sidebar = get_theme_mod('blog_sidebar', 'right');

$class = $full_layout = '';
$col = 'col-lg-9';

if($blog_sidebar == 'left'){
    $class = 'blog-sidebar-left';
}

if($blog_sidebar == 'full' || !is_active_sidebar( 'sidebar-blog' )){
    $col = 'col-lg-12';
}

get_header(); ?>
	<?php get_template_part('page-templates/page', 'header');/* breadcrumbs */ ?>
	<div class="container">
		<div class="row <?php echo esc_attr($class); ?>">
			<section id="primary" class="content-area <?php echo esc_attr($col); ?>">
				<main id="main" class="site-main">

				<?php if ( have_posts() ) :

					if ( is_home() && ! is_front_page() ) : ?>
						<header>
							<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
						</header>
					<?php
					endif;

					while ( have_posts() ) : the_post();
						get_template_part( 'template-parts/content', get_post_format() );
					endwhile;

					filmic_paging();

				else :
					get_template_part( 'template-parts/content', 'none' );
				endif;
				?>

				</main>
			</section>

			<?php
				// Sidebar.
				filmic_get_sidebar( 'sidebar-blog', $blog_sidebar );
			?>
		</div>
	</div>

<?php
get_footer();
