<form action="<?php echo esc_url(home_url( '/' )); ?>" method="get" role="search" class="search-form">
  <input type="search" placeholder="<?php esc_attr_e( 'Search...', 'filmic' ); ?>" value="<?php echo get_search_query(); ?>" name="s" title="<?php esc_attr_e( 'search', 'filmic' ); ?>" class="search-field">
  <button type="submit" class="search-submit">
    <span class="ion-ios-search"></span>
  </button>
</form>