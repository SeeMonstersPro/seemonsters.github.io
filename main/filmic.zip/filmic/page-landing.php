<?php
/**
 * Template Name: Landing Page
 * Template Post Type: page
 * 
 * @package filmic
 */

get_header('landing');
?>

<main id="main" class="site-main" role="main">
    <?php
        if ( have_posts() ) :

            while ( have_posts() ) : the_post();
            $vc = get_post_meta(get_the_ID(), '_wpb_vc_js_status', true);
                if ($vc == true) {
                    the_content();
                } else {
                    echo '<div class="container page-without-vc">';
                        the_content();
                    echo '</div>';
                }
            endwhile;

        else:

            echo '<div class="container">';
                get_template_part( 'templates-parts/content', 'none' );
            echo '</div>';

        endif;
    ?>
</main><!-- #main -->

<?php
get_footer('landing');