<?php
/**
 * Elementor Widget
 *
 * @package Dozir Elementor Widget
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

/**
 * Dozir Menu Toggle
 */
class Filmic_Humberger_Menu extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @return string Widget name.
	 */
	public function get_name() {

		return 'filmic-humberger-menu';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @return string Widget title.
	 */
	public function get_title() {

		return esc_html__( 'Humberger Menu', 'filmic' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-menu-toggle';
	}

	/**
	 * Retrieve the get script.
	 *
	 * @return string Widget get script.
	 */
	public function get_script_depends() {
		return array( 'filmic-humberger-menu' );
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return array( 'filmic-theme' );
	}


	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 */
	protected function _register_controls() { // phpcs:ignore
		$this->main_menu();

		$this->menu_sidebar_style();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<div class="filmic-navigation--widget">
			<div class="toggle-menu">
				<span class="toggle-menu__circle"></span>
				<a href="#" class="toggle-menu__link js-menu-link">
					<span class="toggle-menu__icon">
						<span class="toggle-menu__line toggle-menu__line-1"></span>
						<span class="toggle-menu__line toggle-menu__line-2"></span>
						<span class="toggle-menu__line toggle-menu__line-3"></span>
					</span>
					<!-- icon toggle -->
					<span class="screen-reader-text menu-toggle-text"><?php esc_html_e( 'Menu', 'filmic' ); ?></span>
				</a>
			</div>
			<!-- toggle menu -->

			<div class="menu-overlay">
				<div class="menu-overlay__container">
					<nav class="filmic-menu-dropdown <?php echo esc_attr( $settings['menu'] ); ?>" aria-label="<?php esc_attr_e( 'Dropdown navigation', 'filmic' ); ?>">
						<?php
						if ( 'none' !== $settings['menu'] ) {
							$args = array(
								'menu'           => $settings['menu'],
								'container'      => '',
								'menu_class'     => 'filmic-dropdown-menu',
								'theme_location' => 'primary',
							);

							wp_nav_menu( $args );
						} elseif ( is_user_logged_in() ) {
							?>
							<a class="add-menu" href="<?php echo esc_url( get_admin_url() . 'nav-menus.php' ); ?>"><?php esc_html_e( 'Add a Primary Menu', 'filmic' ); ?></a>
						<?php } ?>
					</nav>
				</div>
			</div>
		</div>

		<?php
	}

	/**
	 * [get_all_nav_active description]
	 */
	public function get_all_nav_active() {
		$menus   = wp_get_nav_menus();
		$options = array();

		foreach ( $menus as $menu ) {
			$options[ $menu->slug ] = $menu->name;
		}

		return $options;
	}


	/**
	 * Main menu control.
	 */
	public function main_menu() {
		$this->start_controls_section(
			'section_content',
			array(
				'label' => esc_html__( 'Layout', 'filmic' ),
			)
		);

		$this->add_control(
			'menu',
			array(
				'label'        => esc_html__( 'Menu', 'filmic' ),
				'type'         => Controls_Manager::SELECT,
				'options'      => $this->get_all_nav_active(),
				'save_default' => true,
				'description'  => sprintf( __( 'Go to the <a href="%s" target="_blank">Menus screen</a> to manage your menus.', 'filmic' ), admin_url( 'nav-menus.php' ) ), //phpcs:ignore
			)
		);

		$this->end_controls_section();
	}

	/**
	 * [menu_style_nornal description]
	 */
	public function menu_style_nornal() {
		$this->add_control(
			'menucolor',
			array(
				'label'     => __( 'Menu Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000',
				'scheme'    => array(
					'type'  => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				),
				'selectors' => array(
					'{{WRAPPER}} .filmic-menu > li > a' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'menu_typo',
				'label'    => __( 'Typography', 'filmic' ),
				'scheme'   => Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .filmic-menu > li > a',
			)
		);

		$this->add_control(
			'menu_item_padding',
			array(
				'label'      => __( 'Padding', 'filmic' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'em' ),
				'default'    => array(
					'top'    => 0,
					'bottom' => 0,
					'left'   => 20,
					'right'  => 20,
				),
				'selectors'  => array(
					'{{WRAPPER}} .filmic-menu > li > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);
	}

	/**
	 * [menu_style_hover description]
	 */
	public function menu_style_hover() {
		$this->add_control(
			'menu_color_hover',
			array(
				'label'     => __( 'Menu Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#aa3166',
				'scheme'    => array(
					'type'  => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				),
				'selectors' => array(
					'{{WRAPPER}} .filmic-menu > li:hover > a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .filmic--hover-underline .filmic-menu > li:hover > a:after' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'menu_item_background_color_hover',
			array(
				'label'     => __( 'Background Item Hover', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#eee',
				'scheme'    => array(
					'type'  => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				),
				'selectors' => array(
					'{{WRAPPER}} .filmic--hover-background .filmic-menu > li:hover' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'menu_typo_hover',
				'label'    => __( 'Typography', 'filmic' ),
				'scheme'   => Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .filmic-menu > li:hover > a',
			)
		);
	}

	/**
	 * [submenu_style_nornal description]
	 */
	public function submenu_style_nornal() {
		$this->add_control(
			'color_submenu',
			array(
				'label'     => __( 'SubMenu Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#000',
				'separator' => 'before',
				'scheme'    => array(
					'type'  => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				),
				'selectors' => array(
					'{{WRAPPER}} .filmic-menu .menu-item-has-children .sub-menu a' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'submenu_typo',
				'label'    => __( 'Typography', 'filmic' ),
				'scheme'   => Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .filmic-menu .menu-item-has-children .sub-menu a',
			)
		);
	}

	/**
	 * Submenu style hover description
	 */
	public function submenu_style_hover() {
		$this->add_control(
			'color_submenu_hover',
			array(
				'label'     => __( 'SubMenu Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#aa3166',
				'separator' => 'before',
				'scheme'    => array(
					'type'  => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				),
				'selectors' => array(
					'{{WRAPPER}} .filmic-menu li .sub-menu > li:hover > a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .filmic--hover-underline .filmic-menu li .sub-menu > li:hover > a:after' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .filmic-menu .sub-menu li.current-menu-item a' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'submenu_item_background_color_hover',
			array(
				'label'     => __( 'Background Submenu Item Hover', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#eee',
				'scheme'    => array(
					'type'  => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				),
				'selectors' => array(
					'{{WRAPPER}} .filmic--hover-background .filmic-menu .sub-menu > li:hover' => 'background-color: {{VALUE}}',
				),
			)
		);
	}

	/**
	 * [menu_sidebar_style description]
	 */
	public function menu_sidebar_style() {
		$this->start_controls_section(
			'menu_sidebar_style',
			array(
				'label' => __( 'Menu Style', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->start_controls_tabs(
			'menu_sidebar_style_tabs'
		);

		$this->start_controls_tab(
			'style_memu_sidebar_normal_tab',
			array(
				'label' => __( 'Normal', 'filmic' ),
			)
		);

		$this->menu_sidebar_style_nornal();

		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_menu_sidebar_hover_tab',
			array(
				'label' => __( 'Hover', 'filmic' ),
			)
		);

		$this->menu_sidebar_style_hover();
	}

	/**
	 * [menu_sidebar_style_nornal description]
	 */
	public function menu_sidebar_style_nornal() {
		$this->add_control(
			'color_toggle',
			array(
				'label'     => __( 'Toggle Icon Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#292929',
				'separator' => 'before',
				'scheme'    => array(
					'type'  => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				),
				'selectors' => array(
					'{{WRAPPER}} .toggle-menu .toggle-menu__line' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'color_toggle_bg',
			array(
				'label'     => __( 'Toggle Icon Background', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'separator' => 'before',
				'scheme'    => array(
					'type'  => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				),
				'selectors' => array(
					'{{WRAPPER}} .toggle-menu .toggle-menu__circle' => 'background-color: {{VALUE}}',
				),
			)
		);

		$this->add_control(
			'color_parent_menu',
			array(
				'label'     => __( 'Parent Menu Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#292929',
				'separator' => 'before',
				'scheme'    => array(
					'type'  => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				),
				'selectors' => array(
					'{{WRAPPER}} .filmic-navigation--widget li > a' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'menu_parent_typo',
				'label'    => __( 'Typography Parent Menu', 'filmic' ),
				'scheme'   => Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .filmic-navigation--widget li > a',
			)
		);

		$this->add_control(
			'color_menu_sub',
			array(
				'label'     => __( 'Sub Menu Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#292929',
				'separator' => 'before',
				'scheme'    => array(
					'type'  => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				),
				'selectors' => array(
					'{{WRAPPER}} .filmic-navigation--widget li ul li a' => 'color: {{VALUE}}',
				),
			)
		);

		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'menu_sub_typo',
				'label'    => __( 'Typography Sub Menu', 'filmic' ),
				'scheme'   => Elementor\Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .filmic-navigation--widget li ul li a',
			)
		);
	}

	/**
	 * Menu sidebar style hover description
	 */
	public function menu_sidebar_style_hover() {

		$this->add_control(
			'color_menu_sidebar_hover',
			array(
				'label'     => __( 'Menu Hover', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9e8157',
				'separator' => 'before',
				'scheme'    => array(
					'type'  => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				),
				'selectors' => array(
					'{{WRAPPER}} .filmic-navigation--widget li a:hover' => 'color: {{VALUE}}',
				),
			)
		);

	}
}
