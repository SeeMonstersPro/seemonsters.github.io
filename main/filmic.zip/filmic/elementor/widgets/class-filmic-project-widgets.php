<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

/**
 * Filmic Project widget.
 *
 * Filmic widget that displays an project widget for page.
 *
 * @since 1.0.0
 */

class Filmic_Project_Widgets extends Widget_Base {
	/**
	 * Get widget name.
	 *
	 * Retrieve landing image widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'filmic-project-widgets';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve landing image widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Project Widget', 'filmic' );
	}

		/**
	 * Get widget icon.
	 *
	 * Retrieve landing image widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-youtube';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the icon widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'filmic-theme' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'filmic-project-widgets' );
	}

	/**
	 * Register category box widget controls.
	 *
	 * Add different input fields to allow the user to change and customize the widget settings
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'section_project',
			[
				'label' => esc_html__( 'Content', 'filmic' ),
			]
		);

		$this->add_control(
            'style_layout',
            [
                'label' => esc_html__( 'Style layout', 'filmic' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1'    => esc_html__( 'Layout Grid', 'filmic' ),
                    '2'      => esc_html__( 'Layout Grid 2', 'filmic' ),
                    '3'      => esc_html__( 'Layout Zigzag', 'filmic' ),
                    '4'      => esc_html__( 'Layout Marsory', 'filmic' ),
                    '5'      => esc_html__( 'Layout Filter', 'filmic' ),
                    '6'      => esc_html__( 'Layout Credits', 'filmic' ),

                ],
                'default' => '1'
            ]
        );

		$this->add_control(
			'columns',
			[
				'label'          => esc_html__( 'Columns', 'filmic' ),
				'type'           => Controls_Manager::SELECT,
				'options'        => [
					'2' => esc_html__( '2', 'filmic' ),
					'3' => esc_html__( '3', 'filmic' ),
					'4' => esc_html__( '4', 'filmic' )
				],
				'default'        => '4',
				'condition' => [
					'style_layout!' => [
						'3',
						'4',
					]
				],

			]
		);

		$this->add_control(
			'product_cat',
			array(
				'label'     => esc_html__( 'Categories', 'miini' ),
				'type'      => Controls_Manager::SELECT2,
				'options'   => filmic_get_narrow_data( 'term', 'ht-project-category' ),
				'multiple'  => true,
				'condition' => [
					'style_layout!' => [
						'5',
					]
				],
			)
		);

		$this->add_control(
			'products_per_page',
			array(
				'label' => esc_html__( 'Post Per Page', 'filmic' ),
				'type'  => Controls_Manager::NUMBER,
				'default' => 4
			)
		);

		$this->add_control(
			'order',
			array(
				'label' => esc_html__( 'Order', 'filmic' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'ASC' => esc_html__( 'ASC', 'filmic' ),
					'DESC' => esc_html__( 'DESC', 'filmic' )
				],
				'default' => 'DESC'
			)
		);

		$this->add_control(
			'order_by',
			[
				'label' => esc_html__( 'Order By', 'filmic' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'ID' => esc_html__( 'ID', 'filmic' ),
					'date' => esc_html__( 'Date', 'filmic' ),
					'title' => esc_html__( 'Title', 'filmic' ),
					'rand' => esc_html__( 'Rand', 'filmic' )
				],
				'default' => 'ID'
			]
		);


		$this->add_control(
			'show_arrow',
			[
				'label' => __( 'Show arrows', 'filmic' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'filmic' ),
				'label_off' => __( 'Hide', 'filmic' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'style_layout!' => [
						'2',
						'4',
						'5',
					]
				],
			]
		);


        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_style',
            [
                'label' => esc_html__( 'Style', 'filmic' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__( 'Title Color', 'filmic' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-title a' => 'color: {{VALUE}}',
                ],
                'default' => '#292929'
            ]
        );

        $this->add_control(
            'title_color_hover',
            [
                'label'     => esc_html__( 'Title Color Hover', 'filmic' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-title a:hover' => 'color: {{VALUE}}',
                ],
                'default' => '#9e8157'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .project-title a',
            ]
        );

        $this->add_control(
            'cat_color',
            [
                'label'     => esc_html__( 'Category Color', 'filmic' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-cat a' => 'color: {{VALUE}}',
                ],
                'default' => '#8f8f8f',
            ]
        );

        $this->add_control(
            'cat_color_hover',
            [
                'label'     => esc_html__( 'Category Color Hover', 'filmic' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-cat a:hover' => 'color: {{VALUE}}',
                ],
                'default' => '#9e8157',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'readmore_typography',
                'selector' => '{{WRAPPER}} .project-cat a',
            ]
        );

        $this->end_controls_section();
	}

	/**
	 * Render Project widget output on the front end.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 *
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$cat_id   = $settings['product_cat'];
		$layout = $settings['style_layout'];
		$columns = $settings['columns'];
		$show_arrow = $settings['show_arrow'];

		$args = array(
            'post_type' => 'ht-project',
            'ignore_sticky_posts' => 1,
			'posts_per_page' => $settings['products_per_page'],
			'order' => $settings['order'],
			'orderby' => $settings['order_by']
        );

		if ( ! empty( $cat_id ) ) :
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'ht-project-category',
					'field'    => 'term_id',
					'terms'    => $cat_id,
				),
			);
		endif;

        $posts = new WP_Query( $args );

        ?>
        	<?php
        		if ( '5' == $layout ) {
        			?>
        				<div class="filter-project">
	                        <ul class="category-isotope center-nav">
	                            <li class="nav-item">
	                                <a class="nav-link active" href="#" data-toggle="tab" data-filter="*"><?php echo esc_html__('All', 'filmic'); ?></a>
	                            </li>
	                            <?php
	                            	$args = array(
						               'taxonomy' => 'ht-project-category',
						               'orderby' => 'name',
						               'order'   => 'ASC'
						            );

						   			$cats = get_categories($args);

						   			foreach($cats as $cat) {
										?>
											<li class="nav-item">
												<a class="nav-link" href="#" data-filter=".<?php echo esc_attr( $cat->slug );?>"><?php echo $cat->name; ?></a>
											</li>
										<?php
									}

	                            ?>
	                        </ul>
	                    </div>
        			<?php
        		}
        	?>
        	<div <?php if ( '5' == $layout ) { ?>  id="gallery-isotope" <?php } ?> class="filmic-project-widgets filmic-project-layout-<?php echo esc_attr( $layout ); ?> <?php if ( '5' == $layout ) { ?> project-columns-<?php echo esc_attr( $columns ); ?> <?php } ?>">
        		<?php if ( '5' != $layout ) { ?>  <div class="filmic-project-wrapp project-columns-<?php echo esc_attr( $columns ); ?>">  <?php } ?>
					<?php
						while ( $posts->have_posts() ) :
				        	$posts->the_post();

				        	$trailer = fw_get_db_post_option( get_the_ID(), 'trailer');
            				$description = fw_get_db_post_option( get_the_ID(), 'description' );

				        	$pid  = get_the_ID();
	                        $taxs = get_the_terms( $pid, 'ht-project-category' );

				        ?>
				        	<?php
				        		if ( '4' == $layout ) :
				        			?>
				        				<div class="filmic-layout-marsory">
			        				<?php
			        			endif;
				        	?>
				        	<div class="project-items <?php
                                            if ( $taxs ) {
                                                foreach( $taxs as $key ) {
                                                    get_term_link( $key->term_ID );
                                                    echo esc_attr( $key->slug );
                                                }
                                            }?>">
								<div class="project-head">
									<a href="<?php echo esc_url( the_permalink() ); ?>">
										<?php if ( has_post_thumbnail() ): ?>
		                                    <?php the_post_thumbnail(); ?>
		                                <?php endif ?>
									</a>
									<!-- Project image -->
									<a href="<?php echo esc_url( $trailer ); ?>" data-lity class="project-trailer-btn">
										<?php echo esc_html__( 'Watch Trailer', 'filmic' );  ?>
									</a>
									<!-- project button -->

								</div>
								<!-- project-head -->
								<div class="project-detail">
									<span class="project-cat">
										<?php
                                            if ( $taxs ) {
                                                foreach( $taxs as $key ) {
                                                    get_term_link( $key->term_ID );
                                                    ?>
                                                        <a href="<?php echo get_term_link( $key->term_id ); ?>" class="category-project"><?php echo esc_attr($key->name); ?></a>
                                                    <?php
                                                }
                                            }
                                        ?>
									</span>
									<!-- project category -->
									<h3 class="project-title">
										<a href="<?php echo esc_url( the_permalink() ); ?>"><?php echo get_the_title(); ?></a>
									</h3>
									<!-- Project title -->
									<?php
										if ( '3' == $layout ) {
											?>
												<p><?php echo esc_html( $description ); ?></p>
											<?php
										}
									?>

									<?php
										if ( 'yes' == $show_arrow ) {
											?>
												<a href="<?php echo esc_url( the_permalink() ); ?>" class="project-arrow"></a>
											<?php
										}
										if ( '6' == $layout ) {
											?>
												<a href="<?php echo esc_url( the_permalink() ); ?>" class="project-permalink"></a>
											<?php
										}
									?>
									<!-- project arrows -->

								</div>
								<!-- project-detail -->
				        	</div>
				        	<?php
				        		if ( '4' == $layout ) :
				        			?>
				        				</div>
			        				<?php
			        			endif;
				        	?>
				        <?php

				        endwhile;
					?>
				<?php if ( '5' != $layout ) { ?>  </div>  <?php } ?>
        	</div>
        	<!-- project widgets -->
        <?php
        wp_reset_postdata();
	}
}

