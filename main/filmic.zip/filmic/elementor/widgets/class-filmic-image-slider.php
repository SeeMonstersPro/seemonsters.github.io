<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;

/**
 * Filmic landing image widget.
 *
 * Filmic widget that displays an landing image for landing page.
 *
 * @since 1.0.0
 */

class Filmic_Image_Slider extends Widget_Base {
	/**
	 * Get widget name.
	 *
	 * Retrieve landing image widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'filmic_image_slider';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve landing image widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Image Slider', 'filmic' );
	}

		/**
	 * Get widget icon.
	 *
	 * Retrieve landing image widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-carousel';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the icon widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'filmic-theme' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'filmic-image-slider' );
	}

	/**
	 * Register category box widget controls.
	 *
	 * Add different input fields to allow the user to change and customize the widget settings
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'section_image_slider',
			array(
				'label' => esc_html__( 'Image Slider', 'filmic' ),
			)
		);

		$repeater = new Elementor\Repeater();

		$repeater->add_control(
			'image',
			[
				'label' => esc_html__( 'Image', 'filmic' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				]
			]
		);

		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'filmic' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter Title', 'filmic' ),
				'default' => esc_html__( 'Soundstages', 'filmic' )
			]
		);

		$this->add_control(
			'image',
			[
				'label' => esc_html__( 'Image Slider', 'filmic' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[],
					[],
					[]
				],
				'title_field' => '{{{ name }}}'
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'image_style',
			[
				'label' => esc_html__( 'Furniture Style', 'filmic' ),
				'tab'  => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_style',
			[
				'label' => esc_html__( 'Color Title', 'filmic' ),
				'type'  => Controls_Manager::COLOR,
				'default' => '#000',
				'selectors' => [
					'{{WRAPPER}} .slider-wrapper-title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'selector' => '{{WRAPPER}} .slider-wrapper-title',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$image = $settings['image'];
		?>
        	<div class="filmic-image-slider image-slider-js">
				<?php foreach ($image as $images ): ?>
					<div class="filmic-image-slider-item">
						<div class="slider-wrapp">
							<img src="<?php echo esc_url( $images['image']['url'] ); ?>" alt="image">
						</div>
						<div class="slider-wrapper">
							<h2 class="slider-wrapper-title"><?php echo esc_html( $images['title'] ); ?></h2>
						</div>
					</div>
				<?php endforeach ?>
        	</div>
        	<div class="testimonial-slider_arrows">
                <span class="testimonial__arrow--left">Prev </span>
                <span class="testimonial__arrow--right">Next </span>
            </div>
		<?php
	}
}
