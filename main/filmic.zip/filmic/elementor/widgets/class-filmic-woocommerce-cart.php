<?php
/**
 * Elementor Widget
 *
 * @package Dozir Elementor Widget
 */

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

/**
 * Class for woostify elementor Cart icon widget.
 */
class Filmic_Woocommerce_Cart extends Widget_Base {
	/**
	 * Category
	 */
	public function get_categories() {
		return [ 'filmic-theme' ];
	}

	/**
	 * Name
	 */
	public function get_name() {
		return 'filmic-cart-icon';
	}

	/**
	 * Gets the title.
	 */
	public function get_title() {
		return __( 'Filmic - Cart Icon', 'filmic' );
	}

	/**
	 * Gets the icon.
	 */
	public function get_icon() {
		return 'eicon-cart';
	}

	/**
	 * General
	 */
	public function general() {
		$this->start_controls_section(
			'count',
			[
				'label' => __( 'Cart', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon',
			[
				'label'   => __( 'Choose Icon', 'filmic' ),
				'type'    => Controls_Manager::ICON,
				'include' => [
					'eicon-cart',
					'eicon-cart-light',
					'eicon-cart-medium',
					'eicon-cart-solid',
					'eicon-bag-light',
					'eicon-bag-medium',
					'eicon-bag-solid',
					'eicon-basket-light',
					'eicon-basket-medium',
					'fa fa-shopping-bag',
					'fa fa-shopping-basket',
					'fa fa-shopping-cart',
					'fa fa-opencart',
					'fa fa-cart-arrow-down',
					'fa fa-cart-plus',
				],
				'default'   => 'fa fa-shopping-cart',
			]
		);

		$this->add_control(
			'cart_color',
			[
				'label'     => __( 'Color Cart', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} #minicart .icon-size' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_color_hover',
			[
				'label'     => __( 'Color Cart Hover', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9e8157',
				'selectors' => [
					'{{WRAPPER}} #minicart .icon-size:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'cart_size',
			[
				'label'      => __( 'Cart Size', 'filmic' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min' => 10,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} #minicart .icon-size' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'count_tab',
			[
				'label' => __( 'Count Tab', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'count_bg_color',
			[
				'label'     => __( 'Background Count Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9e8157',
				'selectors' => [
					'{{WRAPPER}} #minicart .cart-contents-count' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'count_color',
			[
				'label'     => __( 'Color Count', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} #minicart .cart-contents-count' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'count_dimension',
			[
				'label'      => __( 'Dimension', 'filmic' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min' => 10,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cart-contents-count' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'count_border_radius',
			[
				'label'      => __( 'Border Radius Count', 'filmic' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min' => 10,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cart-contents-count' => 'border-radius: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'count_size',
			[
				'label'      => __( 'Size Count', 'filmic' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min' => 10,
						'max' => 200,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} #minicart .cart-contents-count' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'position_x_right',
			[
				'label'      => __( 'X Axis', 'filmic' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => -100,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cart-contents-count' => 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'position_y_top',
			[
				'label'      => __( 'Y Axis', 'filmic' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min'  => -100,
						'max'  => 200,
						'step' => 1,
					],
					'%' => [
						'min' => -100,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .cart-contents-count' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}


	/**
	 * Controls
	 */
	protected function _register_controls() {
		$this->general();
	}

	/**
	 * Render
	 */
	public function render() {
		$settings = $this->get_settings_for_display();
		$icon = $settings['icon'];
		if ( class_exists( 'WooCommerce' ) ) {
			if ( null === WC()->cart ) {
				return;
			}
            $count = WC()->cart->cart_contents_count;
            ?>
	            <div class="cart_mini flex">
	                <div id="minicart" class="cart-contents" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>">
	                    <span class="icon-size <?php echo esc_attr( $icon ); ?>"></span>
                        <span class="cart-contents-count"><?php echo esc_html( $count ); ?></span>
                        <div id="cartcontents">
		                    <div class="widget_shopping_cart_content">
		                        <?php woocommerce_mini_cart(); ?>
		                    </div>
	               		</div>
	                </div>
	            </div>
            <?php
    	}
	}
}
