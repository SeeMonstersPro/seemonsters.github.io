<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

/**
 * Filmic landing image widget.
 *
 * Filmic widget that displays an landing image for landing page.
 *
 * @since 1.0.0
 */

class Filmic_Studio_Widgets extends Widget_Base {
	/**
	 * Get widget name.
	 *
	 * Retrieve landing image widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'filmic-studio-widgets';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve landing image widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Studio Widget', 'filmic' );
	}

		/**
	 * Get widget icon.
	 *
	 * Retrieve landing image widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-slider-3d';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the icon widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'filmic-theme' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'filmic-studio-widgets' );
	}

	/**
	 * Register category box widget controls.
	 *
	 * Add different input fields to allow the user to change and customize the widget settings
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'section_studio',
			[
				'label' => esc_html__( 'Content', 'filmic' ),
			]
		);
		$this->add_control(
            'style_layout',
            [
                'label' => esc_html__( 'Style layout', 'filmic' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1'    => esc_html__( 'Layout 1', 'filmic' ),
                    '2'      => esc_html__( 'Layout 2', 'filmic' ),
                ],
                'default' => '1'
            ]
        );

		$this->add_responsive_control(
			'columns',
			[
				'label'          => esc_html__( 'Columns', 'filmic' ),
				'type'           => Controls_Manager::SELECT,
				'options'        => [
					'1' => esc_html__( '1', 'filmic' ),
					'2' => esc_html__( '2', 'filmic' ),
					'3' => esc_html__( '3', 'filmic' ),
					'4' => esc_html__( '4', 'filmic' )
				],
				'default'        => '4',
				'tablet_default' => '2',
				'mobile_default' => '1',
				'condition' => [
					'style_layout!' => '1',
				],

			]
		);

		$this->add_control(
			'columns_show',
			[
				'label'          => esc_html__( 'Slide To Show', 'filmic' ),
				'type'           => Controls_Manager::SELECT,
				'options'        => [
					'1' => esc_html__( '1', 'filmic' ),
					'2' => esc_html__( '2', 'filmic' ),
					'3' => esc_html__( '3', 'filmic' ),
					'4' => esc_html__( '4', 'filmic' )
				],
				'default'        => '4',
				'condition' => [
					'style_layout!' => '2',
				],

			]
		);

		$this->add_control(
			'products_per_page',
			array(
				'label' => esc_html__( 'Post Per Page', 'filmic' ),
				'type'  => Controls_Manager::NUMBER,
				'default' => 4
			)
		);

		$this->add_control(
			'order',
			array(
				'label' => esc_html__( 'Order', 'filmic' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'ASC' => esc_html__( 'ASC', 'filmic' ),
					'DESC' => esc_html__( 'DESC', 'filmic' )
				],
				'default' => 'DESC'
			)
		);

		$this->add_control(
			'order_by',
			[
				'label' => esc_html__( 'Order By', 'filmic' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'ID' => esc_html__( 'ID', 'filmic' ),
					'date' => esc_html__( 'Date', 'filmic' ),
					'title' => esc_html__( 'Title', 'filmic' ),
					'rand' => esc_html__( 'Rand', 'filmic' )
				],
				'default' => 'ID'
			]
		);

        $this->add_control(
			'show_excerpt',
			[
				'label' => __( 'Show Excerpt', 'filmic' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'filmic' ),
				'label_off' => __( 'Hide', 'filmic' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_readmore',
			[
				'label' => __( 'Show More Details', 'filmic' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __( 'Show', 'filmic' ),
				'label_off' => __( 'Hide', 'filmic' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
            'section_content_style',
            [
                'label' => esc_html__( 'Style', 'leadcon' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_control(
            'title_color',
            [
                'label'     => esc_html__( 'Title Color', 'leadcon' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .entry-title a' => 'color: {{VALUE}}',
                ],
                'default' => '#292929'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'title_typography',
                'selector' => '{{WRAPPER}} .entry-title a',
            ]
        );

        $this->add_control(
            'excerpt_color',
            [
                'label'     => esc_html__( 'Excerpt Color', 'leadcon' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .studio-post-excerpt' => 'color: {{VALUE}}',
                ],
                'default' => '#8f8f8f',
                'condition' => [
					'show_excerpt!' => '',
				],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'excerpt_typography',
                'selector' => '{{WRAPPER}} .studio-post-excerpt',
                'condition' => [
					'show_excerpt!' => '',
				],
            ]
        );

        $this->add_control(
            'readmore_color',
            [
                'label'     => esc_html__( 'More Details Color', 'leadcon' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .studio-readmore' => 'color: {{VALUE}}',
                ],
                'default' => '#9e8157',
                'condition' => [
					'show_readmore!' => '',
				],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'readmore_typography',
                'selector' => '{{WRAPPER}} .studio-readmore',
                'condition' => [
					'show_readmore!' => '',
				],
            ]
        );

        $this->add_control(
            'bg_color_detail',
            [
                'label'     => esc_html__( 'Background Color Details', 'leadcon' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#fff',
                'selectors' => [
                    '{{WRAPPER}} .studio-entry-header' => 'background-color: {{VALUE}}',
                ],
                'condition' => [
					'style_layout!' => '1',
				],
            ]
        );



        $this->end_controls_section();
	}

	/**
	 * Render landing image widget output on the front end.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 *
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$layout = $settings['style_layout'];
		$column  = $settings['columns'];
		$show_excerpt = $settings['show_excerpt'];
		$show_readmore = $settings['show_readmore'];
		$slide_show = $settings['columns_show'];

        $args = array(
            'post_type' => 'ht-studio',
            'ignore_sticky_posts' => 1,
			'posts_per_page' => $settings['products_per_page'],
			'order' => $settings['order'],
			'orderby' => $settings['order_by']
        );

        $posts = new WP_Query( $args );
        ?>
			<div class="swiper-container filmic-studio-widgets filmic-studio-layout-<?php echo esc_attr( $layout ); ?>" <?php if( '1' == $layout ) { ?> data-columns_desk="<?php echo esc_attr( $slide_show ); ?>" <?php } ?>>
				<div class="swiper-wrapper filmic-studio-wrapp filmic-studio-columns-<?php echo esc_attr( $column ); ?>">
					<?php
						while ( $posts->have_posts() ) :
				        	$posts->the_post();
				        	?>
				        		<div id="post-<?php the_ID(); ?>" class="ht-grid-item post post-item swiper-slide">
			                        <div class="studio-entry-thumbnail">
			                            <a href="<?php echo esc_url( the_permalink() ); ?>">
			                                <?php if ( has_post_thumbnail() ): ?>
			                                    <?php the_post_thumbnail(); ?>
			                                <?php endif ?>
			                            </a>
			                        </div>
			                        <!-- Thumbnail -->

			                        <div class="studio-entry-header">
			                            <div class="studio-post-title">
			                                <h2 class="entry-title">
			                                <a href="<?php echo esc_url( the_permalink() ); ?>"><?php echo get_the_title(); ?></a>
			                                </h2>
			                            </div>
			                            <?php
			                            	if ( 'yes' == $show_excerpt ) {
			                            		?>
			                            			<div class="studio-post-excerpt">
						                                <?php echo the_excerpt(); ?>
						                            </div>
			                            		<?php
			                            	}
			                            ?>
			                            <!-- .entry-description -->

			                            <?php
			                            	if( 'yes' == $show_readmore ) {
			                            		?>
													<div class="read-more">
						                            	<a href="<?php echo esc_url( the_permalink() ); ?>" class="studio-readmore"><?php echo esc_html__( 'More Details' ) ?></a>
						                           		<span class="ion-ios-arrow-thin-right read-more-icon"></span>
						                            </div>
			                            		<?php
			                            	}
			                            ?>
			                            <!-- More details -->
			                        </div>
				                </div>
				        	<?php
				        endwhile;
					?>
				</div>
				<!-- Studio-widget -->
				<div class="swiper-scrollbar swiper-scrollbar"></div>
			</div>
        <?php
        wp_reset_postdata();
	}
}

