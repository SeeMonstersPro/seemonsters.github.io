<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

/**
 * Filmic Project widget.
 *
 * Filmic widget that displays an project widget for page.
 *
 * @since 1.0.0
 */

class Filmic_Project_Slider extends Widget_Base {
	/**
	 * Get widget name.
	 *
	 * Retrieve landing image widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'filmic-project-slider';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve landing image widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Project Slider', 'filmic' );
	}

		/**
	 * Get widget icon.
	 *
	 * Retrieve landing image widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-slider-video';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the icon widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'filmic-theme' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'filmic-project-slider' );
	}

	/**
	 * Register category box widget controls.
	 *
	 * Add different input fields to allow the user to change and customize the widget settings
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		$this->start_controls_section(
			'section_project',
			[
				'label' => esc_html__( 'Content', 'filmic' ),
			]
		);

        $this->add_control(
			'product_cat',
			array(
				'label'     => esc_html__( 'Categories', 'miini' ),
				'type'      => Controls_Manager::SELECT2,
				'options'   => filmic_get_narrow_data( 'term', 'ht-project-category' ),
				'multiple'  => true,
			)
		);

		$this->add_control(
			'products_per_page',
			array(
				'label' => esc_html__( 'Post Per Page', 'filmic' ),
				'type'  => Controls_Manager::NUMBER,
				'default' => 4
			)
		);

		$this->add_control(
			'order',
			array(
				'label' => esc_html__( 'Order', 'filmic' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'ASC' => esc_html__( 'ASC', 'filmic' ),
					'DESC' => esc_html__( 'DESC', 'filmic' )
				],
				'default' => 'DESC'
			)
		);

		$this->add_control(
			'order_by',
			[
				'label' => esc_html__( 'Order By', 'filmic' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'ID' => esc_html__( 'ID', 'filmic' ),
					'date' => esc_html__( 'Date', 'filmic' ),
					'title' => esc_html__( 'Title', 'filmic' ),
					'rand' => esc_html__( 'Rand', 'filmic' )
				],
				'default' => 'ID'
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_style',
            [
                'label' => esc_html__( 'Style', 'filmic' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => esc_html__( 'Title Color', 'filmic' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-title a' => 'color: {{VALUE}}',
                ],
                'default' => '#9e8157'
            ]
        );
        $this->add_control(
            'title_color_hover',
            [
                'label'     => esc_html__( 'Title Color Hover', 'filmic' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .project-title a:hover' => 'color: {{VALUE}}',
                ],
                'default' => '#ffffff'
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'readmore_typography',
                'selector' => '{{WRAPPER}} .project-cat a',
            ]
        );

        $this->end_controls_section();
	}

	/**
	 * Render Project widget output on the front end.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 *
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$cat_id   = $settings['product_cat'];

		$args = array(
            'post_type' => 'ht-project',
            'ignore_sticky_posts' => 1,
			'posts_per_page' => $settings['products_per_page'],
			'order' => $settings['order'],
			'orderby' => $settings['order_by']
        );

        if ( ! empty( $cat_id ) ) :
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'ht-project-category',
					'field'    => 'term_id',
					'terms'    => $cat_id,
				),
			);
		endif;


        $posts = new WP_Query( $args );


        ?>
			<div class="filmic-project-slider">
				<div class="filmic-project-wrapp js-project-slider">
					<?php
						while ( $posts->have_posts() ) :
					        	$posts->the_post();

					        	$trailer = fw_get_db_post_option( get_the_ID(), 'trailer');
	            				$description = fw_get_db_post_option( get_the_ID(), 'description' );

					        	$pid  = get_the_ID();
		                        $taxs = get_the_terms( $pid, 'ht-project-category' );
		                        $btn_link = fw_get_db_post_option( get_the_ID(), 'btn_link', '#');
				                $btn_label = fw_get_db_post_option( get_the_ID(), 'btn_label');
				                $info = fw_get_db_post_option( get_the_ID(), 'infomation');

					        ?>
								<div class="project-item-slider">
									<div class="project-head">
										<a href="<?php echo esc_url( the_permalink() ); ?>">
											<?php if ( has_post_thumbnail() ): ?>
			                                    <?php the_post_thumbnail(); ?>
			                                <?php endif ?>
										</a>
									</div>
									<!-- project-head -->
									<div class="project-sum">
										<h3 class="project-title">
											<a href="<?php echo esc_url( the_permalink() ); ?>"><?php echo get_the_title(); ?></a>
										</h3>
										<!-- project-title -->
										<dl class="project-info">
											<?php
												if( ! empty( $info ) ){
					                                foreach( $info as $key ){
						                				?>
						                            		<dt><?php echo esc_html( $key['pro_name'] ); ?></dt>
						                            		<dd><?php echo esc_html( $key['pro_value'] ); ?></dd>
						                        		<?php
						                        	}
						                        }
											?>
										</dl>
										<!-- prject-info -->
										<p class="project-description"><?php echo esc_html( $description ); ?></p>
										<!-- project-descriptions -->
										<a href="<?php echo esc_url( $trailer ); ?>" class="project-trailer-normal-btn" data-lity> <?php echo esc_html__( 'Watch Trailer', 'filmic' ); ?> </a>
										<a href="<?php echo esc_url( $btn_link ); ?>" class="project-buy-btn"><?php echo esc_html( $btn_label ); ?> </a>
									</div>
									<!-- project-sum -->
								</div>
								<!-- Project Slider -->
							<?php
						endwhile;
					?>
				</div>
				<!-- Project wrapp -->
			</div>
			<!-- Filmic project slider -->
        <?php
        wp_reset_postdata();
	}
}