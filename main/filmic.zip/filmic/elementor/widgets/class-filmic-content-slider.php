<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use ELementor\Group_Control_Background;

/*****************  Filmic Slider Content widget. */

class Filmic_Content_Slider extends Widget_Base {
	/*  Get widget name. */
	public function get_name() {
		return 'filmic_content_slider';
	}
    /*  Get widget title. */
	public function get_title() {
		return esc_html__( 'Content Slider', 'filmic' );
	}
	 /* Get widget icon. */
	public function get_icon() {
		return 'eicon-slider-vertical';
	}
	/*  Get widget categories. */
	public function get_categories() {
		return [ 'filmic-theme' ];
	}
	/* Widget scripts dependencies. */
	public function get_script_depends() {
		return array( 'filmic-content-slider-scripts' );
    }

    /************************** Function. *****************************************************/
    public function get_saved_data( $type = 'page' ) {
        $saved_widgets = $this->get_post_template( $type );
        $options = array();
        $options[-1]   = esc_html__( 'Have no template.', 'filmic' );
        if ( count( $saved_widgets ) ) {
            unset($options); 
            foreach ( $saved_widgets as $saved_row ) {
                $options[ $saved_row['id'] ] = $saved_row['name'];
            }
        }
        return $options;
    }
    public function get_post_template( $type = 'page' ) {
        $posts = get_posts(
            array(
                'post_type'      => 'elementor_library',
                'orderby'        => 'title',
                'order'          => 'ASC',
                'posts_per_page' => '-1',
                'tax_query'      => array(
                    array(
                        'taxonomy' => 'elementor_library_type',
                        'field'    => 'slug',
                        'terms'    => $type,
                    ),
                ),
            )
        );
        $templates = array();
        foreach ( $posts as $post ) {

            $templates[] = array(
                'id'   => $post->ID,
                'name' => $post->post_title,
            );
        }
        return $templates;
    }
    /**
     ************************************ Render content type list.
     */
    public function get_content_type() {
        $content_type = array(
            'content'    => esc_html__( 'Content', 'filmic' ),
            'saved_template' => esc_html__( 'Saved Section', 'filmic' ),
        );
        return $content_type;
    }
    /**
     * Render button widget classes names.
     */
    public function get_modal_content( $item, $node_id, $section ) {
        $content_type   = $item[ $section ];
        if ( 'rbs_select_section' === $section ) {
            switch ( $content_type ) {
                case 'content':
                    global $wp_embed;
                    return '<div>' . wpautop( $wp_embed->autoembed( $item['section_content_normal'] ) ) . '</div>';
                break;
                case 'saved_template':
                    return \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $item['section_saved_template'] );
                break;
                default:
                    return;
                break;
            }
        }
    }
    /**
	 * Register category box widget controls.
	 *
	 * Add different input fields to allow the user to change and customize the widget settings
	 *
	 */
	protected function _register_controls() {
        // Rbs heading section starts.
        $this->start_controls_section(
            'rbs_section_content_1',
            [
                'label' => esc_html__( 'Content', 'filmic' ),
            ]
        );

        $repeater = new Elementor\Repeater();
        $this->add_control(
			'section_position',
			[
				'label'   => __( 'Height', 'filmic' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'absolute',
				'options' => [
					'fixed'     => esc_html__( 'Fit to Screen', 'filmic' ),
					'absolute'  => esc_html__( 'Custom', 'filmic' ),
                ],
			]
        );
        $this->add_responsive_control(
			'section_min_height',
			[
				'label' => __( 'Height', 'filmic' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1200,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 700,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 300,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 200,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .section-absolute' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'section_position' => 'absolute',
                ],
			]
		);
        // Rbs content section 
        $repeater->add_control(
            'rbs_select_section',
            [
                'label'   => esc_html__( 'Section', 'filmic' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'content',
                'options' => $this->get_content_type(),
            ]
        );
        // Rbs content section - content.
        $repeater->add_control(
            'section_content_normal',
            [
                'label'      => esc_html__( 'Description', 'filmic' ),
                'type'       => Controls_Manager::WYSIWYG,
                'default'    => esc_html__( '', 'filmic' ),
                'rows'       => 10,
                'show_label' => false,
                'dynamic'    => [
                    'active' => true,
                ],
                'condition'  => [
                    'rbs_select_section' => 'content',
                ],
            ]
        );
        // Rbs content section 1 - template.
        $repeater->add_control(
            'section_saved_template',
            [
                'label'     => esc_html__( 'Select Section', 'filmic' ),
                'type'      => Controls_Manager::SELECT,
                'options'   => $this->get_saved_data( 'section' ),
                'default'   => '-1',
                'condition' => [
                    'rbs_select_section' => 'saved_template',
                ],
            ] 
        );
        $this->add_control(
            'sections_slider',
            [
                'label'   => esc_html__( 'Section List', 'filmic' ),
                'type'    => Controls_Manager::REPEATER,
                'fields'  => $repeater->get_controls(),
                'default' => [
                    [   
                        [],
                        [],
                        []
                    ],
                ],
                'title_field' => '{{{ name }}}',
            ]
        );
        $this->add_control(
			'slider_dots_heading',
			[
				'label' => __( 'Dots', 'filmic' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
            'slider_allow_dots',
            [
                'label'        => esc_html__( 'Allow ', 'filmic' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'label_on'     => esc_html__( 'Yes', 'filmic' ),
                'label_off'    => esc_html__( 'No', 'filmic' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
			'sldier_dots_direction',
			[
				'label'      => esc_html__( 'Direction', 'filmic' ),
				'type'       => Controls_Manager::CHOOSE,
				'options'    => [
					'row'   => [
						'title' => esc_html__( 'Horizontal', 'filmic' ),
						'icon'  => 'eicon-h-align-right',
					],
					'column' => [
						'title' => esc_html__( 'Vertical', 'filmic' ),
						'icon'  => 'eicon-v-align-bottom',
					],
				],
				'default'    => 'row',
				'selectors'  => [
					'{{WRAPPER}} .content-slider-pagination' => 'flex-direction: {{VALUE}}',
				]
			]
		);
        $this->end_controls_section();
        $this->start_controls_section(
			'dots_style',
			[
				'label' => esc_html__( 'Dots', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE
			]
        );
        $this->add_control(
			'dots_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9E8157',
				'selectors' => [
					'{{WRAPPER}} .content-slider-pagination span' => 'background-color: {{VALUE}}',
				]
			]
        );
        $this->add_control(
			'dots_color_active',
			[
				'label'     => esc_html__( 'Color Active', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .content-slider-pagination .swiper-pagination-bullet-active' => 'background-color: {{VALUE}}',
				]
			]
        );
        $this->add_responsive_control(
			'dots_dismen',
			[
				'label'    	 => __( 'Margin', 'filmic' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'	 => [
					'top' 		=> '0',
					'right' 	=> '5',
					'bottom'	=> '0',
					'left'		=> '5',
					'unit'		=> 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .content-slider-pagination span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
			]
        );
        $this->add_responsive_control(
			'content_dots_top',
			[
				'label' => __( 'Top', 'filmic' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 50,
				],
				'selectors' => [
					'{{WRAPPER}} .content-slider-pagination' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
        );
        $this->add_responsive_control(
			'content_dots_right',
			[
				'label' => __( 'Right', 'filmic' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => 'px',
					'size' => 70,
				],
				'selectors' => [
					'{{WRAPPER}} .content-slider-pagination' => 'right: {{SIZE}}{{UNIT}};',
				],
			]
		);
        $this->end_controls_section();
    }
    /**
     * Render
     */   
    protected function render() {
        $settings  = $this->get_settings();
        $node_id   = $this->get_id();
        $slider_allow_dots  = ( 'yes' === $settings['slider_allow_dots'] ) ? '' : 'content-slider-pagination--hide' ;
        $section_position   = ( 'absolute' === $settings['section_position'] ) ? 'section-absolute' : 'section-fixed' ;
        ?>
        <div class="filmic-slider-section-wrapper">
            <div class="filmic-slider-section <?php echo esc_attr( $section_position ) ?>">
                <div class="swiper-container">   
                    <div class="swiper-wrapper">
                    <?php foreach ( $settings['sections_slider'] as $item ) : ?>
                        <div class="swiper-slide" id="section-<?php echo esc_attr( $item['_id'] ); ?>">
                            <?php echo do_shortcode( $this->get_modal_content( $item, $item['_id'], 'rbs_select_section' ) ); ?>
                        </div>
                    <?php endforeach ?>
                    </div>
                </div>
                <?php  ?>
                <div class="content-slider-pagination <?php echo esc_attr( $slider_allow_dots ); ?>"></div>
            </div>
        </div>
        <?php
        wp_reset_postdata();
    }
}