<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Filmic testimonial widget.
 *
 * Filmic widget that displays testimonial page.
 *
 * @since 1.0.0
 */

class Filmic_Blog extends Widget_Base {
	/**
	 * Get widget name.
	 *
	 * Retrieve testimonial widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'filmic_blog';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve testimonial widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Blog', 'filmic' );
	}

		/**
	 * Get widget icon.
	 *
	 * Retrieve testimonial widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-list';
	} 
	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the icon widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'filmic-theme' ];
	}
	/**
	 * Register category box widget controls.
	 *
	 * Add different input fields to allow the user to change and customize the widget settings
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
		// layout.
		$this->start_controls_section(
			'section_blog',
		   	 array(
				'label' => esc_html__( 'Blog', 'filmic' ),
			)
		);
		$this->add_control(
			'blog_post_per_page',
			[
				'label'   => esc_html__( 'Posts Per Page', 'filmic' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3
			]
		);
		$this->add_control(
			'blog_layout',
			[
				'label'		=> __( 'Layout Style', 'filmic' ),
				'type'		=> \Elementor\Controls_Manager::SELECT,
				'default'	=> 'filmic-blog--list',
				'options' 	=> [
					'filmic-blog--list'	=> esc_html__( 'List', 'filmic' ),
					'filmic-blog--2-col'	=> esc_html__( '2 columns', 'filmic' ),
					'filmic-blog--3-col'	=> esc_html__( '3 columns', 'filmic' ),
				],
			]
		);
		$this->add_control(
			'blog_allow_pagination',
			[
				'label'        => esc_html__( 'Pagination', 'filmic' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'on'           => esc_html__( 'No', 'filmic' ),
				'off'          => esc_html__( 'Yes', 'filmic' ),
				'return_value' => 'yes',
			]
		);
		$this->end_controls_section();
		// Blog Item.
		$this->start_controls_section(
			'post_item',
			array(
				'label' => esc_html__( 'Post Item', 'filmic' )
			)
		);
		$this->add_control(
            'post_direction',
            [
                'label' => esc_html__( 'Direction', 'filmic' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'filmic-post-horizontal' => [
                        'title' => esc_html__( 'Horizontal', 'filmic' ),
                        'icon'  => 'ion-android-more-horizontal',
                    ],
                    'filmic-post-vertical' => [
                        'title' => esc_html__( 'Vertical', 'filmic' ),
                        'icon'  => 'ion-android-more-vertical',
                    ],
                ],
				'default' => 'filmic-post-vertical',
				'condition' =>[
					'blog_layout' => 'filmic-blog--list',
				],
            ]
		);
		$this->add_control(
			'show-thumb',
			[
				'label'        => esc_html__( 'Show Thumb', 'filmic' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'filmic' ),
				'label_off'    => esc_html__( 'No', 'filmic' ),
				'return_value' => 'yes',
			]
		);
		$this->add_control(
			'show-date',
			[
				'label'        => esc_html__( 'Show Date', 'filmic' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'filmic' ),
				'label_off'    => esc_html__( 'No', 'filmic' ),
				'return_value' => 'yes',
			]
		);
		$this->add_control(
			'show-content',
			[
				'label'        => esc_html__( 'Show Content', 'filmic' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'yes',
				'label_on'     => esc_html__( 'Yes', 'filmic' ),
				'label_off'    => esc_html__( 'No', 'filmic' ),
				'return_value' => 'yes',
			]
		);
		$this->add_control(
			'blog_content_limit',
			[
				'label'       => esc_html__( 'Excerpt Limit', 'filmic' ),
				'type'        => Controls_Manager::NUMBER,
				'default'	  => 35,
			]
		);
		$this->add_responsive_control(
			'blog_item_spacing',
			[
				'label'     => __( 'Item Spacing', 'filmic' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 30,
				],
				'range'     => [
					'px'   => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__border' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// Sticky post.
		$this->start_controls_section(
			'section_blog_sticky',
				array(
				'label' => esc_html__( 'Sticky Post', 'filmic' ),
			)
		);
		$this->add_control(
			'blog_allow_sticker',
			[
				'label'        => esc_html__( 'Enable', 'filmic' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'on'           => esc_html__( 'No', 'filmic' ),
				'off'          => esc_html__( 'Yes', 'filmic' ),
				'return_value' => 'yes',
			]
		);
		$this->add_control(
			'sticker_post_width',
			[
				'label' 	=> __( 'Width', 'filmic' ),
				'type' 		=> \Elementor\Controls_Manager::SELECT,
				'default' 	=> 'full',
				'options' 	=> [
					'full'  				=> __( 'Full width', 'filmic' ),
					'half' 					=> __( 'Half width', 'filmic' ),
				],
				'condition'	=>[
					'blog_allow_sticker'	=>'yes',
					'blog_layout'			=>'filmic-blog--2-col',
				]

			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'blog_sticky_border',
				'label' => __( 'Border', 'filmic' ),
				'selector' => '{{WRAPPER}} .blog-sticky-post .filmic-blog-item__border',
				'condition'	=>[
					'blog_allow_sticker'	=>'yes',
				]
			]
		);
		$this->add_responsive_control(
			'blog_wrapper_sticky_spacing',
			[
				'label'    	 => __( 'Padding', 'filmic' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'	 => [
					'top' 		=> '0',
					'right' 	=> '0',
					'bottom' 	=> '43',
					'left' 		=> '0',
					'unit'	 	=> 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .blog-sticky-post .filmic-blog-item__description ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} 0 {{LEFT}}{{UNIT}} !important;',
					'{{WRAPPER}} .blog-sticky-post .filmic-blog-item__border ' => 'padding-bottom: {{BOTTOM}}{{UNIT}}',
				],
				'condition'	=>[
					'blog_allow_sticker'	=>'yes',
				]
			]
		);
		$this->end_controls_section();
		// Query.
		$this->start_controls_section(
			'section_blog_filter',
				array(
				'label' => esc_html__( 'Query', 'filmic' ),
			)
		);
		$this->add_control(
			'blog_order_by',
			[
				'label'		=> __( 'Order By', 'filmic' ),
				'type'		=> \Elementor\Controls_Manager::SELECT,
				'default'	=> 'modified',
				'options' 	=> [
					'ID'		=> esc_html__( 'ID', 'filmic' ),
					'name'		=> esc_html__( 'Name', 'filmic' ),
					'title'		=> esc_html__( 'Title', 'filmic' ),
					'date'		=> esc_html__( 'Date', 'filmic' ),
					'modified'	=> esc_html__( 'Modified', 'filmic' ),
					'none'		=> esc_html__( 'Category', 'filmic' ),
				],
			]
		);
		$this->add_control(
			'blog_order_type',
			[
				'label'		=> __( 'Order', 'filmic' ),
				'type'		=> \Elementor\Controls_Manager::SELECT,
				'default'	=> 'ASC',
				'options' 	=> [
					'DESC'	=> esc_html__( 'DESC', 'filmic' ),
					'ASC'	=> esc_html__( 'ASC', 'filmic' ),
				],
			]
		);
		$this->add_control(
			'blog_filter',
			[
				'label' 	=> __( 'Category', 'filmic' ),
				'type'		=> \Elementor\Controls_Manager::SELECT,
				'default' 	=> '',
				'options' 	=> filmic_catelist('post'),
				'condition' => [
					'blog_order_by'	=> 'none',
				],
			]
		);
		$this->end_controls_section();
		// item wrapper.
		$this->start_controls_section(
			'wapper_style',
			[
				'label' => esc_html__( 'Post Item', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_control(
			'post_wrapper_contain',
			[
				'label' => __( 'Wrapper', 'filmic' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'blog_item_background_color',
			[
				'label'     => esc_html__( 'Background Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#transparent',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__border' => 'background-color: {{VALUE}};',
				]
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'wrapper_border',
				'label' => __( 'Border', 'filmic' ),
				'selector' => '{{WRAPPER}} .filmic-blog-item__border',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'post_box_shadow',
				'label' => __( 'Box Shadow', 'filmic' ),
				'selector' => '{{WRAPPER}} .filmic-blog-item__border',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' 		=> 'post_box_shadow_hover',
				'label' 	=> __( 'Box Shadow', 'filmic' ),
				'selector' 	=> '{{WRAPPER}} .filmic-blog-item__border-hover:hover',
				'condition' => [
					'post_hover' => 'yes',
				],
			]
		);
		$this->add_control(
			'description_contain',
			[
				'label' => __( 'Descriptions', 'filmic' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			'blog_wrapper_spacing',
			[
				'label'    	 => __( 'Padding', 'filmic' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'	 => [
					'top' 		=> '0',
					'right' 	=> '0',
					'bottom' 	=> '0',
					'left' 		=> '0',
					'unit'	 	=> 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .filmic-blog-item:not(.blog-sticky-post) .filmic-blog-item__description ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} 0 {{LEFT}}{{UNIT}} !important;',
					'{{WRAPPER}} .filmic-blog-item:not(.blog-sticky-post) .filmic-blog-item__border ' => 'padding-bottom: {{BOTTOM}}{{UNIT}}',
				],
			]
		);
		$this->add_control(
			'post_hover_contain',
			[
				'label' => __( 'Hover', 'filmic' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'post_hover',
			[
				'label'        => esc_html__( 'Enable', 'filmic' ),
				'type'         => Controls_Manager::SWITCHER,
				'default'      => 'no',
				'on'           => esc_html__( 'No', 'filmic' ),
				'off'          => esc_html__( 'Yes', 'filmic' ),
				'return_value' => 'yes',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' 		=> 'wrapper_border_hover',
				'label'  	=> __( 'Border', 'filmic' ),
				'selector'  => '{{WRAPPER}} .filmic-blog-item__border-hover:hover',
				'condition' => [
					'post_hover' => 'yes',
				],
			]
		);
		$this->end_controls_section();
		//date
		$this->start_controls_section(
			'tab_blog_style',
			[
				'label' 	=> esc_html__( 'Date', 'filmic' ),
				'tab'   	=> Controls_Manager::TAB_STYLE,
				'condition' => [
					'show-date' => 'yes',
				]
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'date_typo',
				'label'     => esc_html__( 'Date Typo', 'filmic' ),
				'selector' => '{{WRAPPER}} .filmic-blog-item__description__date .entry-date'
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'month_typo',
				'label'     => esc_html__( 'Month Typo', 'filmic' ),
				'selector' => '{{WRAPPER}} .filmic-blog-item__description__date .entry-month'
			]
		);
		$this->add_control(
			'blog_date_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__date .entry-time' => 'color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'blog_date_brg_color',
			[
				'label'     => esc_html__( 'Background Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__date .entry-time' => 'background-color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'blog_date_border_color',
			[
				'label'     => esc_html__( 'Border', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__date .entry-time' => 'border: 1px solid {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'date_hover_contain',
			[
				'label' => __( 'Hover', 'filmic' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'blog_date_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9e8157',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__date .entry-time:hover' => 'color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'blog_date_brg_hover',
			[
				'label'     => esc_html__( 'Background Hover Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__date .entry-time:hover' => 'background-color: {{VALUE}};',
				]
			]
		);
		$this->add_control(
			'blog_date_border_color_hover',
			[
				'label'     => esc_html__( 'Border', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__date .entry-time:hover' => 'border: 1px solid {{VALUE}};'
				]
			]
		);
		$this->end_controls_section();
		// category.
		$this->start_controls_section(
			'category_style',
			[
				'label' => esc_html__( 'Category', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_control(
			'category_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__entry-header__category' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'category_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9e8157',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__entry-header__category a:hover' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'category_typo',
				'selector' => '{{WRAPPER}} .filmic-blog-item__description__entry-header__category'
			]
		);
		$this->add_responsive_control(
			'category_distance',
			[
				'label'     => __( 'Distance', 'filmic' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 7,
				],  
				'range'     => [
					'px'   => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__entry-header__category' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// tittle.
		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#292929',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__entry-header__title' => 'color: {{VALUE}}'
				]
			]
		);
		$this->add_control(
			'title_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9e8157',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__entry-header__title a:hover' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typo',
				'selector' => '{{WRAPPER}} .filmic-blog-item__description__entry-header__title'
			]
		);
		$this->add_responsive_control(
			'title_distance',
			[
				'label'     => __( 'Distance', 'filmic' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 16,
				],
				'range'     => [
					'px'   => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__entry-header__title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// content.
		$this->start_controls_section(
			'content_style',
			[
				'label' => esc_html__( 'Exceprt', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'content_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__entry-header__content' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => '_typo',
				'selector' => '{{WRAPPER}} .filmic-blog-item__description__entry-header__content'
			]
		);
		$this->add_responsive_control(
			'content_distance',
			[
				'label'     => __( 'Distance', 'filmic' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 25,
				],
				'range'     => [
					'px'   => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-item__description__entry-header__content' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		// readmore.
		$this->start_controls_section(
			'readmore_style',
			[
				'label'		=> esc_html__( 'Continue', 'filmic' ),
				'tab'   	=> Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'readmore_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9e8157',
				'selectors' => [
					'{{WRAPPER}}  .filmic-blog-item__description__entry-header .read-more-link' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .filmic-blog-item__description__entry-header .read-more-icon' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'readmore_color_hover',
			[
				'label'     => esc_html__( 'Color Hover', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9e8157',
				'selectors' => [
					'{{WRAPPER}}  .filmic-blog-item__description__entry-header .read-more:hover .read-more-link' => 'color: {{VALUE}}',
					'{{WRAPPER}}  .filmic-blog-item__description__entry-header .read-more:hover .read-more-icon' => 'color: {{VALUE}}',
				]
			]
		);
		$this->end_controls_section();
		// pagination.
		$this->start_controls_section(
			'tab_pagination_style',
			[
				'label' 	=> esc_html__( 'Pagination', 'filmic' ),
				'tab'   	=> Controls_Manager::TAB_STYLE,
				'condition' =>[
					'blog_allow_pagination' => 'yes',
				],
			]
		);
		$this->add_control(
			'blog_pagination_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8F8F8F',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-widget__wrapper a.page-numbers ' => 'color: {{VALUE}};border: 1px solid {{VALUE}};',
					'{{WRAPPER}} .filmic-blog-widget__wrapper span.dots' => 'color: {{VALUE}};border: 1px solid {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'blog_pagination_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-widget__wrapper a.page-numbers:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .filmic-blog-widget__wrapper span.dots:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .filmic-blog-widget__wrapper span.current' => 'color: {{VALUE}};'
				]
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'blog_pagination_boder',
				'label' => __( 'Border', 'filmic' ),
				'selector' => '{{WRAPPER}} .filmic-blog-widget__wrapper .ht-pagination',
				
			]
		);
		$this->add_control(
			'blog_pagination_brg_color',
			[
				'label'     => esc_html__( 'Background Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-widget__wrapper a.page-numbers' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .filmic-blog-widget__wrapper span.dots' => 'background-color: {{VALUE}};'
				]
			]
		);
		$this->add_control(
			'blog_pagination_brg_hover',
			[
				'label'     => esc_html__( 'Background Hover Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9E8157',
				'selectors' => [
					'{{WRAPPER}} .filmic-blog-widget__wrapper a.page-numbers:hover' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .filmic-blog-widget__wrapper span.page-numbers:hover' => 'background-color: {{VALUE}};',
				]
			]
		);
		$this->add_responsive_control(
			'blog_pagination_margin',
			[
				'label'    	 => __( 'Padding', 'filmic' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'	 => [
					'top' 		=> '50',
					'right' 	=> '0',
					'bottom' 	=> '0',
					'left' 		=> '0',
					'unit'	 	=> 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .filmic-blog-widget__wrapper .ht-pagination' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
			]
		);	
		$this->end_controls_section();
	}
	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */

	protected function render() {
		$settings       = $this->get_settings_for_display();
		$paged          = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
		//blog layout variable
		$limited        = $settings['blog_post_per_page'];
		$blog_layout    = $settings['blog_layout'];
		$item_col       = ( $blog_layout == 'filmic-blog--list' ) ? 'col-lg-12' : ( ( $blog_layout == 'filmic-blog--2-col' ) ? 'col-lg-6' : 'col-lg-4' );
		$allow_sticker  = $settings['blog_allow_sticker'];
		$ignore_sticky 	= ( 'yes' === $allow_sticker ) ? false : true;
		$pagination     = $settings['blog_allow_pagination'];
		$two_col_sticky = ( 'half' === $settings['sticker_post_width'] ) ? 'blog--2-col-has-sticky' : '';
		// post-item variable.
		$show_content   = ( 'yes' === $settings['show-content'] ) ? '' : 'blog-hide-content';
		$content_limit  = $settings['blog_content_limit'];
		$show_thumb     = ( 'yes' === $settings['show-thumb'] ) ? '' : 'blog-hide-thumb';
		$show_date  	= $settings['show-date'];
		$post_hover     = ( 'yes' === $settings['post_hover'] ) ? 'filmic-blog-item__border-hover' : '';
		// filter variables. 
		$blog_cate_filter 	= $settings['blog_filter'];
		$blog_order_by 	= $settings['blog_order_by'];
		$order_type = $settings['blog_order_type'];
		$args = array (
			'post_type'				=> 'post',
			'posts_per_page'		=> $limited,
			'paged'					=> $paged,
			'ignore_sticky_posts' 	=> $ignore_sticky ,
			'category_name'			=> $blog_cate_filter,
			'orderby' 				=> $blog_order_by,  
			'order' 				=> $order_type, 
		);
		$posts = new WP_Query( $args );
		$total_page = $posts->max_num_pages;
		?>
		<div class="filmic-blog-widget__wrapper">
			<div class="filmic-blog-widget row <?php echo esc_attr( $blog_layout.' '.$two_col_sticky ); ?>">
				<?php
				while ( $posts->have_posts() ) :
					$posts->the_post();	
					/* Differ sticky post col & style variable. */
					$item_direction	= ( is_sticky() && 'yes' === $allow_sticker ) ? 'filmic-post-vertical' : $settings['post_direction'];
					if( is_sticky() && 'filmic-blog--list' === $blog_layout ){
						/* stick in list layout */
						$stick_condition_col = 'blog-sticky-post col-lg-12';
					} elseif ( is_sticky() && 'filmic-blog--2-col' === $blog_layout ) {
						/* stick in 2 cols layout */
						$stick_condition_col = ( 'half' === $settings['sticker_post_width'] ) ? 'blog-sticky-post col-lg-6' : 'blog-sticky-post col-lg-12' ;
					} elseif ( is_sticky() && 'filmic-blog--3-col' === $blog_layout ) {
						/* stick in 4col layout */
						$stick_condition_col = 'blog-sticky-post col-lg-12';
					} else {
						$stick_condition_col = $item_col;
					}
					$final_col	=  ( 'yes' === $allow_sticker ) ? $stick_condition_col : $item_col;
				?>
					<div id="post-<?php the_ID(); ?>" class="filmic-blog-item <?php echo esc_attr( $final_col ); ?>">
						<div class="filmic-blog-item__border <?php echo esc_attr( $post_hover.' '.$item_direction ); ?>">
							<?php if (has_post_thumbnail() ) : ?>
								<a href="<?php echo esc_url( the_permalink() ); ?>" class="filmic-blog-item__thumb <?php echo esc_attr( $show_thumb ); ?>">
									<?php the_post_thumbnail(); ?>
								</a>
							<?php endif ?>
							<div class="filmic-blog-item__description">
								<div class="filmic-blog-item__description__date">
									<?php 
										if( 'yes' === $show_date )	filmic_entry_time();
									?>
								</div>
								<div class="filmic-blog-item__description__entry-header">
									<div class="filmic-blog-item__description__entry-header__category">				
										<?php
											esc_html( the_category( ', ' ) );
										?>
									</div>
									<h6 class="filmic-blog-item__description__entry-header__title">
										<a href="<?php echo esc_url( the_permalink() ); ?>"><?php esc_html( the_title()); ?></a>	
									</h6>
									<div class="filmic-blog-item__description__entry-header__content <?php echo esc_attr( $show_content ); ?>">
										<?php 
											echo esc_html( wp_trim_words( get_the_content( get_the_ID() ) , $content_limit, null ) ); 
										?>
									</div>
									<?php 
										filmic_grid_excerpt(); 
									?>
								</div>
							</div>
						</div>
					</div>
				<?php endwhile; ?>	
			</div>
			<?php 
				if( 'yes' === $pagination )	filmic_paging( $posts );	 
			?>
		</div>
		<?php  
		wp_reset_postdata();
	}
}
