<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

/*****************  Filmic Gallery widget. */

class Filmic_Gallery extends Widget_Base {
	/*  Get widget name. */
	public function get_name() {
		return 'filmic_gallery';
	}
    /*  Get widget title. */
	public function get_title() {
		return esc_html__( 'Gallery', 'filmic' );
	}
	 /* Get widget icon. */
	public function get_icon() {
		return 'eicon-gallery-grid';
	}
	/*  Get widget categories. */
	public function get_categories() {
		return [ 'filmic-theme' ];
	}
	/* Widget scripts dependencies. */
	public function get_script_depends() {
		return array( 'filmic-gallery-scripts' );
    }
    /**
	 * Register category box widget controls.
	 *
	 * Add different input fields to allow the user to change and customize the widget settings
	 *
	 */
	protected function _register_controls() {
		// Labels
		$this->start_controls_section(
			'section_gallery',
			array(
				'label' => esc_html__( 'Gallery', 'filmic' ),
			)
		);
		$this->add_control(
			'column',
			[
				'label' 	=> esc_html__( 'Columns', 'filmic' ),
				'type' 		=> \Elementor\Controls_Manager::SELECT,
				'default' 	=> '2-columns',
				'options' 	=> [
					'2-columns'	=> esc_html__( '2 columns', 'filmic' ),
					'3-columns'	=> esc_html__( '3 columns', 'filmic' ),
					'4-columns'	=> esc_html__( '4 columns', 'filmic' ),
				],
			]
		);
		$this->add_control(
            'allow_filter',
            [
                'label'        => esc_html__( 'Filter ', 'filmic' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'label_on'     => esc_html__( 'Yes', 'filmic' ),
                'label_off'    => esc_html__( 'No', 'filmic' ),
                'return_value' => 'yes',
            ]
		);
		$repeater = new Elementor\Repeater();
		$repeater->add_control(
			'label',
			[
				'label'       => esc_html__( 'Label', 'filmic' ),
				'description' => esc_html__( 'Add label for widget filter mode , do not enter existed one', 'filmic' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Your Image Field...', 'filmic' ),
				'default'     => esc_html__( 'Sences', 'filmic' )
			]
		);
		$repeater->add_control(
			'images',
			[
				'label' => __( 'Add Images', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::GALLERY,
				'default' => [],
			]
		);
		$this->add_control(
			'gallery',
			[
				'label'   => esc_html__( 'Labels and images', 'filmic' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => [
					[],
					[]
				],
				'title_field' => '{{{ label }}}'
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'item_style',
			[
				'label' => esc_html__( 'Item', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_responsive_control(
			'item_height',
			[
				'label' => __( 'Item Height', 'filmic' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 5,
					],
				],
				'default' => [
					'size' => 540,
				],
				'selectors' => [
					'{{WRAPPER}} .filmic-gallery-archive .gall-thumb' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'gap',
			[
				'label'     => __( 'Item Padding', 'filmic' ),
				'type'      => Controls_Manager::SLIDER,
				'default'   => [
					'size' => 0,
				],
				'range'     => [
					'px'   => [
						'min' => 0,
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .filmic-gallery-archive .gall-thumb' => 'padding: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'label_style',
			[
				'label' => esc_html__( 'Filters', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_responsive_control(
			'labels_align',
			[
				'label'   => esc_html__( 'Alignment', 'filmic' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'filmic' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'filmic' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'filmic' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} .filmic-gallery-widget__label' => 'text-align: {{VALUE}}',
				]
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'label_typo',
				'selector' => '{{WRAPPER}} .filmic-gallery-widget__label span'
			]
		);
		$this->add_control(
			'labels_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-gallery-widget__label span' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'labels_color_active',
			[
				'label'     => esc_html__( 'Active Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9e8157',
				'selectors' => [
					'{{WRAPPER}} .filmic-gallery-widget__label span:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .filmic-gallery-widget__label span.active-image' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_responsive_control(
			'labels_margin',
			[
				'label'    	 => __( 'Margin', 'filmic' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'	 => [
					'top' 		=> '0',
					'right' 	=> '30',
					'bottom' 	=> '25',
					'left' 		=> '0',
					'unit'	 	=> 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .filmic-gallery-widget__label span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
				'condition'	 => [
					'allow_filter' => 'yes',
				],
			]
		);
		$this->end_controls_section();
    }
    /**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
    protected function render() {
		$settings = $this->get_settings_for_display();
		$gallery	=	$settings['gallery'];
		$filter		=	$settings['allow_filter'];
		$columns 	=	$settings['column'];
		?>
		<div class="filmic-gallery-widget">
			<?php if( 'yes' === $filter ): ?>
			<div class="filmic-gallery-widget__label">
				<span data-filter="*" class="active-image" >All</span>
				<?php foreach ( $gallery as $gall ): ?>
					<?php
						$label	=	$gall['label'];
					?>
					<span data-filter="<?php echo esc_attr( '.'.filmic_slug( $label ) );?>" ><?php echo esc_html( $label ) ?></span>
				<?php endforeach ?>
			</div>
			<?php endif ?>
			<div class="filmic-gallery-archive filmic-gallery-archive--<?php echo esc_attr( $columns ); ?>">
				<?php foreach ( $gallery as $gall ): ?>
					<?php foreach ( $gall['images'] as $image ): ?>
						<?php
							$label		=	$gall['label'];
							$image_url	=	$image['url'];
						?>
						<div class="gall-thumb <?php echo esc_attr( filmic_slug( $label ) ); ?>">
							<div class="gall-thumb__inner">
								<img src="<?php echo esc_url( $image_url ); ?>" alt="gall-image">
								<a 	class="gall-thumb__inner__url"
									href="<?php echo esc_url( $image_url ); ?>"
								>
									<?php echo esc_html( $label ) ?>
								</a>
							</div>
						</div>
					<?php endforeach ?>
				<?php endforeach ?>
			</div>
		</div>
		<?php
    }
}
