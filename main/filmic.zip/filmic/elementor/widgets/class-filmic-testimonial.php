<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

/**
 * Filmic testimonial widget.
 *
 * Filmic widget that displays testimonial page.
 *
 * @since 1.0.0
 */

class Filmic_Testimonial extends Widget_Base {
	/**
	 * Get widget name.
	 *
	 * Retrieve testimonial widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'filmic_testimonial';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve testimonial widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Testimonial', 'filmic' );
	}

		/**
	 * Get widget icon.
	 *
	 * Retrieve testimonial widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-testimonial';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the icon widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'filmic-theme' ];
	}
	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'filmic-testimonial-scripts' );
	}

	/**
	 * Register category box widget controls.
	 *
	 * Add different input fields to allow the user to change and customize the widget settings
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'section_testi',
			array(
				'label' => esc_html__( 'Item Layout', 'filmic' ),
			)
		);
        $repeater = new Elementor\Repeater();

		$repeater->add_control(
			'avatar',
			[
				'label'   => esc_html__( 'Avatar', 'filmic' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				]
			]
        );
		$repeater->add_control(
			'name',
			[
				'label'       => esc_html__( 'Name', 'filmic' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter Name', 'filmic' ),
				'default'     => esc_html__( 'Richard Green ', 'filmic' )
			]
		);
		$repeater->add_control(
			'position',
			[
				'label'       => esc_html__( 'Position', 'filmic' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter Position', 'filmic' ),
				'default'     => esc_html__( 'Marketing Manager of Donal Skehan', 'filmic' )
			]
		);
		$repeater->add_control(
			'content',
			[
				'label'       => esc_html__( 'Content', 'filmic' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Enter Content', 'filmic' ),
				'default'     => esc_html__( '"One of the best Film Studio theme I’ve ever seen. Reasonable price, easy to use, amazing design, smooth run and excellent support. Great work you have done. Congratulation!"', 'filmic' )
			]
		);
		$this->add_control(
			'testimonial',
			[
				'label'   => esc_html__( 'Testimonial', 'filmic' ),
				'type'    => Controls_Manager::REPEATER,
				'fields'  => $repeater->get_controls(),
				'default' => [
					[],
					[]
				],
				'title_field' => '{{{ name }}}'
			]
        );
        $this->add_control(
            'show-number',
            [
                'label'        => esc_html__( 'Show Number', 'filmic' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'label_on'     => esc_html__( 'Yes', 'filmic' ),
                'label_off'    => esc_html__( 'No', 'filmic' ),
				'return_value' => 'yes',
	
            ]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_testi_slider',
			array(
				'label' => esc_html__( 'Slider', 'filmic' ),
			)
		);
		$this->add_responsive_control(
            'testi-slides_to_show',
            [
                'label'   =>  esc_html__( 'Slides to show', 'filmic' ),
                'type'    => Controls_Manager::NUMBER,
                'min'     => 1,
                'max'     => 5,
                'step'    => 1,
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'mobile_default' => 1,
				'tablet_default' => 1,
				'desktop_default' => 1,
            ]
        );
        $this->add_control(
            'testi-dots',
            [
                'label'        => esc_html__( 'Show Dots', 'filmic' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'label_on'     => esc_html__( 'Yes', 'filmic' ),
                'label_off'    => esc_html__( 'No', 'filmic' ),
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'show-testi-arrow',
            [
                'label'        => esc_html__( 'Show Arrows', 'filmic' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'no',
                'label_on'     => esc_html__( 'Yes', 'filmic' ),
                'label_off'    => esc_html__( 'No', 'filmic' ),
                'return_value' => 'yes',
            ]
        );
        $this->end_controls_section();
        
		//style
		$this->start_controls_section(
			'wrapper_style',
			[
				'label' => esc_html__( 'Wrapper', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_responsive_control(
			'user-info-direction',
			[
				'label'   => esc_html__( 'Item Direction', 'filmic' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'row' => [
						'title' => esc_html__( 'Left', 'filmic' ),
						'icon'  => 'eicon-h-align-left',
					],
					'column' => [
						'title' => esc_html__( 'Center', 'filmic' ),
						'icon'  => 'eicon-v-align-bottom',
					],
					'row-reverse' => [
						'title' => esc_html__( 'Right', 'filmic' ),
						'icon'  => 'eicon-h-align-right',
					],
				],
				'default' => 'row',
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-item__info ' => 'flex-direction: {{VALUE}}'
				]
			]
		);
		$this->add_control(
            'wrapper-bg_color',
            [
                'label'     => esc_html__( 'Background Color', 'filmic' ),
                'type'      => Controls_Manager::COLOR,
                'default'   => 'transparent',
                'selectors' => [
                    '{{WRAPPER}} .filmic-testimonial-item' => 'background-color: {{VALUE}}',
                ]
            ]
        );
		$this->add_responsive_control(
            'wrapper-padding',
            [
                'label'      => __( 'Padding', 'filmic' ),
                'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'=> [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'unit' => 'px'
				],
                'selectors'  => [
                    '{{WRAPPER}} .filmic-testimonial-item__content-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
		);
		$this->add_responsive_control(
            'wrapper_width',
            [
                'label' => esc_html__( 'Width', 'filmic' ),
                'type'  => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'full-width'     => esc_html__( 'Full Width', 'filmic' ),
                    'custom'  => esc_html__( 'Custom', 'filmic' ),
                ],
				'default' => 'full-width',
            ]
		);
		$this->add_responsive_control(
			'wrapper_custom_width',
			[
				'label'   => __( 'Enter Width ', 'filmic' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 770,
				],
				'size_units' => [ 'px', '%', 'em' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 2000,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
					'em' => [
						'min' => 0,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-item__content-wrapper' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'=>[
					'wrapper_width'=>'custom'
				]	
			]
		);
		$this->end_controls_section();

		//content
        $this->start_controls_section(
			'content_style',
			[
				'label' => esc_html__( 'Content', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_control(
			'content_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-item__content' => 'color: {{VALUE}}'
				]
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typo',
				'selector' => '{{WRAPPER}} .filmic-testimonial-item__content'
			]
		);
		$this->add_control(
			'content_hover_color',
			[
				'label'     => esc_html__( 'Hover Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-item:hover .filmic-testimonial-item__content' => 'color: {{VALUE}}',
				]
			]
		);
        $this->add_responsive_control(
			'content-align',
			[
				'label'   => esc_html__( 'Alignment', 'filmic' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'filmic' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'filmic' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'filmic' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-item__content ' => 'text-align: {{VALUE}}',
					'{{WRAPPER}} .filmic-testimonial-item__career__name ' => 'text-align: {{VALUE}}',
					'{{WRAPPER}} .filmic-testimonial-item__career__position ' => 'text-align: {{VALUE}}',
					'{{WRAPPER}} .filmic-testimonial-item__avatar ' => 'text-align: {{VALUE}}',
				]
			]
		);
        $this->add_responsive_control(
            'content_distance',
            [
                'label'   => __( 'Distance from Content ', 'filmic' ),
                'type'    => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .filmic-testimonial-item__content' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				],
				
            ]
        );
        $this->end_controls_section();
        //avater
        $this->start_controls_section(
			'user_info_style',
			[
				'label' => esc_html__( 'Avatar', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Image_Size::get_type(),
			[
				'name' => 'img'
			]
		);
		$this->add_responsive_control(
            'avatar-padding',
            [
                'label'      => __( 'Padding', 'filmic' ),
                'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'=> [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'unit' => 'px'
				],
                'selectors'  => [
                    '{{WRAPPER}} .filmic-testimonial-item__avatar' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
		);
		$this->end_controls_section();
		//name
		$this->start_controls_section(
			'name_style',
			[
				'label' => esc_html__( 'Name', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_control(
			'name_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#292929',
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-item__career__name' => 'color: {{VALUE}}'
				]
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'name_typo',
				'selector' => '{{WRAPPER}} .filmic-testimonial-item__career__name'
			]
        );
		$this->add_responsive_control(
            'name_distance',
            [
                'label'   => __( 'Distance from Name ', 'filmic' ),
                'type'    => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .filmic-testimonial-item__career__name' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
		);
		$this->end_controls_section();
		//position
		$this->start_controls_section(
			'position_style',
			[
				'label' => esc_html__( 'Position', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'position_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-item__career__position' => 'color: {{VALUE}}'
				]
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'position_typo',
				'selector' => '{{WRAPPER}} .filmic-testimonial-item__career__position'
			]
        );
		$this->end_controls_section();
		//number
		$this->start_controls_section(
			'number_style',
			[
				'label' => esc_html__( 'Number', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'=>[
					'show-number'=>'yes'
				]
			]
		);
		$this->add_control(
			'number_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-item__order' => 'color: {{VALUE}}',
				]
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'number_typo',
				'selector' => '{{WRAPPER}} .filmic-testimonial-item__order'
			]
		);
		$this->add_control(
			'number_color_hover',
			[
				'label'     => esc_html__( 'Hover Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-item:hover .filmic-testimonial-item__order' => 'color: {{VALUE}};',
				]
			]
		);
		$this->add_responsive_control(
            'testi_number-margin',
            [
                'label'      => __( 'Padding', 'filmic' ),
                'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'=> [
					'top' => '0',
					'right' => '0',
					'bottom' => '0',
					'left' => '0',
					'unit' => 'px'
				],
                'selectors'  => [
                    '{{WRAPPER}} .filmic-testimonial-item__order' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
		);
		$this->end_controls_section();
		//dots
		$this->start_controls_section(
			'testi-dot_style',
			[
				'label' => esc_html__( 'Dots', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'=>[
					'testi-dots'=>'yes'
				]
			]
		);
		$this->add_control(
			'testi-dot_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-list .slick-dots li button' => 'background-color: {{VALUE}}'
				]
			]
		);

		$this->add_control(
			'testi-dot_color_active',
			[
				'label'     => esc_html__( 'Active Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#9e8157',
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-list .slick-dots li.slick-active button' => 'background-color: {{VALUE}} !important;'
				]
			]
		);
		$this->add_responsive_control(
            'testi-dot_distance',
            [
                'label'   => __( 'Distance from Dots ', 'filmic' ),
                'type'    => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 20,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .filmic-testimonial-list .slick-dots' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
				
            ]
        );
		$this->end_controls_section();
		//arrow
		$this->start_controls_section(
			'arrow_style',
			[
				'label' => esc_html__( 'Arrows', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition'=>[
					'show-testi-arrow'=>'yes'
				]
			]
		);
		$this->add_control(
			'arrow_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-list__arrows i' => 'color: {{VALUE}}'
				]
			]
		);

		$this->add_control(
			'arrow_color_active',
			[
				'label'     => esc_html__( 'Hover Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#292929',
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-list__arrows i:hover' => 'color: {{VALUE}} !important;'
				]
			]
		);
		$this->add_responsive_control(
			'arrow_size',
			[
				'label'   => __( 'Size ', 'filmic' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 48,
				],
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-list__arrows i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				
			]
		);
		$this->add_responsive_control(
			'arrow_distance',
			[
				'label'   => __( 'Distance ', 'filmic' ),
				'type'    => Controls_Manager::SLIDER,
				'default' => [
					'size' => 0,
				],
				'range' => [
					'px' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .filmic-testimonial-list__left' => 'left: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .filmic-testimonial-list__right' => 'right: {{SIZE}}{{UNIT}};',
				]
				
			]
		);
		$this->end_controls_section();
	}
	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 */

	protected function render() {
		$settings = $this->get_settings_for_display();
		$show_num_check = $settings['show-number'];
		$testi_desk_slider = $settings['testi-slides_to_show'];
		$testi_tablet_slider = $settings['testi-slides_to_show_tablet'];
		$testi_mobile_slider = $settings['testi-slides_to_show_mobile'];
		$show_dots_check = $settings['testi-dots'];
		$show_arrows_check = $settings['show-testi-arrow'];
		$order_num = 0;
        ?>
		<div class="filmic-testimonial-widget">
			<div class="filmic-testimonial-list"
				data-show="<?php echo esc_attr( $testi_desk_slider );  ?>"
				data-show-tablet="<?php echo esc_attr( $testi_tablet_slider ); ?>" 
				data-show-mobile="<?php echo esc_attr( $testi_mobile_slider ); ?>"
				data-dots="<?php echo esc_attr(  $show_dots_check ); ?>"
			>
                <?php foreach ($settings['testimonial'] as $testi ) : ?>
					<?php 
						$order_num++; 
						$odered_num = ($order_num < 10 && $order_num > 0) ? '0'.$order_num : $order_num;
					?>
                    <div class="filmic-testimonial-item">
						<?php if ( $show_num_check == 'yes' ): ?>
							<h3 class="filmic-testimonial-item__order"> <?php echo esc_attr( $odered_num );?></h3>
						<?php endif ?>
                        <div class="filmic-testimonial-item__content-wrapper">
                            <div class="filmic-testimonial-item__content">
                            <?php echo esc_html( $testi['content'] ); ?>
                            </div>
                            <div class="filmic-testimonial-item__info">
                                <div class="filmic-testimonial-item__avatar">
                                    <?php if ( ! $testi['avatar']['id'] ) {
                                        $image_url = $testi['avatar']['url'];
                                    } else {
                                        $image_url = Elementor\Group_Control_Image_Size::get_attachment_image_src( $testi['avatar']['id'], 'img', $settings );
                                    } ?>
                                    <img src="<?php echo esc_url( $image_url ) ?>" class='avatar' alt='avatar'>
                                </div>
                                <div class="filmic-testimonial-item__career">
                                    <h5 class="filmic-testimonial-item__career__name"><?php echo esc_html( $testi['name'] ); ?></h5>
                                    <p class="filmic-testimonial-item__career__position"><?php echo esc_html( $testi['position'] ); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach ?>
			</div>
			<?php if ( 'yes' === $show_arrows_check ): ?>
			<div class="filmic-testimonial-list__arrows">
				<i class="ion-ios-arrow-thin-left filmic-testimonial-list__left"></i>
				<i class="ion-ios-arrow-thin-right filmic-testimonial-list__right"></i>
			</div>
			<?php endif ?>
        </div>
        <?php
	}
}
