<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;

/**
 * Filmic Member image widget.
 *
 * Filmic widget that displays member's infomation for page.
 *
 * @since 1.0.0
 */

class Filmic_Member extends Widget_Base {
	/**
	 * Get widget name.
	 *
	 * Retrieve member widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'filmic_member';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve landing image widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Members', 'filmic' );
	}

		/**
	 * Get widget icon.
	 *
	 * Retrieve landing image widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-person';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the icon widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'filmic-theme' ];
	}
	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return array( 'filmic-members-scripts' );
	}

	/**
	 * Register category box widget controls.
	 *
	 * Add different input fields to allow the user to change and customize the widget settings
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'section_member',
			array(
				'label' => esc_html__( 'Members Layout', 'filmic' ),
			)
		);

		$this->add_control(
			'member-amount',
			[
                'label'   => esc_html__( 'Amount ', 'filmic' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 6
            ]
		);
		$this->add_responsive_control(
            'align',
            [
                'label'		=> esc_html__( 'Direction', 'filmic' ),
                'type' 		=> Controls_Manager::CHOOSE,
                'options' 	=> [
                    'row' 		=> [
                        'title' => esc_html__( 'Horizontal', 'filmic' ),
                        'icon'  => 'ion-android-more-horizontal',
                    ],
                    'column' 	=> [
                        'title' => esc_html__( 'Vertical', 'filmic' ),
                        'icon'  => 'ion-android-more-vertical',
                    ],
                ],
				'default' => 'row',
				'selectors' => [
                    '{{WRAPPER}} .filmic-member' => 'flex-direction: {{VALUE}}',
                ],
            ]
		);
		$this->add_control(
            'member-content-appearance',
            [
                'label'        => esc_html__( 'Show Excerpt', 'filmic' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'label_on'     => esc_html__( 'Yes', 'filmic' ),
                'label_off'    => esc_html__( 'No', 'filmic' ),
                'return_value' => 'yes',
            ]
		);
		$this->add_control(
            'member-social-appearance',
            [
                'label'        => esc_html__( 'Show Social Media', 'filmic' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'label_on'     => esc_html__( 'Yes', 'filmic' ),
                'label_off'    => esc_html__( 'No', 'filmic' ),
                'return_value' => 'yes',
            ]
		);
        $this->add_responsive_control(
            'slidemode',
            [
                'label' 	=> esc_html__( 'Layout Mode', 'filmic' ),
                'type'  	=> \Elementor\Controls_Manager::SELECT,
                'options' 	=> [
                    'member-grid-mode'     => esc_html__( 'Grid', 'filmic' ),
                    'member-slide-mode'  => esc_html__( 'Slide', 'filmic' ),
                ],
				'default'	=> 'member-grid-mode',
            ]
		);
		$this->add_responsive_control(
            'member-slides_to_show',
            [
                'label'          =>  esc_html__( 'Slides to show', 'filmic' ),
                'type'           => Controls_Manager::NUMBER,
                'min'            => 1,
                'max'            => 5,
                'step'           => 1,
				'devices'        => [ 
					'desktop', 'tablet', 'mobile' 
				],
                'mobile_default' => 1,
				'tablet_default' => 2,
				'desktop_default'=> 3,
				'condition'		 => [
					'slidemode'=>'member-slide-mode'
				]
            ]
		);
		$this->add_control(
            'member-filter-hover',
            [
                'label'        => esc_html__( 'Gray Thumbnail', 'filmic' ),
                'type'         => Controls_Manager::SWITCHER,
                'default'      => 'yes',
                'label_on'     => esc_html__( 'Yes', 'filmic' ),
                'label_off'    => esc_html__( 'No', 'filmic' ),
				'return_value' => 'yes',
				'condition'=>[
					'slidemode'=>'member-slide-mode'
				]
            ]
		);
		$this->end_controls_section();
	//------------------ section Style.
		///tittle
		$this->start_controls_section(
			'member-tittle_style',
			[
				'label' => esc_html__( 'Name', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'member-title-align',
			[
				'label'      => esc_html__( 'Alignment', 'filmic' ),
				'type'       => Controls_Manager::CHOOSE,
				'options'    => [
					'left'   => [
						'title' => esc_html__( 'Left', 'filmic' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'filmic' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'filmic' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'    => 'left',
				'selectors'  => [
					'{{WRAPPER}} .filmic-member__name' => 'text-align: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#292929',
				'selectors' => [
					'{{WRAPPER}} .filmic-member__name ' => 'color: {{VALUE}}'
				]
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typo',
				'selector' => '{{WRAPPER}} .filmic-member__name '
			]
		);
		$this->add_responsive_control(
			'member-tittle-margin',
			[
				'label'    	 => __( 'Margin', 'filmic' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'	 => [
					'top' 		=> '0',
					'right' 	=> '0',
					'bottom'	=> '7',
					'left'		=> '0',
					'unit'		=> 'px',
				],
				'selectors'  => [
					'{{WRAPPER}} .filmic-member__name ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
			]
		);
		$this->end_controls_section();
		//position
		$this->start_controls_section(
			'member-position_style',
			[
				'label' => esc_html__( 'Position', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_responsive_control(
			'member-position-align',
			[
				'label'      => esc_html__( 'Alignment', 'filmic' ),
				'type'       => Controls_Manager::CHOOSE,
				'options'    => [
					'left'   => [
						'title' => esc_html__( 'Left', 'filmic' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'filmic' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'filmic' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'    => 'left',
				'selectors'  => [
					'{{WRAPPER}} .filmic-member__position' => 'text-align: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'position_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-member__position ' => 'color: {{VALUE}}'
				]
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'position_typo',
				'selector' => '{{WRAPPER}} .filmic-member__position '
			]
		);
		$this->add_responsive_control(
			'member-position-margin',
			[
				'label'      => __( 'Margin', 'filmic' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .filmic-member__position ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				],
			]
		);
		$this->end_controls_section();

		// content
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'filmic' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		// Alignment.
		$this->add_responsive_control(
			'member-content-align',
			[
				'label'      => esc_html__( 'Alignment', 'filmic' ),
				'type'       => Controls_Manager::CHOOSE,
				'options'    => [
					'left'   => [
						'title' => esc_html__( 'Left', 'filmic' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'filmic' ),
						'icon'  => 'fa fa-align-center',
					],
					'right'  => [
						'title' => esc_html__( 'Right', 'filmic' ),
						'icon'  => 'fa fa-align-right',
					],
				],
				'default'    => 'left',
				'selectors'  => [
					'{{WRAPPER}} .filmic-member__description' => 'text-align: {{VALUE}}',
					'{{WRAPPER}} .filmic-member__social' => 'text-align: {{VALUE}}',
				]
			]
		);
		$this->add_control(
			'member-content_color',
			[
				'label'     => esc_html__( 'Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#8f8f8f',
				'selectors' => [
					'{{WRAPPER}} .filmic-member__description p ' => 'color: {{VALUE}}'
				]
			]
		);
		$this->add_group_control(
			Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typo',
				'selector' => '{{WRAPPER}} .filmic-member__description p '
			]
		);
		$this->add_control(
            'member-limited',
            [
                'label'   => esc_html__( 'Limit Text', 'sable' ),
                'type'    => Controls_Manager::NUMBER,
                'default' => 15
            ]
        );
        $this->add_responsive_control(
            'member-info-padding',
            [
                'label'      => __( 'Content Padding', 'filmic' ),
                'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'    => [
					'top' 	 => '27',
					'right'  => '30',
					'bottom' => '27',
					'left'   => '30',
					'unit'   => 'px'
				],
                'selectors'  => [
                    '{{WRAPPER}} .filmic-member__info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
		);
		$this->add_responsive_control(	
            'member-content-padding',
            [
                'label'      => __( 'Excerpt Padding', 'filmic' ),
                'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'    => [
					'top'    => '25',
					'right'  => '0',
					'bottom' => '32',
					'left'   => '0',
					'unit'   => 'px'
				],
                'selectors'  => [
                    '{{WRAPPER}} .filmic-member__description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
		);
		$this->add_control(
            'member-content-bg_color',
            [
				'label'     => esc_html__( 'Background Color', 'filmic' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => 'transparent',
				'selectors' => [
					'{{WRAPPER}} .filmic-member__info' => 'background-color: {{VALUE}}',
				]
            ]
        );
		$this->end_controls_section();

	}
	/**
	 * Render the widget output on the frontend.    
	 *
	 * Written in PHP and used to generate the final HTML.
	 */
	protected function render() {
		$settings		= $this->get_settings_for_display();
		$members		= $settings['member-amount'];
		$limited		= $settings['member-limited'];
		$avatar_gray	= ( $settings['member-filter-hover'] == 'yes' ) ? 'filmic-member__avatar__grayscale' : ''; 
		$paged			= ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
        $args 			= array(
            'post_type' 		=> 'ht-member',
            'posts_per_page'	=> $members,
            'paged' 			=> $paged
        );
        $posts = new WP_Query( $args );
		$total_page = $posts->max_num_pages;
		?>
		<div class="filmic-members-widget <?php echo esc_attr( $settings['slidemode'] ); ?>"
			data-show			="<?php echo esc_attr( $settings['member-slides_to_show'] );  ?>"
			data-show-tablet	="<?php echo esc_attr( $settings['member-slides_to_show_tablet'] ); ?>" 
			data-show-mobile	="<?php echo esc_attr( $settings['member-slides_to_show_mobile'] ); ?>" 
		>
			<div class="row">
			<?php
			while ( $posts->have_posts() ) :
				$posts->the_post();
				$position	= function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( get_the_ID(), 'position' ) : '';
				$facebook	= function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( get_the_ID(), 'facebook' ) : '';
				$twitter	= function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( get_the_ID(), 'twitter' ) : '';
				$instagram	= function_exists( 'fw_get_db_post_option' ) ? fw_get_db_post_option( get_the_ID(), 'instagram' ) : '';
			?>
				<div id="post-<?php the_ID(); ?>" class="filmic-member__item col-lg-6">
					<div class="filmic-member">
						<div class="filmic-member__avatar <?php echo esc_attr( $avatar_gray ); ?>">
							<?php 
							if ( has_post_thumbnail() ){
								the_post_thumbnail();
							}
							?>
						</div>
						<div class="filmic-member__info">
							<h6 class="filmic-member__name">
								<?php echo get_the_title(); ?>
							</h6>
							<div><p class="filmic-member__position"><?php echo esc_html( $position ); ?></p></div>
							<?php if ( 'yes' == $settings['member-content-appearance'] ): ?>
								<div class="filmic-member__description">
									<?php echo esc_html( wp_trim_words( get_the_excerpt( get_the_ID() ) , $limited, null ) ) ?>
								</div>
							<?php endif ?>	
							<?php if ( 'yes' == $settings['member-social-appearance'] ): ?>
							<div class="filmic-member__social">
								<a href="<?php echo esc_html( $facebook ); ?>"><i class="ion-social-facebook"></i></a>
								<a href="<?php echo esc_html( $twitter ); ?>"><i class="ion-social-twitter"></i></a>
								<a href="<?php echo esc_html( $instagram ); ?>"><i class="ion-social-instagram-outline"></i></a>
							</div>
							<?php endif ?>
						</div>
					</div>
				</div>
            	<?php endwhile; ?>

			</div>	
		</div>
		<?php

	}
}
