<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package filmic
 */

$c_footer = get_theme_mod('footer_layout', true);

$p_footer = function_exists('fw_get_db_post_option') ? fw_get_db_post_option(get_the_ID(), 'p_footer') : array();
if(isset($p_footer['gadget'])){
    if($p_footer['gadget'] == 'custom'){
        $c_footer = true;
    }elseif($p_footer['gadget'] == 'disable'){
        $c_footer = false;
    }
}


$footer_copyright_left = get_theme_mod( 'footer_copyright_left', '&copy; '. date( 'Y' ) .' Filmic. All Rights Reserved. Designed by Lee Hari.' );
$footer_copyright_right = get_theme_mod( 'footer_copyright_right' ); ?>

	</div><!-- #content -->

    <?php
        if (  function_exists( 'boostify_footer_active' ) && boostify_footer_active() ):
            boostify_get_footer_template();
            ?>
                <span class="scroll-to-top ion-ios-arrow-up" aria-label="<?php esc_attr_e('Back to top', 'filmic'); ?>" title="<?php esc_attr_e('Scroll To Top', 'filmic'); ?>"></span>
            <?php
        else:
            if($c_footer == true):/*on/off footer*/ ?>
                <footer id="colophon" class="site-footer" role="contentinfo">
                    <?php if ( is_active_sidebar( 'sidebar-footer' ) ) :/*footer widget*/ ?>
                        <div class="site-footer__main">
                            <div class="container">
                                <div class="row">
                                    <?php dynamic_sidebar( 'sidebar-footer' ); ?>
                                </div><!-- .row -->
                            </div><!-- .container -->
                        </div>
                    <?php endif; ?>

                    <div class="site-footer__copyright">
                        <div class="container">
                            <div class="site-footer__container">
                                <?php if ( $footer_copyright_left ) : ?>
                                    <div class="left-copyright">
                                        <?php echo wp_kses_post( $footer_copyright_left ); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ( $footer_copyright_right ) : ?>
                                    <div class="right-copyright">
                                        <?php echo wp_kses_post( $footer_copyright_right ); ?>
                                    </div>
                                <?php endif; ?>
                            </div><!-- site-footer__container -->
                        </div><!-- .container -->
                    </div><!-- .site-footer__copyright -->
                    <span class="scroll-to-top ion-ios-arrow-up" aria-label="<?php esc_attr_e('Back to top', 'filmic'); ?>" title="<?php esc_attr_e('Scroll To Top', 'filmic'); ?>"></span>
                </footer>
            <?php
        endif;
        endif;
    ?>
    <div class="theme-overlay"></div>
</div>

<?php wp_footer(); ?>

</body>
</html>