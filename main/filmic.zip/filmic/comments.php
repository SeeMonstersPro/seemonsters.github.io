<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package filmic
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">

	<?php
	// You can start editing here -- including this comment!
	if ( have_comments() ) : ?>
		<h2 class="comments-title post-headline t-small t-uppercase">
			<?php
				$comments_number = get_comments_number();
				if ( '1' === $comments_number ) {
					/* translators: %s: post title */
					printf( _x( 'One comment on &ldquo;%s&rdquo;', 'comments title', 'filmic' ), get_the_title() );
				} else {
					printf(
						/* translators: 1: number of comments, 2: post title */
						_nx(
							'%1$s comment on &ldquo;%2$s&rdquo;',
							'%1$s comments on &ldquo;%2$s&rdquo;',
							$comments_number,
							'comments title',
							'filmic'
						),
						number_format_i18n( $comments_number ),
						get_the_title()
					);
				}
			?>
		</h2><!-- .comments-title -->

        <?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :/*comment navigation*/ ?>
            <nav id="comment-nav-above" class="navigation comment-navigation">
                <h3 class="screen-reader-text"><?php esc_html_e( 'Comment navigation', 'filmic'); ?></h3>
                <div class="nav-previous"><?php previous_comments_link( esc_html__( 'Older Comments', 'filmic') ); ?></div>
                <div class="nav-next"><?php next_comments_link( esc_html__( 'Newer Comments ', 'filmic') ); ?></div>
            </nav>
        <?php endif; ?>

		<ul class="comment-list">
			<?php
				wp_list_comments( array(
					'style'      => 'ul',
					'short_ping' => true,
					'callback' => 'filmic_comment',
					'end_callback' => 'filmic_comment_close'
				) );
			?>
		</ul><!-- .comment-list -->

		<?php if ( ! comments_open() ) : ?>
			<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'filmic' ); ?></p>
		<?php
		endif;

	endif; // Check for have_comments().

    $req = get_option( 'require_name_email' );
    $aria_req = $req ? "required" : '';

	comment_form( array(
		'title_reply' => esc_html__( 'Leave A Comment', 'filmic' ),
		'title_reply_before' => '<h3 id="reply-title" class="comment-reply-title post-headline t-small t-uppercase">',
		'title_reply_after' => '</h3>',
		'comment_notes_before' => '',
		'label_submit' => esc_html__( 'Post Comment', 'filmic' ),
		'class_submit' => 'comment-submit-btn',

		'fields' => apply_filters( 'comment_form_default_fields', array(
			'author' =>
                '<div class="row"><div class="col-md-6"><p class="comment-form-author">'
				. '<input id="author" class="comment-form-field" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30" placeholder="'. esc_attr__('Name *', 'filmic') .'" ' . esc_attr($aria_req) . '></p></div>',


			'email' => '<div class="col-md-6"><p class="comment-form-email">'
						. '<input id="email" class="comment-form-field" name="email" type="email" value="' . esc_attr( $commenter['comment_author_email'] ) .
										'" size="30" placeholder="Email *" ' . esc_attr($aria_req) . '></p></div></div>',

			'url' => '<p class="comment-form-url">'
						. '<input id="url" class="comment-form-field" name="url" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) .
										'" size="30" placeholder="'. esc_attr__('Website (Optional)', 'filmic') .'"></p>'
		) ),

		'comment_field' => '<p class="comment-form-comment">'
							. '<textarea id="comment" name="comment" class="comment-form-field" rows="8" ' . esc_attr($aria_req) . ' placeholder="'. esc_attr__( 'Comment', 'filmic' ) .'"></textarea>'
												. '</p>'
	) );
	?>

</div><!-- #comments -->

<?php
	function filmic_comment( $comment, $args, $depth ) {
		$GLOBALS['comment'] = $comment;
		extract($args, EXTR_SKIP);
		if ( 'li' === $args['style'] ) {
			$tag = 'li';
			$add_below = 'comment';
		} else {
			$tag = 'li';
			$add_below = 'comment';
		} ?>

<<?php echo esc_attr($tag); ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?> id="comment-<?php comment_ID(); ?>">
	<article class="comment-wrapper">
		<div class="comment-container">
			<div class="comment-avatar">
				<?php echo get_avatar( $comment->comment_author_email, 70); ?>
			</div><!-- .comment-avatar -->

			<div class="comment-main">
				<header class="comment-header">
					<h3 class="comment-author"><?php comment_author(); ?></h3>
					<time class="comment-meta-item t-small"><?php echo human_time_diff( get_comment_time('U'), current_time('timestamp') ) . " " . esc_html__('ago', 'filmic'); ?></time>
				</header><!-- .comment-header -->

				<div class="comment-content post-content">
					<?php comment_text(); ?>
				</div><!-- .comment-content -->

				<footer class="comment-footer">
					
					<?php comment_reply_link( array_merge( $args, array(
						'add_below' => $add_below,
						'depth' => $depth,
						'max_depth' => $args['max_depth'],
                        'before'    => '<div class="comment-reply">',
                        'after'     => '</div>'
					) ) ); ?>

					<?php edit_comment_link('<span class="comment-meta-item">Edit</span>', '', ''); ?>
					<?php if ( $comment->comment_approved == '0' ) : ?>
						<p class="comment-meta-item"><?php esc_html_e('Your comment is awaiting moderation.', 'filmic'); ?></p>
					<?php endif; ?>
				</footer><!-- .comment-footer -->
			</div><!-- .comment-main -->
		</div><!-- .comment-container -->
	</article>
<?php } /*filmic_comment*/

function filmic_comment_close() {
	echo '</li>';
}

?>




