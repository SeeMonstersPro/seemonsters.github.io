<?php
/**
 * Register the required plugins for this theme.
 * @package    TGM-Plugin-Activation
 * @subpackage Example
 * @version    2.6.1
 * @author     Thomas Griffin
 * @author     Gary Jones
 * @copyright  Copyright (c) 2011, Thomas Griffin
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       https://github.com/thomasgriffin/TGM-Plugin-Activation
 */

/*Include the TGM_Plugin_Activation class.*/
require_once get_template_directory() . '/tgm-plugin/class-tgm-plugin-activation.php';

/*TGM_Plugin_Activation class constructor.*/
function filmic_register_required_plugins() {
    $plugins = array(
        array(
            'name'               => esc_html__('Revolution Slider', 'filmic'),
            'slug'               => 'revolution-slider',
            'source'             => get_template_directory() . '/inc/plugins/revolution-slider.zip',
            'required'           => false,
            'version'            => '',
            'force_activation'   => false,
            'force_deactivation' => false,
            'external_url'       => ''
        ),
        array(
            'name'               => esc_html__('HT Packages', 'filmic'),
            'slug'               => 'ht-packages',
            'source'             => get_template_directory() . '/inc/plugins/ht-packages.zip',
            'required'           => true,
            'version'            => '',
            'force_activation'   => false,
            'force_deactivation' => false,
            'external_url'       => ''
        ),
        array(
            'name'      => esc_html__('Unyson', 'filmic'),
            'slug'      => 'unyson',
            'required'  => true,
        ),
        array(
            'name'      => esc_html__('Elementor', 'filmic'),
            'slug'      => 'elementor',
            'required'  => true,
        ),
        array(
            'name'      => esc_html__('Kirki', 'filmic'),
            'slug'      => 'kirki',
            'required'  => true,
        ),
        array(
            'name'      => esc_html__('Woocommerce', 'filmic'),
            'slug'      => 'woocommerce',
            'recommended' => true,
        ),
        array(
            'name'      => esc_html__('Contact Form 7', 'filmic'),
            'slug'      => 'contact-form-7'
        ),
        array(
           'name' => esc_html__('Envato Market','filmic'),
           'slug' => 'envato-market',
           'source' => 'https://envato.github.io/wp-envato-market/dist/envato-market.zip',
           'required' => true,
           'recommended' => true,
        ),
        array(
            'name'               => esc_html__('Boostify Header Footer Builder', 'filmic'),
            'slug'               => 'boostify-header-footer-builder',
            'required'           => true,
        ),
    );

    $config = array(
        'id'           => 'tgmpa',
        'menu'         => 'tgmpa-install-plugins',/*menu slug*/
        'capability'   => 'edit_theme_options',
        'is_automatic' => false,
    );

    tgmpa( $plugins, $config );
}
add_action( 'tgmpa_register', 'filmic_register_required_plugins' );
