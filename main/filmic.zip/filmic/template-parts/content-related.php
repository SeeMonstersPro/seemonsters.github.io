<?php

$categories = get_the_category($post->ID);

if (!$categories) return;

$categories_ids = array();
foreach( $categories as $individual_category ) {
    $categories_ids[] = $individual_category->term_id;
}

$args = array(
    'category__in' => $categories_ids,
    'post__not_in' => array($post->ID),
    'posts_per_page' => 3,
    'ignore_sticky_posts'=> 1 
);

$my_query = new wp_query($args);

if ( $my_query->have_posts() ) : ?>
    <div class="post-section entry-related">
        <h3 class="post-headline t-small t-uppercase"><?php esc_html_e( 'Related Posts', 'filmic' ) ?></h3>
            <div class="row">
                <?php while( $my_query->have_posts() ) : $my_query->the_post(); ?>
                    <div class="col-md-4">
                        <div class="entry-related__single">
                            <div class="entry-related__thumbnail">
                                <a href="<?php the_permalink(); ?>" rel="bookmark">
                                    <?php the_post_thumbnail(); ?>
                                </a>
                            </div>

                            <div class="entry-related__content">
                                <span class="entry-related__time"><?php the_time('M jS, Y'); ?></span>
                                <h3 class="entry-related__title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>

                                <div class="read-more">
                                    <a href="<?php the_permalink(); ?>" class="read-more-link"><?php esc_html_e( 'Continue', 'filmic' ); ?></a>
                                    <span class="ion-ios-arrow-thin-right read-more-icon"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile;
                wp_reset_postdata(); ?>
        </div>
    </div>

<?php endif;