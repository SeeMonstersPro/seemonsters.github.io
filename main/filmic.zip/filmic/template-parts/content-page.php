<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package filmic
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('entry-content'); ?>>
	<?php
		the_content();
		echo filmic_wp_link_pages();

	?>
</article>
