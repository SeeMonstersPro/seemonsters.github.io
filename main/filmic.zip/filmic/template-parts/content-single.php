<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package filmic
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php echo filmic_post_thumbnail(); ?>
	<div class="entry-container">
		<?php echo filmic_entry_time(); ?>

		<div class="entry-wrapper">
    		<?php echo filmic_entry_header(); ?>

    		<div class="entry-content">
    			<?php the_content(); filmic_wp_link_pages(); ?>
            </div><!-- .entry-content -->
          
            <div class="entry-meta">
                <div class="entry-tags">
                  <?php the_tags(esc_html__('Tags: ', 'filmic'), ', ', ''); ?>
                </div><!-- .entry-tags -->
            </div>
		</div>
	</div>
    <?php get_template_part('template-parts/content', 'related'); ?>		
</article>