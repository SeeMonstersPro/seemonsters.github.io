<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package filmic
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<div class="entry-thumbnail">
			<a href="<?php echo get_permalink( $post->ID ); ?>">
				<?php the_post_thumbnail(); ?>
			</a>
		</div><!-- entry-thumbnail -->
	<?php endif; ?>
	<div class="entry-container">
		<a class="entry-time" href="<?php echo get_permalink( $post->ID ); ?>">
			<span class="entry-date"><?php echo get_the_date('d'); ?></span>
			<span class="entry-month t-small t-uppercase"><?php echo get_the_date('M'); ?></span>
		</a><!-- entry-time -->

		<div class="entry-wrapper">
			<header class="entry-header">
				<div class="entry-categories t-small"><?php the_category( ', ' ); ?></div>
				<?php
				if ( is_single() ) :
					the_title( '<h1 class="entry-title">', '</h1>' );
				else :
					the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
				endif;
				?>
			</header><!-- .entry-header -->

			<div class="entry-excerpt">
				<?php
					the_excerpt();
				?>
			</div><!-- .entry-excerpt -->
		</div><!-- .entry-wrapper -->
	</div><!-- .entry-container -->
</article><!-- #post-## -->