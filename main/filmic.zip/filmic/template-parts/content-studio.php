<?php
/**
 * Template part for displaying studio single page
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package filmic
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('entry-content'); ?>>
	<?php
		the_content();
		echo filmic_next_prev_links();
		
	?>
</article>
