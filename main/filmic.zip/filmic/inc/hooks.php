<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

if ( ! function_exists( 'filmic_action_theme_setup' ) ) : /**
 * Theme setup.
 *
 * Set up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support post thumbnails.
 * @internal
 */ {
	function filmic_action_theme_setup() {

		/*
		 * Make Theme available for translation.
		 */
		load_theme_textdomain( 'filmic', get_template_directory() . '/languages' );

		// Add RSS feed links to <head> for posts and comments.
		add_theme_support( 'automatic-feed-links' );

		// Enable support for Post Thumbnails, and declare two sizes.
		add_theme_support( 'post-thumbnails' );

		add_image_size( 'filmic-740x540-thumbnail-list', 740, 540, true );

		add_theme_support('title-tag');

		add_theme_support( 'boostify-header-footer' );

		add_theme_support( 'woocommerce', array(
			// 'thumbnail_image_width' => 150,
			// 'single_image_width'    => 300,

			'product_grid'          => array(
				'default_rows'    => 3,
				'min_rows'        => 2,
				'max_rows'        => 8,
				'default_columns' => 4,
				'min_columns'     => 2,
				'max_columns'     => 5,
			),
		) );

		add_theme_support( 'wc-product-gallery-slider' );
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );

		add_theme_support( 'custom-logo', array(
				'height'      => 55,
				'width'       => 205,
				'flex-width' => true,
                'flex-height' => true,
		) );

		/*
		 * Enable support for Post Formats.
		 * See http://codex.wordpress.org/Post_Formats
		 */
		add_theme_support( 'post-formats', array(
			'aside',
			'image',
			'video',
			'audio',
			'quote',
			'link',
			'gallery',
		) );

		// This theme uses its own gallery styles.
		add_filter( 'use_default_gallery_style', '__return_false' );
	}
}
endif;
add_action( 'after_setup_theme', 'filmic_action_theme_setup' );

/**
 * Register widget area
 */
function filmic_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Blog Sidebar', 'filmic' ),
		'id'            => 'sidebar-blog',
		'description'   => esc_html__( 'Blog Sidebar', 'filmic' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title t-uppercase t-small">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Shop Sidebar', 'filmic' ),
		'id'            => 'sidebar-shop',
		'description'   => esc_html__( 'Shop Sidebar', 'filmic' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="widget-title t-uppercase t-small">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'			=> esc_html__( 'Footer Sidebar', 'filmic' ),
		'id'			=> 'sidebar-footer',
		'description'	=> esc_html__( 'Footer Sidebar', 'filmic' ),
		'before_widget'	=> '<div id="%1$s" class="col-md-6 col-lg-3 widget site-footer__widget %2$s">',
		'after_widget'	=> '</div>',
		'before_title'	=> '<h3 class="site-footer__widget-title t-uppercase t-small">',
		'after_title'	=> '</h3>'
	) );
}
add_action( 'widgets_init', 'filmic_widgets_init' );

/**
 * Install Demo content
 */
function filmic_backups_demos($demos) {
	$demos_array = array(
		'filmic' => array(
			'title' => esc_html__('Filmic Demo', 'filmic'),
			'screenshot' => get_template_directory_uri().'/screenshot.jpg',
			'preview_link' => '//filmic.boostifythemes.com/',
		)
		// ...
	);

	$download_url = 'https://boostifythemes.com/ht-demos/';

	foreach ($demos_array as $id => $data) {
		$demo = new FW_Ext_Backups_Demo($id, 'piecemeal', array(
			'url' => $download_url,
			'file_id' => $id,
		));
		$demo->set_title($data['title']);
		$demo->set_screenshot($data['screenshot']);
		$demo->set_preview_link($data['preview_link']);

		$demos[ $demo->get_id() ] = $demo;

		unset($demo);
	}

	return $demos;
}

add_filter('fw:ext:backups-demo:demos', 'filmic_backups_demos');


/* enqueue google fonts
------------------------------------------------->*/
function filmic_google_fonts_url() {
    $font_url = '';
    if ( 'off' !== _x( 'on', 'Google font: on or off', 'filmic' ) ) {
        $font_url = add_query_arg( 'family', urlencode( 'Playfair Display:400,700&subset=latin,latin-ext' ), "//fonts.googleapis.com/css" );
    }
    return $font_url;
}
function filmic_google_fonts_scripts() {
    wp_enqueue_style( 'filmic-fonts', filmic_google_fonts_url(), array(), '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'filmic_google_fonts_scripts' );



function filmic_cat_count_span($links) {
  $links = str_replace('(', '<span class="cat-item-count">', $links);
  $links = str_replace(')', '</span>', $links);
  return $links;
}
add_filter('get_archives_link', 'filmic_cat_count_span');
add_filter('wp_list_categories', 'filmic_cat_count_span');

function filmic_excerpt_more($more) {
	global $post;
	return '... <div class="read-more"><a href="' . get_permalink($post->ID) . '" class="read-more-link">Continue</a><span class="ion-ios-arrow-thin-right read-more-icon"></span></div>';
}

add_filter('excerpt_more', 'filmic_excerpt_more');


function filmic_move_comment_field_to_bottom( $fields ) {
	$comment_field = $fields['comment'];
	unset($fields['comment']);
	$fields['comment'] = $comment_field;
	return $fields;
}

add_filter('comment_form_fields', 'filmic_move_comment_field_to_bottom');


/*body classes*/
add_filter( 'body_class', 'filmic_classes' );
function filmic_classes( $classes ) {
    /*! BROWSER DETECT
    ------------------------------------------------->*/
    global $is_IE, $is_safari, $is_iphone;

    if( $is_safari ) $classes[]     = 'safari-detected';
    elseif( $is_IE ) $classes[]     = 'ie-detected';
    elseif( $is_iphone ) $classes[] = 'iphone-detected';


    if(filmic_blog()){
        $classes[] = 'group-blog';
    }

    if( ! class_exists( 'Kirki' ) ){
        $classes[] = 'no-kirki-customize';
    }

    return $classes;
}

/*Custom css for admin*/
function filmic_load_wp_admin_style() {
    if(class_exists('WPBakeryVisualComposerAbstract')){
        /*ionicon font - for vc-builder*/
        wp_enqueue_style( 'filmic-vc-icon', get_template_directory_uri() . '/css/vc-icon.css');
        if(class_exists('Kirki')){
            /*kirki custom css*/
            wp_enqueue_style( 'filmic-kirki-custom', get_template_directory_uri() . '/css/kirki-custom.css');
        }
    }
}
add_action( 'admin_enqueue_scripts', 'filmic_load_wp_admin_style' );

// Add FullpageJS plugin
function filmic_add_files() {
	wp_enqueue_style( 'fullpage-css', get_template_directory_uri() . '/css/jquery.fullpage.min.css' );
	wp_enqueue_style( 'fullpage-custom.css', get_template_directory_uri() . '/css/fullpage-custom.css' );
	wp_enqueue_style( 'dropkick-css', get_template_directory_uri() . '/css/dropkick.css' );
	wp_enqueue_script( 'fullpage-js', get_template_directory_uri() . '/js/jquery.fullpage.min.js', array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'dropkick-js', get_template_directory_uri() . '/js/dropkick.js', array( 'jquery' ), '1.0', true );
}
add_action( 'wp_enqueue_scripts', 'filmic_add_files' );

/**
 * Ensure cart contents update when products are added to the cart via AJAX
 */
function filmic_add_to_cart_fragment( $fragments ) {

    ob_start();
	?>
	<span class="cart-contents-count"><?php echo sprintf('%d', WC()->cart->cart_contents_count); ?></span>
	<?php

    $fragments['#minicart .cart-contents-count'] = ob_get_clean();

    return $fragments;
}
add_action( 'woocommerce_add_to_cart_fragments', 'filmic_add_to_cart_fragment' );

remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
add_action( 'add_to_cart_fragments', 'wpex_main_menu_cart_link_fragments', 10 );
add_action( 'woocommerce_before_main_content', 'filmic_wrap_row_before', 5);
add_action( 'woocommerce_before_main_content', 'filmic_wrap_col_before', 10);
add_action( 'woocommerce_after_main_content' , 'filmic_wrap_col_after', 10);
add_action( 'woocommerce_after_main_content' , 'filmic_wrap_row_after', 20);
add_action( 'woocommerce_before_main_content' , 'filmic_shop_sidebar', 5);
remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar');
remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
add_filter('woocommerce_show_page_title', '__return_false');

function filmic_wrap_row_before(){
	echo '<div class="container"><div class="row">';
}
function filmic_wrap_row_after(){
	echo '</div></div>';
}
function filmic_wrap_col_before(){
	if( is_active_sidebar( 'sidebar-shop' ) && is_shop() ){
		echo '<div class="col-lg-9">';
	}else{
		echo '<div class="col-lg-12">';
	}

}

// Update cart link with AJAX
function wpex_main_menu_cart_link_fragments( $fragments ) {
	global $woocommerce;

	  ob_start();

	  $fragments['.wpex-menu-cart-total'] = ob_get_clean();

	  return $fragments;
}



function filmic_wrap_col_after(){
	echo '</div>';
}

function filmic_shop_sidebar(){
	get_sidebar();
}

function filmic_scroll_to_top() {
	?>
		<span class="scroll-to-top ion-ios-arrow-up" aria-label="<?php esc_attr_e('Back to top', 'filmic'); ?>" title="<?php esc_attr_e('Scroll To Top', 'filmic'); ?>"></span>
	<?php
}
add_action( 'boostify_hf_get_footer', 'filmic_scroll_to_top', 10 );