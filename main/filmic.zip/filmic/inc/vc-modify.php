<?php
/*modify default shortcode======================================================*/
if ( class_exists( 'WPBakeryVisualComposerAbstract' ) ) {
    /*vc_row*/
    $theme_row = array(
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Row stretch', 'filmic' ),
            'param_name' => 'full_width',
            'value' => array(
                esc_html__( 'Default', 'filmic' ) => '',
                esc_html__( 'Stretch row', 'filmic' ) => 'stretch_row',
                esc_html__( 'Stretch row and content', 'filmic' ) => 'stretch_row_content',
                esc_html__( 'Stretch row and content (no paddings)', 'filmic' ) => 'stretch_row_content_no_spaces',
                esc_html__( 'Theme fullwidth', 'filmic' ) => 'theme_default',
            ),
            'description' => esc_html__( 'Select stretching options for row and content (Note: stretched may not work properly if parent container has "overflow: hidden" CSS property).', 'filmic' ),
        ),
    );
    vc_add_params( 'vc_row', $theme_row );

    /*custom heading*/
    $theme_product = array(
        array(
            'type' => 'textfield',
            'heading' => esc_html__( 'Subtitle', 'filmic' ),
            'param_name' => 'subtitle',
            'value' => ''
        ),
        array(
            'type'        => 'dropdown',
            'heading'     => esc_html__('Font weight', 'filmic' ),
            'param_name'  => 'font_weight',
            'dependency' => array(
                'element' => 'use_theme_fonts',
                'value' => 'yes'
            ),
            'value' => array(300,400,500,600,700,800,900),
            'std' => 600
        ),
        array(
            'type'        => 'checkbox',
            'heading'     => esc_html__('Custom Style?', 'filmic' ),
            'param_name'  => 'custom_style',
            'value' => array(
                esc_html__('Yes', 'filmic') => 'yes',
            ),
            'std' => 'no'
        )
    );
    vc_add_params( 'vc_custom_heading', $theme_product);

    /*vc_btn*/
    $theme_button = array(
        /*style*/
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Style', 'filmic' ),
            'description' => esc_html__( 'Select button display style.', 'filmic' ),
            'param_name' => 'style',
            'value' => array(
                esc_html__( 'Modern', 'filmic' ) => 'modern',
                esc_html__( 'Classic', 'filmic' ) => 'classic',
                esc_html__( 'Flat', 'filmic' ) => 'flat',
                esc_html__( 'Outline', 'filmic' ) => 'outline',
                esc_html__( '3d', 'filmic' ) => '3d',
                esc_html__( 'Custom', 'filmic' ) => 'custom',
                esc_html__( 'Outline custom', 'filmic' ) => 'outline-custom',
                esc_html__( 'Gradient', 'filmic' ) => 'gradient',
                esc_html__( 'Gradient Custom', 'filmic' ) => 'gradient-custom',
                esc_html__( 'Filmic Button', 'filmic' ) => 'filmic-btn',
            ),
            'std' => 'filmic-btn'
        ),
        /*disable color option*/
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Color', 'filmic' ),
            'param_name' => 'color',
            'description' => esc_html__( 'Select button color.', 'filmic' ),
            'param_holder_class' => 'vc_colored-dropdown vc_btn3-colored-dropdown',
            'value' => array(
                    esc_html__( 'Classic Grey', 'filmic' ) => 'default',
                    esc_html__( 'Classic Blue', 'filmic' ) => 'primary',
                    esc_html__( 'Classic Turquoise', 'filmic' ) => 'info',
                    esc_html__( 'Classic Green', 'filmic' ) => 'success',
                    esc_html__( 'Classic Orange', 'filmic' ) => 'warning',
                    esc_html__( 'Classic Red', 'filmic' ) => 'danger',
                    esc_html__( 'Classic Black', 'filmic' ) => 'inverse',
                ) + getVcShared( 'colors-dashed' ),
            'std' => 'grey',
            'dependency' => array(
                'element' => 'style',
                'value_not_equal_to' => array(
                    'custom',
                    'outline-custom',
                    'gradient',
                    'gradient-custom',
                    'filmic-btn',
                ),
            ),
        ),
    );
    vc_add_params( 'vc_btn', $theme_button );
}

/*modify google font list======================================================*/
if ( ! function_exists( 'helper_vc_fonts' ) ) {
    function filmic_add_new_gg_fonts( $fonts_list ) {
        $poppins->font_family = 'Poppins';
        $poppins->font_types = '300 light:300:normal,300 light italic:300:italic,400 regular:400:normal,400 italic:400:italic,500 medium:500:normal,500 medium italic:500:italic,600 semi-bold:600:normal,600 semi-bold italic:600:italic,700 bold:700:normal,700 bold italic:700:italic';
        $poppins->font_styles = 'regular,italic,300italic,400italic,500italic,600italic,700italic';
        $poppins->font_family_description = esc_html_e( 'Select font family', 'filmic' );
        $poppins->font_style_description = esc_html_e( 'Select font styling', 'filmic' );
        $fonts_list[] = $poppins;

        return $fonts_list;
    }
    add_filter('vc_google_fonts_get_fonts_filter', 'filmic_add_new_gg_fonts');
}