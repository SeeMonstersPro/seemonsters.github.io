<?php
/**
 * Theme Customizer
 */
Filmic_Kirki::add_config( 'filmic', array(
    'option_type' => 'theme_mod',
    'capability'  => 'edit_theme_options',
) );

// Add the general section
require get_template_directory() . '/inc/customizers/general.php';

// Add the header section
require get_template_directory() . '/inc/customizers/header.php';

// Add the page header section
require get_template_directory() . '/inc/customizers/page-header.php';

// Add blog customizer
require get_template_directory() . '/inc/customizers/blog.php';

// Add the color section & control ******
require get_template_directory(). '/inc/customizers/color.php';

// Add typography section & conrol 
require get_template_directory(). '/inc/customizers/typography.php';

// Add footer customizer
require get_template_directory() . '/inc/customizers/footer.php';