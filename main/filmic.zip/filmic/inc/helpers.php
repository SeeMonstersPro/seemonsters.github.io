<?php

// @codingStandardsIgnoreStart
if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 *
 * @package filmic
 */

/*remove query strings*/
add_filter( 'script_loader_src', 'filmic_remove_query_string', 15, 1 );
add_filter( 'style_loader_src', 'filmic_remove_query_string', 15, 1 );
function filmic_remove_query_string( $src ){
    $parts = explode( '?ver', $src );
    return $parts[0];
}

if ( ! function_exists( 'filmic_posted_on' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function filmic_posted_on() {
	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
	}

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);

	$posted_on = sprintf(
		esc_html_x( 'Posted on %s', 'post date', 'filmic' ),
		'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
	);

	$byline = sprintf(
		esc_html_x( 'by %s', 'post author', 'filmic' ),
		'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	echo '<span class="posted-on">' . $posted_on . '</span><span class="byline"> ' . $byline . '</span>'; // WPCS: XSS OK.

}
endif;

if ( ! function_exists( 'filmic_entry_footer' ) ) :
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function filmic_entry_footer() {
	// Hide category and tag text for pages.
	if ( 'post' === get_post_type() ) {
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( esc_html__( ', ', 'filmic' ) );
		if ( $categories_list && filmic_categorized_blog() ) {
			printf( '<span class="cat-links">' . esc_html__( 'Posted in %1$s ', 'filmic' ) . '</span>', $categories_list ); // WPCS: XSS OK.
		}

		/* translators: used between list items, there is a space after the comma */
		$tags_list = get_the_tag_list( '', esc_html__( ', ', 'filmic' ) );
		if ( $tags_list ) {
			printf( '<span class="tags-links">' . esc_html__( 'Tagged %1$s ', 'filmic' ) . '</span>', $tags_list ); // WPCS: XSS OK.
		}
	}

	if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		echo '<span class="comments-link">';
		/* translators: %s: post title */
		comments_popup_link( sprintf( wp_kses(__( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'filmic' ), array( 'span' => array( 'class' => array() ) ) ), get_the_title() ) );
		echo '</span>';
	}

	edit_post_link(
		sprintf(
			/* translators: %s: Name of current post */
			esc_html__( 'Edit %s', 'filmic' ),
			the_title( '<span class="screen-reader-text">"', '"</span>', false )
		),
		'<span class="edit-link">',
		'</span>'
	);
}
endif;

/**
 * Returns true if a blog has more than 1 category.
 *
 * @return bool
 */
function filmic_categorized_blog() {
	if ( false === ( $all_the_cool_cats = get_transient( 'filmiccategories' ) ) ) {
		// Create an array of all the categories that are attached to posts.
		$all_the_cool_cats = get_categories( array(
			'fields'     => 'ids',
			'hide_empty' => 1,
			// We only need to know if there is more than one category.
			'number'     => 2,
		) );

		// Count the number of categories that are attached to the posts.
		$all_the_cool_cats = count( $all_the_cool_cats );

		set_transient( 'filmiccategories', $all_the_cool_cats );
	}

	if ( $all_the_cool_cats > 1 ) {
		// This blog has more than 1 category so filmic_categorized_blog should return true.
		return true;
	} else {
		// This blog has only 1 category so filmic_categorized_blog should return false.
		return false;
	}
}

/*check page-header `on` or `off`*/
if(!function_exists('filmic_bread')):
    function filmic_bread(){
        $bread = get_theme_mod('c_bread', true);

        $pid = get_queried_object_id();
        $p_bread = (function_exists('fw_get_db_post_option')) ? fw_get_db_post_option($pid, 'p_bread') : true;

        if(isset($p_bread['gadget']) && $p_bread['gadget'] == 'disable'){
            $bread = false;
        }

        if(isset($p_bread['gadget']) && $p_bread['gadget'] == 'custom'){
            $bread = true;
        }

        return $bread;
    }
endif;

if ( ! function_exists( 'filmic_entry_time' ) ) {
/**
 * Prints HTML with meta information for date and month
 */
	function filmic_entry_time() {
        global $post;
		?>
		<a class="entry-time" href="<?php echo get_permalink( $post->ID ); ?>">
			<span class="entry-date"><?php echo get_the_date('d'); ?></span>
			<span class="entry-month t-small t-uppercase"><?php echo get_the_date('M'); ?></span>
		</a><!-- entry-time -->
		<?php
	}
}

if ( ! function_exists( 'filmic_post_thumbnail' ) ) {
/**
 * Print HTML with post thumbnail
*/
	function filmic_post_thumbnail() {
		if ( has_post_thumbnail() ) : ?>
		<div class="entry-thumbnail">
      <?php the_post_thumbnail( 'single-post-full-width' ); ?>
		</div><!-- entry-thumbnail -->
		<?php endif;
	}
}

/*header blog post single*/
if ( ! function_exists( 'filmic_entry_header' ) ) {
	function filmic_entry_header() { ?>
		<header class="entry-header">
			<div class="entry-categories t-small"><?php the_category( ', ' ); ?></div>
			<?php if(!filmic_bread()){
                /*not showing title on single page*/
                the_title( '<h2 class="entry-title">', '</h2>' );
            } ?>
		</header>
		<?php
	}
}

/*wp_link_pages*/
if(!function_exists('filmic_wp_link_pages')):
    function filmic_wp_link_pages(){
        $args = array(
            'before' => '<div class="theme-page-links flw">',
            'after' => '</div>',
            'link_before' => '<span>',
            'link_after'  => '</span>',
        );
        return wp_link_pages($args);
    }
endif;

/*blog pagination*/
if (!function_exists( 'filmic_paging' ) ) :
    function filmic_paging( $wp_query = null ) {

        if ( ! $wp_query ) {
            $wp_query = $GLOBALS['wp_query'];
        }

        /*Don't print empty markup if there's only one page.*/

        if ( $wp_query->max_num_pages < 2 ) {
            return;
        }

        $paged        = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
        $pagenum_link = html_entity_decode( get_pagenum_link() );
        $query_args   = array();
        $url_parts    = explode( '?', $pagenum_link );

        if ( isset( $url_parts[1] ) ) {
            wp_parse_str( $url_parts[1], $query_args );
        }

        $pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
        $pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

        $format = $GLOBALS['wp_rewrite']->using_index_permalinks() && ! strpos( $pagenum_link,
            'index.php' ) ? 'index.php/' : '';
        $format .= $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit( 'page/%#%',
            'paged' ) : '?paged=%#%';

        /*Set up paginated links.*/
        $links = paginate_links( array(
            'base'      => $pagenum_link,
            'format'    => $format,
            'total'     => $wp_query->max_num_pages,
            'current'   => $paged,
            'mid_size'  => 1,
            'add_args'  => array_map( 'urlencode', $query_args ),
            'prev_text' => '<span class="ion-arrow-left-b t-small"></span>',
            'next_text' => '<span class="ion-arrow-right-b t-small"></span>',
            'type'      => 'list'
        ) );

        if ( $links ) : ?>
            <nav class="ht-pagination">
                <span class="screen-reader-text"><?php esc_html_e( 'Posts pagination', 'filmic'); ?></span>
                <?php echo wp_kses_post($links); ?>
            </nav>
        <?php endif;
    }
endif;

/* HEADER LAYOUT===================== */
if(!function_exists('filmic_header_layout')){
    function filmic_header_layout(){
        /*PAGE OPTIONS*/
        $pid = get_queried_object_id();
        $p_header_layout = (function_exists('fw_get_db_post_option')) ? fw_get_db_post_option($pid, 'page_header_layout') : 'default';

        /*CUSTOMIZER*/
        $c_header_layout = get_theme_mod('header_layout_cfg', 'layout-1');

        if(isset($p_header_layout['gadget']) && $p_header_layout['gadget'] != 'default' ){
            switch($p_header_layout['gadget']){
                case 'layout-1' :
                    get_template_part('page-templates/header', 'layout-1');
                    break;
                case 'layout-2' :
                    get_template_part('page-templates/header', 'layout-2');
                    break;
                case 'layout-3' :
                    get_template_part('page-templates/header', 'layout-3');
                    break;
            }
        }else{
            switch($c_header_layout){
                case 'layout-2' :
                    get_template_part('page-templates/header', 'layout-2');
                    break;
                case 'layout-3' :
                    get_template_part('page-templates/header', 'layout-3');
                    break;
                case 'layout-1' :
                    default :
                    get_template_part('page-templates/header', 'layout-1');
                    break;
            }
        }
    }
}

/*logo*/
if(!function_exists('filmic_logo_image')){
    function filmic_logo_image(){
        $pid = get_queried_object_id();
        $p_lg = function_exists('fw_get_db_post_option') ? fw_get_db_post_option($pid, 'p_lg') : '';

        $logo_id = get_theme_mod('custom_logo');
        $c_lg = wp_get_attachment_image_src( $logo_id, 'full' );

        $tag = 'figure';
        $tag_child = 'figcaption';
        if( is_front_page() ){
            $tag = 'h1';
            $tag_child = 'span';
        }


        if(isset($p_lg['gadget']) && $p_lg['gadget'] == 'custom'){
            $lg_img = $p_lg['custom']['lg_data']['url']; ?>
            <<?php echo esc_attr($tag); ?> itemscope itemtype="http://schema.org/Organization" class="theme-logo">
                <a href="<?php echo esc_url(home_url('/')); ?>" itemprop="url">
                    <img src="<?php echo esc_url($lg_img); ?>"
                        alt="<?php esc_attr_e('Logo image', 'filmic'); ?>"
                        itemprop="logo" >
                </a>
                <<?php echo esc_attr($tag_child); ?> class="screen-reader-text"><?php echo esc_attr( bloginfo( 'name' ) ); ?></<?php echo esc_attr($tag_child); ?>>
            </<?php echo esc_attr($tag); ?>>
        <?php }else{
            $lg_img = ($c_lg != '') ? $c_lg[0] : get_template_directory_uri().'/images/logo.png'; ?>
            <<?php echo esc_attr($tag); ?> itemscope itemtype="http://schema.org/Organization" class="theme-logo">
                <a href="<?php echo esc_url(home_url("/")); ?>" itemprop="url">
                    <img
                        src="<?php echo esc_url($lg_img); ?>"
                        alt="<?php esc_attr_e('Logo image', 'filmic'); ?>"
                        itemprop="logo" >
                </a>
                <<?php echo esc_attr($tag_child); ?> class="screen-reader-text"><?php echo esc_attr( bloginfo( 'name' ) ); ?></<?php echo esc_attr($tag_child); ?>>
            </<?php echo esc_attr($tag); ?>>
        <?php }
    }
}

/*film detect blog page*/
if(!function_exists('filmic_blog')):
    function filmic_blog() {
        global $post;
        $post_type = get_post_type($post );
        return ( (is_archive() || is_author() || is_category() || is_home() || is_single() || is_tag()) && $post_type == 'post' ) ? true : false;
    }
endif;

/*Remove Rev Slider Metabox*/
if ( is_admin() ) {
    function film_remove_rev_slider_meta_boxes($post_type){
        add_action('do_meta_boxes', function () use ($post_type) {
            remove_meta_box('mymetabox_revslider_0', $post_type, 'normal');
        });
    }
    add_action('registered_post_type', 'film_remove_rev_slider_meta_boxes');
}

/*set content width*/
if ( ! isset( $content_width ) ) $content_width = 1170;

/*img alt*/
if(!function_exists('filmic_img_alt')):
    function filmic_img_alt($id = null, $alt = '' ){
        $img_alt = (get_post_meta($id,'_wp_attachment_image_alt', true) != '') ? get_post_meta($id,'_wp_attachment_image_alt', true) : $alt;
        return $img_alt;
    }
endif;

/*edit location*/
if(!function_exists('filmic_edit_location')){
    function filmic_edit_location($id = ''){
        $option = $id.'_edit_location';
        if(is_customize_preview()):
            echo '<div id="' . esc_attr($id) . '-edit-location">';
                if ( class_exists( 'Kirki' ) ){echo Kirki::get_option($option);}
            echo '</div>';
        endif;
    }
}

/*customizer label*/
if(!function_exists('filmic_label')){
    function filmic_label($data = ''){
        $output  = '<span style="padding: 7px 10px; background-color: #0073aa; color: #fff; display: block">' .  $data . '</span>';
        return $output;
    }
}

function filmic_right_header_layout(){
    ?>
    <div class="r-header-layout">
        <?php

        if ( class_exists( 'WooCommerce' ) ) {

            $count = WC()->cart->cart_contents_count;
            ?>
            <div class="cart_mini flex">
                <a id="minicart" class="cart-contents" href="<?php echo wc_get_cart_url(); ?>" title="<?php _e( 'View your shopping cart' ); ?>">
                    <span class="ion ion-ios-cart"></span>
                    <?php
                    if ( $count > 0 ) {
                        ?>
                        <span class="cart-contents-count"><?php echo esc_html( $count ); ?></span>
                        <?php
                    }
                echo '</a>';
            ?>

                <div id="cartcontents">
                    <div class="widget_shopping_cart_content">
                        <?php woocommerce_mini_cart(); ?>
                    </div>
                </div>
            </div>
            <?php

        }
        ?>
        <button class="ion-ios-search-strong" id="theme-search-btn"></button>
    </div>
    <?php
}


/*search form on desktop*/
function filmic_desktop_search_form(){
    ?>
    <div class="theme-search-box">
        <form action="<?php echo esc_url(home_url('/')); ?>" class="desktop-search-form">
            <input name="s" type="text" placeholder="<?php esc_attr_e('To search start typing...', 'filmic'); ?>" required>
            <span><?php esc_html_e('Press Enter to search or Esc to close', 'filmic'); ?></span>
        </form>
    </div>
<?php }

/*search form mobile*/
function filmic_mobile_search_form(){ ?>
    <form action="<?php echo esc_url(home_url('/')); ?>" class="mobile-search-form">
        <input name="s" type="text" required>
        <button type="submit"></button>
    </form>
<?php }

/*slick*/
if ( !function_exists( 'filmic_slick_js' ) ) {
    function filmic_slick_js() {
        wp_enqueue_style( 'filmic-slick-css', get_template_directory_uri() . '/css/slick.css', false );
        wp_enqueue_style( 'filmic-slick-theme-css', get_template_directory_uri() . '/css/slick-theme.css', false );
        wp_enqueue_script( 'filmic-slick-js', get_template_directory_uri() . '/js/slick.min.js', array('jquery'), '1.0', true );
        wp_enqueue_script( 'filmic-slick-custom', get_template_directory_uri() . '/js/slick-custom.js' , array( 'jquery' ), true );
    }
}

// Excerpt for Blog Grid Layout
if (!function_exists( 'filmic_grid_excerpt' )) {
    function filmic_grid_excerpt() {
        global $post;
        echo '<div class="read-more"><a href="' . get_permalink($post->ID) . '" class="read-more-link">'. esc_html__('Continue', 'filmic') .'</a><span class="ion-ios-arrow-thin-right read-more-icon"></span></div>';
    }
}

/*svg upload support*/
function filmic_svg_uploads($type){
    $new_type = array();
    $new_type['svg'] = 'image/svg+xml';

    $type = array_merge($type, $new_type );

    return $type;
}
add_action('upload_mimes', 'filmic_svg_uploads');


/*THEME CSS INLINE ************************************************************/
add_action( 'wp_enqueue_scripts', 'film_css_inline', 1001);
function film_css_inline() {
    if(!function_exists('FW')) return;

    $css = '';
    /*page id*/
    $id = get_queried_object_id();
    $page_id = '.page-id-' . $id;

    /*DEFAULT FONT STYLE*/
        if(class_exists('Kirki')){
            $default = get_theme_mod( 'body_typography', array('font-family' => 'Poppins', 'font-size' => '14px'));
            $css .= 'input, select, textarea, button{font-family:' . $default['font-family'] . '; font-size:' . $default['font-size'] . '}';
        }

    /*HEADER LAYOUT=================================*/
        $header_layout = fw_get_db_post_option($id, 'page_header_layout');
        $css .= '@media (min-width: 992px){';

        if(isset($header_layout['gadget']) && $header_layout['gadget'] != 'default' ){
            switch($header_layout['gadget']){
                /*LAYOUT 1*/
                case 'layout-1' :
                    /*header*/
                    $layout = $header_layout['layout-1'];
                    /*menu overlap*/
                    break;
                /*LAYOUT 2*/
                case 'layout-2' :
                    break;
            }
        }
        $css .= '}';

    /*FOOTER==========================================*/
        $p_footer = function_exists('fw_get_db_post_option') ? fw_get_db_post_option(get_the_ID(), 'p_footer') : array();
        if(isset($p_footer['gadget']) && $p_footer['gadget'] == 'custom'){
            $widget_bg = !empty($p_footer['custom']['widget_bg']) ? $p_footer['custom']['widget_bg'] : '#292929';
            $coppy_bg = !empty($p_footer['custom']['coppy_bg']) ? $p_footer['custom']['coppy_bg'] : '#1b1919';

            $css .= $page_id . ' .site-footer__main{background-color: '. esc_attr($widget_bg) .'}';
            $css .= $page_id . ' .site-footer__copyright{background-color: '. esc_attr($coppy_bg) .'}';
        }


    if(empty($css)) return;
    wp_add_inline_style( "kirki-styles-filmic", $css );
}

// Custom Next Previous Post Links
if ( !function_exists( 'filmic_next_prev_links' ) ) {
    function filmic_next_prev_links() {
        $prev_post = get_previous_post();
        $next_post = get_next_post();
        $output = '<div class="post-links">';

        if ( $prev_post ) {
            $prev_title = strip_tags( str_replace( '"', '', $prev_post->post_title ) );
            $output .= '<div class="post-links-prev"><a href="' . get_permalink( $prev_post->ID ) . '">';
            $output .= '<div class="post-links-container">';
            $output .= '<span class="post-links-desc t-small t-uppercase">Previous Studio</span>';
            $output .= '<h4 class="post-links-title">' . $prev_title . '</h4>';
            $output .= '</div></a></div>';
        }

        if ( $next_post ) {
            $next_title = strip_tags( str_replace( '"', '', $next_post->post_title ) );
            $output .= '<div class="post-links-next"><a href="' . get_permalink( $next_post->ID ) . '">';
            $output .= '<div class="post-links-container">';
            $output .= '<span class="post-links-desc t-small t-uppercase">Next Studio</span>';
            $output .= '<h4 class="post-links-title">' . $next_title . '</h4>';
            $output .= '</div></a></div>';
        }

        $output .= '</div>';

        return $output;
    }
}

function filmic_page_header_title($bread_title){
	$blog_title = get_theme_mod('c_blog_title', 'Blog');
    if ( is_day() ) :
        printf( esc_html__( 'Daily Archives: %s', 'filmic'), get_the_date() );
    elseif ( is_month() ) :
        printf( esc_html__( 'Monthly Archives: %s', 'filmic'), get_the_date( esc_html_x( 'F Y', 'monthly archives date format', 'filmic')));
    elseif (is_home()) :
        echo esc_html($blog_title);
    elseif(is_author()):
        $author = (get_query_var('author_name')) ? get_user_by('slug', get_query_var('author_name')) : get_userdata(get_query_var('author'));
        echo esc_html($author->display_name);
    elseif ( is_year() ) :
        printf( esc_html__( 'Yearly Archives: %s', 'filmic'), get_the_date( esc_html_x( 'Y', 'yearly archives date format', 'filmic') ) );
    elseif(is_tag()):
        esc_html_e('Tags: ', 'filmic'); single_tag_title();
    elseif(is_page() || is_single()) :
        echo esc_html($bread_title);
    elseif( class_exists('WooCommerce') ):
        if(is_shop()):
            esc_html_e('Shop', 'filmic');
        endif;
    elseif( is_tax() ) :
        global $wp_query;
        $term = $wp_query->get_queried_object();
        $title = $term->name;
        echo esc_html($title);
    elseif( is_search() ):
        esc_html_e('Search results', 'filmic');
    else :
        esc_html_e( 'Archives', 'filmic');
    endif;
}

if ( ! function_exists( 'filmic_get_sidebar' ) ) {
	/**
	 * Get the sidebar
	 *
	 * @param      string  $sidebar_id The sidebar identifier.
	 * @param      string  $sidebar    The sidebar position.
	 * @param      string  $classes    The class name.
	 */
	function filmic_get_sidebar( $sidebar_id = 'sidebar-blog', $sidebar, $classes = 'col-lg-3 theme-blog-sidebar' ) {
        if ( 'full' != $sidebar && is_active_sidebar( $sidebar_id ) ) :
        	?>
            <div class="<?php echo esc_attr( $classes ); ?>">
                <?php dynamic_sidebar( $sidebar_id ); ?>
            </div>
	        <?php
	    endif;
	}
}
/* CHECK IF ELEMENTOR IS ACTIVE
***************************************************/
    if ( ! function_exists( 'filmic_is_elementor' ) ) :
        function filmic_is_elementor() {
            return defined( 'ELEMENTOR_VERSION' );
        }
    endif;

/* rereieve post type categories */
    function filmic_catelist($postype){
        $cats = get_categories(get_query_var($postype));
        $cate_list = array();
        foreach ($cats as $cat) :
        $args = array(
            'post_type'   => $postype,
            'category__in' => array($cat->term_id)
        );
        $my_query = new WP_Query($args);
        if ($my_query->have_posts() ):
            $cate_list[$cat->slug] = esc_html__( $cat->name, 'filmic' );
        endif;
        endforeach;
        $cate_list[''] = esc_html__( 'All', 'filmic' );
        return $cate_list;
    }
/* convert Strong to Slug */
    function filmic_slug($str, $delimiter = '-'){
        $slug = strtolower(trim(preg_replace('/[\s-]+/', $delimiter, preg_replace('/[^A-Za-z0-9-]+/', $delimiter, preg_replace('/[&]/', 'and', preg_replace('/[\']/', '', iconv('UTF-8', 'ASCII//TRANSLIT', $str))))), $delimiter));
        return $slug;
    }
    /* TOURS WIDGET: GET NARROW DATA SOURCE
    ***************************************************/
    if ( ! function_exists( 'filmic_get_narrow_data' ) ):
        function filmic_get_narrow_data( $type = 'post', $terms = 'category' ) {
            /* $type  = `post` || `term`
            *  $terms = post_type || taxonomy | ex: post, category, product, product_cat, custom_post_type...
            */

            $output = array();
            switch ( $type ):
                case 'post':
                    $tour_args = array(
                        'post_type'           => $terms,
                        'post_status'         => 'publish',
                        'ignore_sticky_posts' => 1,
                        'posts_per_page'      => - 1,
                    );
                    $qr        = new WP_Query( $tour_args );
                    $output    = wp_list_pluck( $qr->posts, 'post_title', 'ID' );
                    break;

                case 'term':
                    $terms  = get_terms( $terms );
                    $output = wp_list_pluck( $terms, 'name', 'term_id' );
                    break;
            endswitch;

            return $output;
        }
    endif;
