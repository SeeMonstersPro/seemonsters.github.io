<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }
/**
 * Include static files: javascript and css
 */

if ( is_admin() ) return;

/*Load our main stylesheet.*/
wp_enqueue_style(
	'filmic-theme-style',
	get_template_directory_uri() . '/style.css',
	array(),
	null
);

/*Swiper css*/
wp_enqueue_style(
    'swiper-style',
    get_template_directory_uri() . '/css/swiper.min.css',
    array(),
    null
);

/*Slick css*/
wp_enqueue_style(
    'slick-style',
    get_template_directory_uri() . '/css/slick.css',
    array(),
    null
);

/*Slick theme*/
wp_enqueue_style(
    'slick-theme',
    get_template_directory_uri() . '/css/slick-theme.css',
    array(),
    null
);


wp_enqueue_style(
    'filmic-lity-css',
    get_template_directory_uri() . '/css/lity.min.css',
    array(),
    null
);

/*comment reply*/
if(is_singular() && comments_open() && get_option('thread_comments')){
    wp_enqueue_script('comment-reply');
}

/*mobile menu*/
wp_enqueue_script(
    'filmic-mobile-menu',
    get_template_directory_uri() . '/js/slim.menu.modified.js',
    array( 'jquery' ),
    null,
    true
);

/*
Slick Js
 */
wp_enqueue_script(
    'slick',
    get_template_directory_uri() . '/js/slick.min.js',
    array( 'jquery' ),
    null,
    true
);
/*
Swiper Js
 */
wp_enqueue_script(
    'swiper',
    get_template_directory_uri() . '/js/swiper.min.js',
    array( 'jquery' ),
    null,
    true
);

wp_enqueue_script(
    'filmic-lity-js',
    get_template_directory_uri() . '/js/lity.min.js',
    array( 'jquery' ),
    false,
    true
);

wp_enqueue_script(
    'isotop-js',
    get_template_directory_uri() . '/js/isotope.pkgd.min.js',
    array( 'jquery' ),
    false,
    true
);

wp_enqueue_script(
    'isotop',
    get_template_directory_uri() . '/js/isotope.js',
    array( 'jquery' ),
    false,
    true
);

/*
Isotope Js
 */
wp_enqueue_script(
    'isotope',
    get_template_directory_uri() . '/js/isotope.pkgd.min.js',
    array( 'jquery' ),
    null,
    true
);

wp_enqueue_script( 'filmic-main-js', get_template_directory_uri() . '/js/custom.js', array( 'jquery' ), null, true );