<?php

/*THEME SHORTCODE*/
add_action( 'init', 'filmic_vc_shortcode' );
if(!function_exists('filmic_vc_shortcode')){
    function filmic_vc_shortcode(){
        /*video lightbox*/
        vc_map( array(
            'name' => esc_html__( 'Video Lightbox', 'filmic' ),
            'base' => 'lightbox',
            'category' => esc_html__( 'Filmic Theme', 'filmic' ),
            'description' => esc_html__( 'Add a video popup', 'filmic' ),
            'icon' => 'fa fa-video-camera',
            'params' => array(

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Title', 'filmic' ),
                    'param_name' => 'title',
                    'value' => '',
                    'admin_label' => true,
                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Subtitle', 'filmic' ),
                    'param_name' => 'subtitle',
                    'value' => '',
                    'admin_label' => true,
                ),

                array(
                    'type' => 'iconpicker',
                    'heading' => esc_html__( 'Font Icon', 'filmic' ),
                    'param_name' => 'font_icon',
                    'value' => 'fa-play',
                    'admin_label' => true,
                    'description' => esc_html__( 'Choose a font icon', 'filmic' ),
                    'dependency' => array(
                        'element' => 'icon',
                        'value' => 'use-font-icon'
                    ),
                ),

                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__( 'Image', 'filmic' ),
                    'param_name' => 'img',
                    'admin_label' => true,
                    'value' => '',
                    'description' => esc_html__( 'Choose an overlay image', 'filmic' )
                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Video URL', 'filmic' ),
                    'param_name' => 'video_url',
                    'value' => esc_html__( 'https://www.youtube.com/watch?v=Q0CbN8sfihY', 'filmic' ),
                    'admin_label' => true,
                ),

                /*INCLUDE BY DEFAULT*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Class', 'filmic' ),
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'filmic'),
                    'admin_label' => true,
                    'param_name' => 'class',
                ),

                array(
                    'type' => 'css_editor',
                    'heading'=> esc_html__( 'CSS', 'filmic' ),
                    'param_name' => 'inline_css',
                    'group' => esc_html__( 'Design Options', 'filmic' ),
                ),
            )
        ) );
        
        /*timeline*/
        vc_map( array(
            'name' => esc_html__( 'Timeline', 'filmic' ),
            'base' => 'timeline',
            'category' => esc_html__( 'Filmic Theme', 'filmic' ),
            'description' => esc_html__( 'Add content for timeline', 'filmic' ),
            'icon' => 'fa fa-clock-o',
            'params' => array(

                array(
                    'type' => 'param_group',
                    'heading' => esc_html__( 'Values', 'filmic' ),
                    'param_name' => 'values',
                    'description' => esc_html__( 'Enter values for year, title and description', 'filmic' ),
                    'value' => urlencode( json_encode( array(
                        array(
                            'year' => esc_html__( '2017', 'filmic' ),
                            'title' => esc_html__( 'Hard work pays off', 'filmic' ),
                            'description' => esc_html__( 'Nullam tempor, ipsum eget egestas viverra, velit augue fringilla arcu, et sollicitudin enim eros nec est. Suspendisse volutpat velit porttitor placerat. Mauris porttitor aliquam bibendum. Nam at ul trices justo. Mauris eget urna magna.', 'filmic' )
                        ),

                        array(
                            'year' => esc_html__( '2016', 'filmic' ),
                            'title' => esc_html__( 'Breaking box office record', 'filmic' ),
                            'description' => esc_html__( 'Pellentesque habitant morbi tristique senectus et netus et malesua fames ac turpis egestas. Etiam velit cursus, tempor ipsum in, tempus lectus. Nullam tempus nisi id nisl luctus, non tempor justo molestie.', 'filmic' )
                        ),

                        array(
                            'year' => esc_html__( '2013', 'filmic' ),
                            'title' => esc_html__( 'Road to success', 'filmic' ),
                            'description' => esc_html__( 'Etiam quis interdum felis, at pellentesque metus. Morbi congue lectus. Donec eleifend ultricies urna et euismod. Sed consectetur tellus eget odio aliquet, vel vestibulum tellus sollicitudin.
                            
                            Mauris porttitor aliquam bibendum. Nam at ultrices justo. Mauris eget urna magna ornare neque lipsum.', 'filmic' )
                        ),

                        array(
                            'year' => esc_html__( '2009', 'filmic' ),
                            'title' => esc_html__( 'Debut Production', 'filmic' ),
                            'description' => esc_html__( 'Aenean et est tristique, dictum lorem vel, porttitor urna. Nullam vitae urna consequat, condimentum est vitae, mollis nulla. Duis ultricies lobortis rhoncus. Duis ut odio ut mauris euismod luctus non non eros. Cras mattis massa ac sem aliquam vestibulum.', 'filmic' )
                        )
                    ) ) ),
                    'params' => array(
                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__( 'Year', 'filmic' ),
                            'param_name' => 'year',
                            'description' => esc_html__( 'Enter the timeline year', 'filmic' ),
                            'admin_label' => true
                        ),

                        array(
                            'type' => 'textfield',
                            'heading' => esc_html__( 'Title', 'filmic' ),
                            'param_name' => 'title',
                            'description' => esc_html__( 'Enter the timeline year', 'filmic' ),
                            'admin_label' => true
                        ),

                        array(
                            'type' => 'textarea',
                            'heading' => esc_html__( 'Description', 'filmic' ),
                            'param_name' => 'description',
                            'description' => esc_html__( 'Enter the timeline description', 'filmic' ),
                            'admin_label' => true
                        ),

                    )
                ),

                /*INCLUDE BY DEFAULT*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Class', 'filmic' ),
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'filmic'),
                    'admin_label' => true,
                    'param_name' => 'class',
                ),

                array(
                    'type' => 'css_editor',
                    'heading'=> esc_html__( 'CSS', 'filmic' ),
                    'param_name' => 'inline_css',
                    'group' => esc_html__( 'Design Options', 'filmic' ),
                ),
            )
        ) );
        
        /*iconbox*/
        vc_map( array(
            'name' => esc_html__( 'Iconbox', 'filmic' ),
            'base' => 'iconbox',
            'category' => esc_html__( 'Filmic Theme', 'filmic' ),
            'description' => esc_html__( 'Add an iconbox', 'filmic' ),
            'icon' => 'fa fa-archive',
            'params' => array(

                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Icon Type', 'filmic' ),
                    'param_name' => 'icon_type',
                    'value' => array(
                        esc_html__( 'Use Font', 'filmic' ) => 'icon_font',
                        esc_html__( 'Use Image', 'filmic' ) => 'icon_image'
                    ),
                    'std' => 'icon_font',
                    'description' => esc_html__( 'Select the icon type', 'filmic' ),
                ),

                array(
                    'type' => 'iconpicker',
                    'heading' => esc_html__( 'Font Icon', 'filmic' ),
                    'param_name' => 'use_icon',
                    'value' => '',
                    'description' => esc_html__( 'Choose a font icon', 'filmic' ),
                    'dependency' => array(
                        'element' => 'icon_type',
                        'value' => 'icon_font'
                    ),
                ),

                array(
                    'type' => 'colorpicker',
                    'heading' => esc_html__( 'Font Icon Color', 'filmic' ),
                    'param_name' => 'icon_font_color',
                    'value' => '#8f8f8f',
                    'description' => esc_html__( 'Choose a font icon color', 'filmic' ),
                    'dependency' => array(
                        'element' => 'icon_type',
                        'value' => 'icon_font'
                    )
                ),

                array( 
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Font Icon Size', 'filmic' ),
                    'param_name' => 'icon_font_size',
                    'value' => '80',
                    'description' => esc_html__( 'Choose a font icon size', 'filmic' ),
                    'dependency' => array(
                        'element' => 'icon_type',
                        'value' => 'icon_font'
                    )
                ),

                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__( 'Image', 'filmic' ),
                    'param_name' => 'use_image',
                    'value' => '',
                    'description' => esc_html__( 'Choose an image', 'filmic' ),
                    'dependency' => array(
                        'element' => 'icon_type',
                        'value' => 'icon_image'
                    )
                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Title', 'filmic' ),
                    'param_name' => 'title',
                    'value' => '',
                    'admin_label' => true,
                ),

                array(
                    'type' => 'textarea',
                    'heading' => esc_html__( 'Description', 'filmic' ),
                    'param_name' => 'description',
                    'value' => '',
                ),

                array(
                    'type' => 'vc_link',
                    'heading' => esc_html__( 'Link', 'filmic' ),
                    'param_name' => 'link',
                    'value' => '',
                    'description' => esc_html__( 'Enter a link', 'filmic' ),                
                ),

                /*INCLUDE BY DEFAULT*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Class', 'filmic' ),
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'filmic'),
                    'admin_label' => true,
                    'param_name' => 'class',
                ),

                array(
                    'type' => 'css_editor',
                    'heading'=> esc_html__( 'CSS', 'filmic' ),
                    'param_name' => 'inline_css',
                    'group' => esc_html__( 'Design Options', 'filmic' ),
                ),

            )
        ) );
    
        /*carousel*/
        vc_map( array(
            'name' => esc_html__( 'Carousel', 'filmic' ),
            'base' => 'carousel',
            'category' => esc_html__( 'Filmic Theme', 'filmic' ),
            'description' => esc_html__( 'Add a carousel', 'filmic' ),
            'icon' => 'fa fa-slideshare',
            'params' => array(

                array(
                    'type' => 'attach_images',
                    'heading' => esc_html__( 'Images', 'filmic' ),
                    'param_name' => 'images',
                    'description' => esc_html__( 'Add some images', 'filmic' ),
                    'admin-label' => true
                ),

                /*INCLUDE BY DEFAULT*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Class', 'filmic' ),
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'filmic'),
                    'admin_label' => true,
                    'param_name' => 'class',
                ),

                array(
                    'type' => 'css_editor',
                    'heading'=> esc_html__( 'CSS', 'filmic' ),
                    'param_name' => 'inline_css',
                    'group' => esc_html__( 'Design Options', 'filmic' ),
                ),

            )
        ) );
        
        /*team members*/
        vc_map( array(
            'name' => esc_html__( 'Team Members', 'filmic' ),
            'base' => 'team_members',
            'category' => esc_html__( 'Filmic Theme', 'filmic' ),
            'description' => esc_html__( 'Add your team members', 'filmic' ),
            'icon' => 'fa fa-users',
            'params' => array(
        
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Select Layout', 'filmic' ),
                    'param_name' => 'layout_type',
                    'value' => array(
                        esc_html__( 'Layout 1', 'filmic' ) => 'layout_1',
                        esc_html__( 'Layout 2', 'filmic' ) => 'layout_2',
                        esc_html__( 'Layout 3', 'filmic' ) => 'layout_3'
                    ),
                    'std' => 'layout_1',
                    'description' => esc_html__( 'Select a layout', 'filmic' )
                ),
        
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__( 'Member Image', 'filmic' ),
                    'param_name' => 'image',
                    'description' => esc_html__( 'Select a member image', 'filmic' ),
                ),
        
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Member Name', 'filmic' ),
                    'param_name' => 'name',
                    'description' => esc_html__( 'Enter the member name', 'filmic' ),
                    'admin_label' => true,
                ),
        
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Member Position', 'filmic' ),
                    'param_name' => 'position',
                    'description' => esc_html__( 'Enter the member position', 'filmic' ),
                    'admin_label' => true,
                ),
        
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__( 'Member Description', 'filmic' ),
                    'param_name' => 'description',
                    'description' => esc_html__( 'Enter the member description', 'filmic' ),
                    'dependency' => array(
                        'element' => 'layout_type',
                        'value' => 'layout_1'
                    )
                ),
        
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Member Facebook Account', 'filmic' ),
                    'param_name' => 'facebook',
                    'description' => esc_html__( 'Enter the member Facebook account', 'filmic' ),
                    'dependency' => array(
                        'element' => 'layout_type',
                        'value' => 'layout_1'
                    )
                ),
        
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Member Twitter Account', 'filmic' ),
                    'param_name' => 'twitter',
                    'description' => esc_html__( 'Enter the member Twitter account', 'filmic' ),
                    'dependency' => array(
                        'element' => 'layout_type',
                        'value' => 'layout_1'
                    )
                ),
        
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Member Instagram Account', 'filmic' ),
                    'param_name' => 'instagram',
                    'description' => esc_html__( 'Enter the member Instagram account', 'filmic' ),
                    'dependency' => array(
                        'element' => 'layout_type',
                        'value' => 'layout_1'
                    )
                ),
        
                /*INCLUDE BY DEFAULT*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Class', 'filmic' ),
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'filmic'),
                    'admin_label' => true,
                    'param_name' => 'class',
                ),
        
                array(
                    'type' => 'css_editor',
                    'heading'=> esc_html__( 'CSS', 'filmic' ),
                    'param_name' => 'inline_css',
                    'group' => esc_html__( 'Design Options', 'filmic' ),
                ),
        
            )
        ) );        

        /*project*/
            $categories = get_terms( 'ht-project-category' );
            $category_arr = $posts_arr = array();
            /*get blog categories*/
            if( !empty( $categories ) && ! is_wp_error( $categories ) ) {
                foreach( $categories as $key ) {
                    $category_arr[] = array( 'label' => $key->name, 'value' => $key->slug );
                }
            }
            /*get blog posts*/
            $args = new WP_Query( array(
                'post_type'      => 'ht-project',
                'posts_per_page' => -1
            ));

            $data = $args->posts;
            if( !empty( $args ) && ! is_wp_error( $args ) ) {
                foreach( $data as $key ) {
                    $posts_arr[] = array( 'label' => $key->post_title, 'value' => $key->post_name );
                }
            }
        vc_map( array(
            'name' => esc_html__( 'Projects', 'filmic' ),
            'base' => 'project',
            'category' => esc_html__( 'Filmic Theme', 'filmic' ),
            'description' => esc_html__( 'Add projects', 'filmic' ),
            'icon' => 'fa fa-product-hunt',
            'params' => array(
                /*style*/
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Style', 'filmic' ),
                    'param_name' => 'style',
                    'admin_label' => true,
                    'value' => array(
                        esc_html__( 'Grid', 'filmic' ) => 'grid',
                        esc_html__( 'Grid No Gap', 'filmic' ) => 'grid-nogap',
                        esc_html__( 'Zigzag', 'filmic' ) => 'zigzag',
                        esc_html__( 'Carousel', 'filmic' ) => 'carousel'
                    ),
                    'std' => 'grid'
                ),
                /*data source*/
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Narrow data source', 'filmic' ),
                    'param_name' => 'source',
                    'admin_label' => true,
                    'value' => array(
                        esc_html__('Categories', 'filmic') => 'cat',
                        esc_html__('Posts', 'filmic') => 'post',
                    ),
                    'std' => 'cat'
                ),
                /*select post by categories*/
                array(
                    'type' => 'autocomplete',
                    'heading' => esc_html__( 'Enter categories', 'filmic' ),
                    'param_name' => 'data_cat',
                    'settings' => array(
                        'multiple' => true,
                        'min_length' => 1,
                        'unique_values' => true,
                        'delay' => 200,
                        'values' => $category_arr
                    ),
                    'dependency' => array(
                        'element' => 'source',
                        'value' => 'cat'
                    )
                ),
                /*select post by posts*/
                array(
                    'type' => 'autocomplete',
                    'heading' => esc_html__( 'Enter posts', 'filmic' ),
                    'param_name' => 'data_post',
                    'settings' => array(
                        'multiple' => true,
                        'min_length' => 1,
                        'unique_values' => true,
                        'delay' => 200,
                        'values' => $posts_arr
                    ),
                    'dependency' => array(
                        'element' => 'source',
                        'value' => 'post'
                    )
                ),

                /*carousel style: show arrow*/
                array(
                    'type' => 'checkbox',
                    'heading' => esc_html__( 'Show arrows', 'filmic' ),
                    'param_name' => 'arrows',
                    'edit_field_class' => 'vc_col-sm-6',
                    'dependency' => array(
                        'element' => 'style',
                        'value' => 'carousel'
                    ),
                    'value' => array(
                        esc_html__( 'Yes', 'filmic' ) => 'yes'
                    ),
                    'std' => 'yes'
                ),
                /*carousel style: show dots*/
                array(
                    'type' => 'checkbox',
                    'heading' => esc_html__( 'Show dots', 'filmic' ),
                    'param_name' => 'dots',
                    'edit_field_class' => 'vc_col-sm-6',
                    'dependency' => array(
                        'element' => 'style',
                        'value' => 'carousel'
                    ),
                    'value' => array(
                        esc_html__( 'Yes', 'filmic' ) => 'yes'
                    ),
                    'std' => 'no'
                ),


                /*total items*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Total items', 'filmic' ),
                    'description' => esc_html__('Set max limit for items or enter -1 to display all', 'filmic' ),
                    'param_name' => 'total',
                    'dependency' => array(
                        'element' => 'source',
                        'value' => 'cat'
                    ),
                    'value' => 6
                ),
                /*column*/
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Column', 'filmic' ),
                    'param_name' => 'column',
                    'value' => array(2,3,4,5),
                    'dependency' => array(
                        'element' => 'style',
                        'value_not_equal_to' => array( 'zigzag', 'carousel' )
                    ),
                    'std' => 3
                ),
                /*overlay content with `grid-nogap` style*/
                array(
                    'type' => 'checkbox',
                    'heading' => esc_html__('Overlay content', 'filmic' ),
                    'param_name' => 'overlay',
                    'value' => array(
                        esc_html__( 'Yes', 'filmic' ) => 'yes'
                    ),
                    'dependency' => array(
                        'element' => 'style',
                        'value' => 'grid-nogap'
                    ),
                    'std' => 'no'
                ),
                /*order by*/
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Order by', 'filmic' ),
                    'description' => esc_html__('Select order type.', 'filmic'),
                    'param_name' => 'orderby',
                    'admin_label' => true,
                    'value' => array(
                        esc_html__('Date', 'filmic') => 'date',
                        esc_html__('Post ID', 'filmic') => 'ID',
                        esc_html__('Author', 'filmic') => 'author',
                        esc_html__('Title', 'filmic') => 'title',
                        esc_html__('Last modified', 'filmic') => 'modified',
                        esc_html__('Name', 'filmic') => 'name',
                        esc_html__('Number of comments', 'filmic') => 'comment_count',
                        esc_html__('Random', 'filmic') => 'rand',
                        esc_html__( 'Your pick', 'filmic' ) => 'post_name__in',
                        esc_html__( 'None', 'filmic' ) => 'none',
                    ),
                    'std' => 'date'
                ),
                /*order*/
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Sort order', 'filmic' ),
                    'description' => esc_html__('Select sorting order.', 'filmic'),
                    'param_name' => 'order',
                    'admin_label' => true,
                    'value' => array(
                        esc_html__('Ascending', 'filmic') => 'ASC',
                        esc_html__('Descending', 'filmic') => 'DESC'
                    ),
                    'std' => 'ASC'
                ),

                /*INCLUDE BY DEFAULT*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Class', 'filmic' ),
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'filmic'),
                    'admin_label' => true,
                    'param_name' => 'class',
                ),

                array(
                    'type' => 'css_editor',
                    'heading'=> esc_html__( 'CSS', 'filmic' ),
                    'param_name' => 'inline_css',
                    'group' => esc_html__( 'Design Options', 'filmic' ),
                ),

            )
        ));
        
        /*studio*/
        vc_map( array(
            'name' => esc_html__( 'Studios', 'filmic' ),
            'base' => 'studio',
            'category' => esc_html__( 'Filmic Theme', 'filmic' ),
            'description' => esc_html__( 'Add studios', 'filmic' ),
            'icon' => 'fa fa-pie-chart',
            'params' => array(
                /*total items*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Total items', 'filmic' ),
                    'description' => esc_html__('Set max limit for items or enter -1 to display all', 'filmic' ),
                    'param_name' => 'total',
                    'value' => 6
                ),
                /*column*/
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Column', 'filmic' ),
                    'param_name' => 'column',
                    'value' => array(2,3,4,5),
                    'std' => 4
                ),
                /*gap*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Gap', 'filmic' ),
                    'description' => esc_html__('Unit: px', 'filmic' ),
                    'param_name' => 'gap',
                    'value' => 20,
                ),
                /*order by*/
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Order by', 'filmic' ),
                    'description' => esc_html__('Select order type.', 'filmic'),
                    'param_name' => 'orderby',
                    'admin_label' => true,
                    'value' => array(
                        esc_html__('Date', 'filmic') => 'date',
                        esc_html__('Post ID', 'filmic') => 'ID',
                        esc_html__('Author', 'filmic') => 'author',
                        esc_html__('Title', 'filmic') => 'title',
                        esc_html__('Last modified', 'filmic') => 'modified',
                        esc_html__('Name', 'filmic') => 'name',
                        esc_html__('Number of comments', 'filmic') => 'comment_count',
                        esc_html__('Random', 'filmic') => 'rand'
                    ),
                    'std' => 'date'
                ),
                /*order*/
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Sort order', 'filmic' ),
                    'description' => esc_html__('Select sorting order.', 'filmic'),
                    'param_name' => 'order',
                    'admin_label' => true,
                    'value' => array(
                        esc_html__('Ascending', 'filmic') => 'ASC',
                        esc_html__('Descending', 'filmic') => 'DESC'
                    ),
                    'std' => 'ASC'
                ),

                /*INCLUDE BY DEFAULT*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Class', 'filmic' ),
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'filmic'),
                    'admin_label' => true,
                    'param_name' => 'class',
                ),

                array(
                    'type' => 'css_editor',
                    'heading'=> esc_html__( 'CSS', 'filmic' ),
                    'param_name' => 'inline_css',
                    'group' => esc_html__( 'Design Options', 'filmic' ),
                ),

            )
        ));

        /*testimonial*/
        vc_map( array(
            'name' => esc_html__( 'Testimonial', 'filmic' ),
            'base' => 'testimonial',
            'category' => esc_html__( 'Filmic Theme', 'filmic' ),
            'icon' => 'fa fa-commenting',
            'description' => 'Add a testimonial',
            'params' => array(
                /*style*/
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Style', 'filmic' ),
                    'param_name' => 'style',
                    'value' => array(
                        esc_html__( 'Style 1', 'filmic' ) => 'style-1',
                        esc_html__( 'Style 2', 'filmic' ) => 'style-2',
                        esc_html__( 'Style 3', 'filmic' ) => 'style-3',
                        esc_html__( 'Style 4', 'filmic' ) => 'style-4'
                    ),
                    'std' => 'style-1'
                ),

                /*INCLUDE BY DEFAULT*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Class', 'filmic' ),
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'filmic'),
                    'admin_label' => true,
                    'param_name' => 'class',
                ),

                array(
                    'type' => 'css_editor',
                    'heading'=> esc_html__( 'CSS', 'filmic' ),
                    'param_name' => 'inline_css',
                    'group' => esc_html__( 'Design Options', 'filmic' ),
                ),
            )        
        ) );

        /*blog*/
        vc_map( array(
            'name' => esc_html__( 'Blog', 'filmic' ),
            'base' => 'blog',
            'description' => 'Add custom blog',
            'category' => esc_html__( 'Filmic Theme', 'filmic' ),
            'icon' => 'fa fa-newspaper-o',
            'params' => array(

                /*style*/
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Style', 'filmic' ),
                    'param_name' => 'style',
                    'value' => array(
                        esc_html__( 'list', 'filmic' ) => 'list',
                        esc_html__( 'grid', 'filmic' ) => 'grid',
                        esc_html__( 'custom', 'filmic' ) => 'custom',
                    ),
                    'std' => 'list',
                    'admin_label' => true
                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Number of posts to display', 'filmic' ),
                    'description' => esc_html__( 'Enter -1 to display all posts', 'filmic' ),
                    'param_name' => 'posts',
                    'value' => 4,
                    'admin_label' => true
                ),

                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Thumbnail Position', 'filmic' ),
                    'param_name' => 'thumbnail',
                    'value' => array(
                        esc_html__( 'Top', 'filmic' ) => 'top',
                        esc_html__( 'Left', 'filmic' ) => 'left'
                    ),
                    'std' => 'top',
                    'admin_label' => true,
                    'dependency' => array(
                        'element' => 'style',
                        'value' => 'list'
                    )
                ),

                /*number of columns*/
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Columns', 'filmic' ),
                    'param_name' => 'columns',
                    'value' => array(2, 3, 4),
                    'std' => 2,
                    'admin_label' => true,
                    'dependency' => array(
                        'element' => 'style',
                        'value_not_equal_to' => 'list'
                    ),
                ),

                /*order by*/
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Order by', 'filmic' ),
					'description' => esc_html__('Select order type.', 'filmic'),
					'param_name' => 'orderby',
					'admin_label' => true,
					'value' => array(
						esc_html__('Date', 'filmic') => 'date',
						esc_html__('Post ID', 'filmic') => 'ID',
						esc_html__('Author', 'filmic') => 'author',
						esc_html__('Title', 'filmic') => 'title',
						esc_html__('Last modified', 'filmic') => 'modified',
						esc_html__('Name', 'filmic') => 'name',
						esc_html__('Number of comments', 'filmic') => 'comment_count',
						esc_html__('Random', 'filmic') => 'rand'
					),
					'std' => 'date'
				),
				/*Sort order*/
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Sort order', 'filmic' ),
					'description' => esc_html__('Select sorting order.', 'filmic'),
					'param_name' => 'order',
					'admin_label' => true,
					'value' => array(
						esc_html__('Ascending', 'filmic') => 'ASC',
						esc_html__('Descending', 'filmic') => 'DESC'
					),
					'std' => 'DESC'
                ),
                
                array(
                    'type' => 'checkbox',
                    'heading' => esc_html__( 'Show pagination?', 'filmic' ),
                    'param_name' => 'pagination',
                    'value' => array(
                        esc_html__( 'Yes', 'filmic' ) => 'yes'
                    ),
                    'std' => 'yes'
                ),

                /*INCLUDE BY DEFAULT*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Class', 'filmic' ),
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'filmic'),
                    'admin_label' => true,
                    'param_name' => 'class',
                ),

                array(
                    'type' => 'css_editor',
                    'heading'=> esc_html__( 'CSS', 'filmic' ),
                    'param_name' => 'inline_css',
                    'group' => esc_html__( 'Design Options', 'filmic' ),
                ),
            )
        ) );

        /*maps*/
        vc_map( array(
            'name' => esc_html__( 'Map', 'filmic' ),
            'base' => 'gmaps',
            'category' => esc_html__( 'Filmic Theme', 'filmic' ),
            'description' => esc_html__( 'Add a custom map', 'filmic' ),
            'icon' => 'fa fa-map-marker',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Google Maps API key required', 'filmic' ),
                    'description' => sprintf( esc_html__( 'Enter your Google Maps API key. %1$s', 'filmic' ) , '<a href="//developers.google.com/maps/documentation/javascript/get-api-key" target="_blank">' . esc_html__( 'Get your API key here' , 'filmic' ) . '</a>' ),
                    'param_name' => 'api_key',
                    'value' => ''
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Coordinate', 'filmic' ),
                    'param_name' => 'address',
                    'admin_label' => true,
                    'value' => '40.713789,-74.010944',
                    'description' => sprintf( esc_html__( 'Enter the coordinate. %1$s', 'filmic' ), '<a href="//gps-coordinates.net/" target="_blank">' . esc_html__('Find it here', 'filmic') . '</a>') 
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__( 'Map Marker', 'filmic' ),
                    'param_name' => 'map_marker',
                    'description' => esc_html__( 'Choose a map marker icon', 'filmic' )
                ),
                array(
                    'type' => 'textarea',
                    'heading' => esc_html__( 'Info Window', 'filmic' ),
                    'param_name' => 'info_window',
                    'description' => esc_html__( 'Enter description for your location', 'filmic' )
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Map Height', 'filmic' ),
                    'param_name' => 'map_height',
                    'value' => '400px'
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Zoom Level', 'filmic' ),
                    'param_name' => 'zoom_level',
                    'value' => 13
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Map Type', 'filmic' ),
                    'admin_label' => true,
                    'param_name' => 'map_type',
                    'description' => esc_html__( 'Choose a map type', 'filmic' ),
                    'value' => array(
                        esc_html__( 'Roadmap', 'filmic' ) => 'ROADMAP',
                        esc_html__( 'Satellite', 'filmic' ) => 'SATELLITE',
                        esc_html__( 'Hybrid', 'filmic' ) => 'HYBRID',
                        esc_html__( 'Terrain', 'filmic' ) => 'TERRAIN'
                    ),
                    'std' => 'ROADMAP'
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Map Style', 'filmic' ),
                    'admin_label' => true,
                    'param_name' => 'map_style',
                    'description' => esc_html__( 'Choose a map style. This approach changes the style of the Roadmap types (base imagery in terrain and satellite views is not affected, but roads, labels, etc. respect styling rules', 'filmic' ),
                    'value' => array(
                        esc_html__( 'Default', 'filmic' ) => 'default',
                        esc_html__( 'Grayscale', 'filmic' ) => 'style1',
                        esc_html__( 'Subtle Grayscale', 'filmic' ) => 'style2',
						esc_html__( 'Apple Maps-esque', 'filmic' ) => 'style3',
						esc_html__( 'Pale Dawn', 'filmic' )        => 'style4',
						esc_html__( 'Muted Blue', 'filmic' )       => 'style5',
						esc_html__( 'Paper', 'filmic' )            => 'style6',
						esc_html__( 'Light Dream', 'filmic' )      => 'style7',
						esc_html__( 'Retro', 'filmic' )            => 'style8',
						esc_html__( 'Avocado World', 'filmic' )    => 'style9',
						esc_html__( 'Shades of Grey', 'filmic' )   => 'style10',
						esc_html__( 'Blue water', 'filmic' )       => 'style11',
						esc_html__( 'Filmic', 'filmic' )     => 'style12',
                    ),
                    'std' => 'style12'
                ),
                /*INCLUDE BY DEFAULT*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Class', 'filmic' ),
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'filmic'),
                    'admin_label' => true,
                    'param_name' => 'class',
                ),
                array(
                    'type' => 'css_editor',
                    'heading'=> esc_html__( 'CSS', 'filmic' ),
                    'param_name' => 'inline_css',
                    'group' => esc_html__( 'Design Options', 'filmic' ),
                ),
            )
        ) );

        /*counter*/
        vc_map( array(
            'name' => esc_html__( 'Counter', 'filmic' ),
            'base' => 'counter',
            'category' => esc_html__( 'Filmic Theme', 'filmic' ),
            'icon' => 'fa fa-hand-pointer-o',
            'description' => 'Add a counter',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Number', 'filmic' ),
                    'admin_label' => true,
                    'param_name' => 'number'
                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Description', 'filmic' ),
                    'admin_label' => true,
                    'param_name' => 'description'
                ),

                /*INCLUDE BY DEFAULT*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Class', 'filmic' ),
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'filmic'),
                    'admin_label' => true,
                    'param_name' => 'class',
                ),

                array(
                    'type' => 'css_editor',
                    'heading'=> esc_html__( 'CSS', 'filmic' ),
                    'param_name' => 'inline_css',
                    'group' => esc_html__( 'Design Options', 'filmic' ),
                ),
            ) 
        ) );

        /*landing*/
        vc_map( array(
            'name' => esc_html__( 'Landing', 'filmic' ),
            'base' => 'landing',
            'category' => esc_html__( 'Filmic Theme', 'filmic' ),
            'icon' => 'fa fa-file-image-o',
            'description' => 'Add a landing',
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Title', 'filmic' ),
                    'admin_label' => true,
                    'param_name' => 'title'
                ),

                array(
                    'type' => 'vc_link',
                    'heading' => esc_html__( 'URL', 'filmic' ),
                    'param_name' => 'link',
                    'description' => esc_html__( 'Add a url for this demo', 'filmic' ) 
                ),

                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__( 'Thumbnail', 'filmic' ),
                    'param_name' => 'thumbnail',
                    'description' => esc_html__( 'Add a thumbnail for this demo', 'filmic' )
                ),

                /*INCLUDE BY DEFAULT*/
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Class', 'filmic' ),
                    'description' => esc_html__('Style particular content element differently - add a class name and refer to it in custom CSS.', 'filmic'),
                    'admin_label' => true,
                    'param_name' => 'class',
                ),

                array(
                    'type' => 'css_editor',
                    'heading'=> esc_html__( 'CSS', 'filmic' ),
                    'param_name' => 'inline_css',
                    'group' => esc_html__( 'Design Options', 'filmic' ),
                ),
            )
        ) );
    }
}