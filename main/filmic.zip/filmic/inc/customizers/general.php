<?php
/*GENERAL===================================================================================================*/

/*Add General section*/
Filmic_Kirki::add_section( 'general', array(
    'title'      => esc_attr__( 'General', 'filmic'),
    'capability' => 'edit_theme_options',
    'priority' => 0
));

/*header layout*/
Filmic_Kirki::add_field( 'filmic', array(
    'type'      => 'select',
    'settings'  => 'header_layout_cfg',
    'label'     => esc_attr__( 'Header Layout', 'filmic' ),
    'placeholder' => esc_attr__('Select your header layout', 'filmic'),/*since 3.0.21*/
    'section'   => 'general',
    'default'   => 'layout-1',
    'description' => esc_attr__('Choose Header Preset Select your main header preset here to apply for all pages', 'filmic'),
    'choices' => array(
        'layout-1' => esc_attr__('Layout 1', 'filmic'),
        'layout-2' => esc_attr__('Layout 2', 'filmic'),
        'layout-3' => esc_attr__('Layout 3', 'filmic'),
    )
));

Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'switch',
    'settings'    => 'sticky_menu',
    'label'       => esc_html__( 'Sticky Menu', 'bros' ),
    'section'     => 'general',
    'default'     => '0',
    'priority'    => 10,
    'choices'     => [
        'on'  => esc_html__( 'Yes', 'bros' ),
        'off' => esc_html__( 'No', 'bros' ),
    ],
) );