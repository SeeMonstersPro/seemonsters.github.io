<?php
/*Add the blog section*/
Filmic_Kirki::add_section( 'blog', array(
    'title'      => esc_attr__( 'Blog', 'filmic'),
    'capability' => 'edit_theme_options'
));

Filmic_Kirki::add_field( 'filmic', array(
	'type'        => 'text',
	'settings'    => 'c_blog_title',
	'label'       => esc_attr__( 'Blog Page Title', 'filmic' ),
	'section'     => 'blog',
	'default'     => 'Blog'
 ) );

Filmic_Kirki::add_field( 'filmic', array(
    'type'        => 'radio-image',
    'settings'    => 'blog_sidebar',
    'label'       => esc_attr__( 'Sidebar', 'filmic' ),
    'description' => esc_attr__( 'Select the sidebar position your blog page', 'filmic' ),
    'section'     => 'blog',
    'choices'     => array(
        'left'   => get_template_directory_uri() . '/images/sidebar/left.png',
        'full' => get_template_directory_uri() . '/images/sidebar/full.png',
        'right'  => get_template_directory_uri() . '/images/sidebar/right.png',
    ),
    'default' => 'right'
 ) );