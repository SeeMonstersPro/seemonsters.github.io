<?php

/*get wordpress menu*/
$list_menu = get_terms('nav_menu');
$menu = array('disable' => esc_attr__('Disable', 'filmic'));
foreach($list_menu as $key){
    $menu[$key->term_id] = $key->name;
}

/*Add the header layout panel*/
Filmic_Kirki::add_panel( 'c_panel', array(
    'title'      => esc_attr__( 'Header Layout', 'filmic'),
    'capability' => 'edit_theme_options',
));

/*Add the header 1 section*/
Filmic_Kirki::add_section( 'header_1', array(
    'title'      => esc_attr__( 'Layout 1', 'filmic'),
    'capability' => 'edit_theme_options',
    'panel'   => 'c_panel',
));

/*Add the header 2 section*/
Filmic_Kirki::add_section( 'header_2', array(
    'title'      => esc_attr__( 'Layout 2', 'filmic'),
    'capability' => 'edit_theme_options',
    'panel'   => 'c_panel',
));

/*Add the header 3 section*/
Filmic_Kirki::add_section( 'header_3', array(
    'title'      => esc_attr__( 'Layout 3', 'filmic'),
    'capability' => 'edit_theme_options',
    'panel'   => 'c_panel',
));


/*HEADER LAYOUT 1====================*/

/*header background color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd1_bg',
    'label' => esc_attr__( 'Background color', 'filmic' ),
    'section' => 'header_1',
    'default' => '#ffffff',
    'transport' => 'auto',
    'output' => array(
        array(
            'element' => '.header-layout-1 .site-header__container',
            'property' => 'background-color'
        )
    ),
    'partial_refresh' => array(
        'hd1_edit_location' => array(
            'selector'        => '#hd1-edit-location',
            'render_callback' => 'filmic_edit_location',
        ),
    ),
));

/*label*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'custom',
    'settings' => 'hd1_parent_menu_label',
    'section' => 'header_1',
    'default'     => filmic_label(esc_attr__('Parent menu option', 'filmic')),
));

/*menu text color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd1_menu',
    'label' => esc_attr__( 'Text color', 'filmic' ),
    'section' => 'header_1',
    'default' => '#8f8f8f',
    'transport' => 'auto',
    'output' => array(
        array(
            'element' => array(
                '.header-layout-1 .site-header__menu > li > a',
                '.header-layout-1 #theme-search-btn'
            ),
            'property' => 'color',
            'media_query' => '@media (min-width: 992px)'
        ),
    )
));

/*menu highlight/hover color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd1_menu_highlight',
    'label' => esc_attr__( 'Text highlight color', 'filmic' ),
    'section' => 'header_1',
    'default' => '#292929',
    'transport' => 'auto',
    'output' => array(
        array(
            'element' => array(
                '.header-layout-1 .site-header__menu > li:hover > a',
                '.header-layout-1 .site-header__menu > li.current-menu-ancestor > a',
                '.header-layout-1 .site-header__menu > li.current-menu-parent > a',
                '.header-layout-1 .site-header__menu > li.current_page_parent > a',
                '.header-layout-1 .site-header__menu > li.current_page_ancestor > a',
                '.header-layout-1 .site-header__menu li.current-menu-item > a',
                '.header-layout-1 #theme-search-btn:hover',
            ),
            'property' => 'color',
            'media_query' => '@media (min-width: 992px)'
        ),
    )
));

/*label*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'custom',
    'settings' => 'hd1_submenu_label',
    'section' => 'header_1',
    'default'     => filmic_label(esc_attr__('Submenu option', 'filmic')),
));

/*submenu text color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd1_submenu_text_color',
    'label' => esc_attr__('Text color', 'filmic'),
    'section' => 'header_1',
    'transport' => 'auto',
    'default' => '#ffffff',
    'output' => array(
        array(
            'element' => array(
                '.header-layout-1 .site-header__menu li .sub-menu a',
                '.header-layout-1 .site-header__menu li.menu-item-has-children:after'
            ),
            'property' => 'color',
            'media_query' => '@media (min-width: 992px)'
        ),
    )
));

/*submenu text highlight color*/
/*Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd1_submenu_text_highlight',
    'label' => esc_attr__('Text highlight', 'filmic'),
    'section' => 'header_1',
    'transport' => 'auto',
    'default' => '#292929',
    'output' => array(
        array(
            'element' => array(
                '.header-layout-1 .site-header__menu .sub-menu a:hover',
                '.header-layout-1 .site-header__menu .sub-menu li.current-menu-item > a'
            ),
            'property' => 'color',
            'media_query' => '@media (min-width: 992px)'
        ),
    )
));*/

/*submenu text highlight background color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd1_submenu_text_highlight_bg',
    'label' => esc_attr__('Background text highlight', 'filmic'),
    'section' => 'header_1',
    'transport' => 'auto',
    'default' => '#454444',
    'output' => array(
        array(
            'element' => array(
                '.header-layout-1 .site-header__menu .sub-menu a:hover',
                '.header-layout-1 .site-header__menu .sub-menu li.current-menu-item > a'
            ),
            'property' => 'background-color',
            'media_query' => '@media (min-width: 992px)'
        ),
    )
));

/*submenu background color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd1_submenu_bg_color',
    'label' => esc_attr__('Background color', 'filmic'),
    'section' => 'header_1',
    'transport' => 'auto',
    'default' => '#292929',
    'output' => array(
        array(
            'element' => array(
                '.header-layout-1 .site-header__menu .sub-menu',
            ),
            'property' => 'background-color',
            'media_query' => '@media (min-width: 992px)'
        )
    )
));


/*sidebar menu*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'select',
    'settings' => 'hd1_sidebar_menu',
    'label' => esc_attr__( 'Sidebar menu', 'filmic' ),
    'section' => 'header_1',
    'choices' => $menu,
    'default' => 'disable',
));


/*HEADER LAYOUT 2====================*/

/*header background color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd2_bg',
    'label' => esc_attr__( 'Background color', 'filmic' ),
    'section' => 'header_2',
    'choices' => array(
        'alpha' => true
    ),
    'default' => 'rgba(255,255,255,0)',
    'transport' => 'auto',
    'output' => array(
        array(
            'element' => '.header-layout-2 .site-header__container',
            'property' => 'background-color'
        )
    ),
    'partial_refresh' => array(
        'hd2_edit_location' => array(
            'selector'        => '#hd2-edit-location',
            'render_callback' => 'filmic_edit_location',
        ),
    ),
));

/*label*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'custom',
    'settings' => 'hd2_parent_menu_label',
    'section' => 'header_2',
    'default'     => filmic_label(esc_attr__('Parent menu option', 'filmic')),
));

/*menu text color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd2_menu',
    'label' => esc_attr__( 'Text color', 'filmic' ),
    'section' => 'header_2',
    'default' => '#8f8f8f',
    'transport' => 'auto',
    'output' => array(
        array(
            'element' => array(
                '.header-layout-2 .site-header__menu > li > a',
                '.header-layout-2 #theme-search-btn'
            ),
            'property' => 'color',
            'media_query' => '@media (min-width: 992px)'
        ),
    )
));

/*menu highlight/hover color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd2_menu_highlight',
    'label' => esc_attr__( 'Text highlight color', 'filmic' ),
    'section' => 'header_2',
    'default' => '#ffffff',
    'transport' => 'auto',
    'output' => array(
        array(
            'element' => array(
                '.header-layout-2 .site-header__menu > li:hover > a',
                '.header-layout-2 .site-header__menu > li.current-menu-ancestor > a',
                '.header-layout-2 .site-header__menu > li.current-menu-parent > a',
                '.header-layout-2 .site-header__menu > li.current_page_parent > a',
                '.header-layout-2 .site-header__menu > li.current_page_ancestor > a',
                '.header-layout-2 .site-header__menu li.current-menu-item > a',
                '.header-layout-2 #theme-search-btn:hover',
            ),
            'property' => 'color',
            'media_query' => '@media (min-width: 992px)'
        ),
        array(
            'element' => array(
                '.header-layout-2 #toggle-sidebar-btn:hover span',
                '.header-layout-2 #toggle-sidebar-btn:hover span:before',
                '.header-layout-2 #toggle-sidebar-btn:hover span:after',
            ),
            'property' => 'background-color',
            'media_query' => '@media (min-width: 992px)'
        )
    )
));

/*label*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'custom',
    'settings' => 'hd2_submenu_label',
    'section' => 'header_2',
    'default'     => filmic_label(esc_attr__('Submenu option', 'filmic')),
));

/*submenu text color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd2_submenu_text_color',
    'label' => esc_attr__('Text color', 'filmic'),
    'section' => 'header_2',
    'transport' => 'auto',
    'default' => '#ffffff',
    'output' => array(
        array(
            'element' => array(
                '.header-layout-2 .site-header__menu li .sub-menu a',
                '.header-layout-2 .site-header__menu li.menu-item-has-children:after'
            ),
            'property' => 'color',
            'media_query' => '@media (min-width: 992px)'
        ),
    )
));

/*submenu text highlight background color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd2_submenu_text_highlight_bg',
    'label' => esc_attr__('Background text highlight', 'filmic'),
    'section' => 'header_2',
    'transport' => 'auto',
    'default' => '#454444',
    'output' => array(
        array(
            'element' => array(
                '.header-layout-2 .site-header__menu .sub-menu a:hover',
                '.header-layout-2 .site-header__menu .sub-menu li.current-menu-item > a'
            ),
            'property' => 'background-color',
            'media_query' => '@media (min-width: 992px)'
        ),
    )
));

/*submenu background color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd2_submenu_bg_color',
    'label' => esc_attr__('Background color', 'filmic'),
    'section' => 'header_2',
    'transport' => 'auto',
    'default' => '#292929',
    'output' => array(
        array(
            'element' => array(
                '.header-layout-2 .site-header__menu .sub-menu',
            ),
            'property' => 'background-color',
            'media_query' => '@media (min-width: 992px)'
        )
    )
));


/*sidebar menu*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'select',
    'settings' => 'hd2_sidebar_menu',
    'label' => esc_attr__( 'Sidebar menu', 'filmic' ),
    'section' => 'header_2',
    'choices' => $menu,
    'default' => 'disable',
));

/*HEADER LAYOUT 3====================*/

/* header background color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd3_bg',
    'label' => esc_attr__( 'Background color', 'filmic' ),
    'section' => 'header_3',
    'choices' => array(
        'alpha' => true
    ),
    'default' => 'rgba(255,255,255,0)',
    'transport' => 'auto',
    'output' => array(
        array(
            'element' => '.header-layout-3 .site-header__container',
            'property' => 'background-color'
        )
    ),
    'partial_refresh' => array(
        'hd3_edit_location' => array(
            'selector'        => '#hd3-edit-location',
            'render_callback' => 'filmic_edit_location',
        ),
    ),
));

/*infor content*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'textarea',
    'settings' => 'hd3_info',
    'label' => esc_attr__( 'Infomation', 'filmic' ),
    'section' => 'header_3',
    'default' =>
'<ul>
<li><a href="tel:+012123456" style="color: #ffffff">(+01)-212-3456</a></li>
<li><a href="mailto:info@jamesburton.com" style="color: #8f8f8f">info@jamesburton.com</a></li>
</ul>',
));

/*icon color*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'hd3_icon_color',
    'label' => esc_attr__( 'Icon color', 'filmic' ),
    'section' => 'header_3',
    'default' => '#ffffff',
    'transport' => 'auto',
    'output' => array(
        array(
            'element' => array(
                '.header-layout-3 #theme-search-btn'
            ),
            'property' => 'color',
            'media_query' => '@media (min-width: 992px)'
        ),
    ),
));

/*sidebar menu*/
Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'select',
    'settings' => 'hd3_sidebar_menu',
    'label' => esc_attr__( 'Sidebar menu', 'filmic' ),
    'section' => 'header_3',
    'choices' => $menu,
    'default' => 'disable',
));