<?php

/*Add the page header section*/
Filmic_Kirki::add_section( 'page_header', array(
    'title'      => esc_attr__( 'Page Header', 'filmic'),
    'capability' => 'edit_theme_options'
));

Filmic_Kirki::add_field( 'filmic', array(
    'type'        => 'custom',
    'settings'    => 'p_header_label',
    'section'     => 'page_header',
    'default'     => filmic_label(esc_attr__('Custom your page header here', 'filmic')),
    'partial_refresh' => array(
        'bread_edit_location' => array(
            'selector'        => '#bread-edit-location',
            'render_callback' => 'filmic_edit_location',
        ),
    ),
));

/*en/disable page breadcumbs*/
Filmic_Kirki::add_field( 'filmic', array(
    'type'      => 'switch',
    'settings'  => 'c_bread',
    'label'     => esc_attr__( 'On/Off page header', 'filmic' ),
    'section'   => 'page_header',
    'default'   => '1',
    'choices' => array(
        'yes' => esc_attr__('Yes', 'filmic'),
        'no' => esc_attr__('No', 'filmic'),
    )
));

/*breadcrumbs display*/
Filmic_Kirki::add_field( 'filmic', array(
    'type'      => 'switch',
    'settings'  => 'c_bread_display',
    'section'   => 'page_header',
    'label'     => esc_attr__( 'On/off breadcrumbs', 'filmic' ),
    'default'     => '1',
    'choices' => array(
        'on'  => esc_attr__( 'On', 'filmic' ),
        'off' => esc_attr__( 'Off', 'filmic' )
    ),
    'active_callback'  => array(
        array(
            'setting'  => 'c_bread',
            'operator' => '==',
            'value'    => '1',
        ),
    ),
));

/*background breadcrumb*/
Filmic_Kirki::add_field( 'filmic', array(
    'type'      => 'radio',
    'settings'  => 'c_header_bg',
    'label'     => esc_attr__( 'Background', 'filmic' ),
    'description' => esc_attr__('If select background image option, the theme recommends a header size of at least 1170 width pixels', 'filmic'),
    'section'   => 'page_header',
    'default'   => 'bg_color',
    'choices'   => array(
        'bg_image' => esc_attr__( 'Use Image', 'filmic' ),
        'bg_color' => esc_attr__( 'Use Solid Color', 'filmic' ),
    ),
    'active_callback'  => array(
        array(
            'setting'  => 'c_bread',
            'operator' => '==',
            'value'    => '1',
        ),
    ),
));

//use img
Filmic_Kirki::add_field( 'filmic', array(
    'type'      => 'cropped_image',
    'settings'  => 'c_header_bg_image',
    'label'     => esc_attr__( 'Upload Image', 'filmic' ),
    'section'   => 'page_header',
    'width' => 1920,
    'height' => 300,
    'description'   => esc_attr__( 'Upload background image of page header here!', 'filmic' ),
    'output'     => array(
        array(
            'element' => '.theme-breadcrumb',
            'property' => 'background-image',
        )
    ),
    'active_callback'  => array(
        array(
            'setting'  => 'c_bread',
            'operator' => '==',
            'value'    => '1',
        ),
        array(
            'setting'  => 'c_header_bg',
            'operator' => '==',
            'value'    => 'bg_image',
        ),
    )
));

//use css
Filmic_Kirki::add_field( 'filmic', array(
    'type'        => 'color',
    'settings'    => 'c_header_bg_color',
    'label'       => esc_attr__( 'Select Color', 'filmic' ),
    'section'     => 'page_header',
    'default'     => '#f3f3f3',
    'transport' => 'auto',
    'choices' => array(
        'alpha' => true
    ),
    'output'     => array(
        array(
            'element' => '.theme-breadcrumb',
            'property' => 'background-color',
        )
    ),
    'active_callback'  => array(
        array(
            'setting'  => 'c_bread',
            'operator' => '==',
            'value'    => '1',
        ),
        array(
            'setting'  => 'c_header_bg',
            'operator' => '!=',
            'value'    => 'bg_image',
        ),
    )
));

/*text align*/
Filmic_Kirki::add_field( 'filmic', array(
    'type'      => 'select',
    'settings'  => 'c_bread_align',
    'label'     => esc_attr__( 'Text align', 'filmic' ),
    'section'   => 'page_header',
    'choices'   => array(
        'left' => esc_attr__( 'Left', 'filmic' ),
        'right' => esc_attr__( 'Right', 'filmic' ),
        'center' => esc_attr__( 'Center', 'filmic' ),
    ),
    'default' => 'center',
    'active_callback'  => array(
        array(
            'setting'  => 'c_bread',
            'operator' => '==',
            'value'    => '1',
        ),
    ),
));

/* TEXT COLOR */
Filmic_Kirki::add_field( 'filmic', array(
    'type'            => 'color',
    'settings'        => 'c_bread_color',
    'label'           => esc_attr__( 'Text color', 'filmic' ),
    'section'         => 'page_header',
    'default'         => '#292929',
    'transport'       => 'auto',
    'output'          => array(
        array(
            'element'  => array(
                '.bread-title',
                '.ht-breadcrumbs',
                '.ht-breadcrumbs .last-item',
                '.ht-breadcrumbs a'
            ),
            'property' => 'color'
        )
    ),
    'active_callback' => array(
        array(
            'setting'  => 'c_bread',
            'operator' => '==',
            'value'    => '1',
        ),
    ),
));