<?php 
Filmic_Kirki::add_section( 'typography', array(
 	'title'      => esc_attr__( 'Typography', 'filmic' ),
 	'capability' => 'edit_theme_options',
 ) );
 // typo main menu
Filmic_Kirki::add_field( 'filmic', array(
 	'type'        => 'typography',
 	'settings'    => 'menu_typography',
 	'label'       => esc_attr__( 'Mainmenu Typography', 'filmic' ),
 	'description' => esc_attr__( 'Select the typography options for your Main menu.', 'filmic' ),
 	'section'     => 'typography',
 	'default'     => array(
 		'font-family'    => 'Lato',
 		'variant'        => '700',
 		'font-size'      => '14px',
 	),
 	'output' => array(
 		array(
 			'element' => '.site-header .site-header__menu > li > a',
 		),
 	),
 ) );
// typo sub menu
Filmic_Kirki::add_field( 'filmic', array(
 	'type'        => 'typography',
 	'settings'    => 'submenu_typography',
 	'label'       => esc_attr__( 'Submenu Mainmenu Typography', 'filmic' ),
 	'description' => esc_attr__( 'Select the typography options for your Submenu.', 'filmic' ),
 	'section'     => 'typography',
 	'default'     => array(
 		'font-family'    => 'Lato',
		'variant'        => '700',
		'font-size'      => '14px'
 	),
 	'output' => array(
 		array(
 			'element' => '.site-header .site-header__menu li .sub-menu a',
 		),
 	),
 ) );
 
// typo body
Filmic_Kirki::add_field( 'filmic', array(
 	'type'        => 'typography',
 	'settings'    => 'body_typography',
 	'label'       => esc_attr__( 'Body Typography', 'filmic' ),
 	'description' => esc_attr__( 'Select the main typography options for your site.', 'filmic' ),
 	'section'     => 'typography',
 	'default'     => array(
 		'font-family'    => 'Poppins',
 		'variant'        => 'regular',
 		'font-size'      => '14px',
 		'line-height'    => '24px',
 		'color'          => '#8f8f8f',
 	),
 	'output' => array(
 		array(
 			'element' => array(
				'body',
				'.sc-counter__description',
				'.team-members-layout-2 .team-members__name',
			),
 		),
 	),
 ) );
// typo heading
Filmic_Kirki::add_field( 'filmic', array(
 	'type'        => 'typography',
 	'settings'    => 'heading_typography',
 	'label'       => esc_attr__( 'Heading', 'filmic' ),
 	'section'     => 'typography',
 	'default'     => array(
 		'font-family' => 'Playfair Display',
 		'variant' => '700',
		'color' => '#292929',
 	),
 	'output' => array(
 		array(
 			'element' => 'h1, h2, h3, h4, h5, h6',
 		),
 	),
 ));
Filmic_Kirki::add_field( 'filmic', array(
 	'type'        => 'typography',
 	'settings'    => 'h1_typography',
 	'label'       => esc_attr__( 'H1', 'filmic' ),
 	'section'     => 'typography',
 	'default'     => array(
 		'font-size'      => '48px',
 	),
 	'output' => array(
 		array(
 			'element' => 'h1',
 		),
 	),
 ));
Filmic_Kirki::add_field( 'filmic', array(
 	'type'        => 'typography',
 	'settings'    => 'h2_typography',
 	'label'       => esc_attr__( 'H2', 'filmic' ),
 	'section'     => 'typography',
 	'default'     => array(
 		'font-size'      => '36px',
 	),
 	'output' => array(
 		array(
 			'element' => 'h2',
 		),
 	),
 ));
Filmic_Kirki::add_field( 'filmic', array(
 	'type'        => 'typography',
 	'settings'    => 'h3_typography',
 	'label'       => esc_attr__( 'H3', 'filmic' ),
 	'section'     => 'typography',
 	'default'     => array(
 		'font-size'      => '30px',
 	),
 	'output' => array(
 		array(
 			'element' => 'h3',
 		),
 	),
 ));
Filmic_Kirki::add_field( 'filmic', array(
 	'type'        => 'typography',
 	'settings'    => 'h4_typography',
 	'label'       => esc_attr__( 'H4', 'filmic' ),
 	'section'     => 'typography',
 	'default'     => array(
 		'font-size'      => '24px',
 	),
 	'output' => array(
 		array(
 			'element' => 'h4',
 		),
 	),
 ));

 Filmic_Kirki::add_field( 'filmic', array(
	'type'        => 'typography',
	'settings'    => 'h5_typography',
	'label'       => esc_attr__( 'H5', 'filmic' ),
	'section'     => 'typography',
	'default'     => array(
		'font-size'      => '20px',
	),
	'output' => array(
		array(
			'element' => 'h5',
		),
	),
));

Filmic_Kirki::add_field( 'filmic', array(
	'type'        => 'typography',
	'settings'    => 'h6_typography',
	'label'       => esc_attr__( 'H6', 'filmic' ),
	'section'     => 'typography',
	'default'     => array(
		'font-size'      => '18px',
	),
	'output' => array(
		array(
			'element' => 'h6',
		),
	),
));

