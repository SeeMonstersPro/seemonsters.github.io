<?php
Filmic_Kirki::add_section( 'colors', array(
 	'title'      => esc_attr__( 'Colors', 'filmic' ),
 	'priority'   => 20,
 	'capability' => 'edit_theme_options',
 ) );

 /*primary color*/
Filmic_Kirki::add_field( 'filmic', array(
	'type'      => 'color',
	'settings'  => 'primary_color',
	'label'     => esc_attr__( 'Primary color', 'filmic' ),
	'description' => esc_attr__( 'Choose color', 'filmic' ),
	'section'   => 'colors',
	'default'   => '#292929',
	'transport' => 'auto',
	'output' => array(
		// color
		array(
			'element' => array(
                'a',
                '.sc-project .project-trailer-btn',
				'.project-grid-nogap .sc-project-item:hover .project-nogap-arrow',
				'.entry-title a',
				'.sc-carousel .slick-prev:before',
				'.sc-carousel .slick-next:before',
				'.sc-testimonial-style-1 .sc-testimonial__name',
				'.sc-testimonial-style-2 .sc-testimonial__name'
            ),
			'function' => 'css',
			'property' => 'color'
		),
		// background color
		array(
			'element' => array(
				'.sc-project .project-trailer-btn:after',
				'.scroll-to-top',
				'.timeline:before',
				'.sc-timeline:after',
            ),
			'function' => 'css',
			'property' => 'background-color',
		),
	),
) );


/*second color*/
Filmic_Kirki::add_field( 'filmic', array(
	'type'      => 'color',
	'settings'  => 'secondary_color',
	'label'     => esc_attr__( 'Secondary color', 'filmic' ),
	'description' => esc_attr__( 'Choose color', 'filmic' ),
	'section'   => 'colors',
	'default'   => '#9e8157',
	'transport' => 'auto',
	'output' => array(
		// color
		array(
			'element' => array(
                '.wpcf7 .contact-form-field:focus',
                '.contact__social a',
                'a:hover',
                '.sc-project .sc-project-item:hover .sc-project-title a',
				'.project-carousel .sc-project-item .sc-project-title a',
				'.sc-iconbox__link',
				'.read-more-icon',
				'.sc-counter__number',
				'.read-more-link',
				'.read-more-link:hover',
				'.read-more-link:focus',
				'.read-more-link:visited',
				'.entry-time:hover',
				'.entry-title a:hover',
				'.entry-time--secondary:hover',
				'.timeline__year',
				'.sc-timeline:after',
				'.sc-testimonial-style-4:before',
				'.sc-testimonial-style-4 .sc-testimonial__content p',
				'.menu-main li.current-menu-item a',
				'.menu-main li.current-menu-ancestor > a'
            ),
			'function' => 'css',
			'property' => 'color'
		),

		// background color
		array(
			'element' => array(
                '.dk-select-options .dk-option-highlight',
				'.project-grid-nogap.with-overlay .project-nogap-arrow',
                '.swiper-scrollbar .swiper-scrollbar-drag',
				'.vc_btn3-style-filmic-btn.vc_btn3.vc_btn3-color-grey',
				'.vc_custom_heading-custom-style:before',
                '.project-carousel .project-trailer-normal-btn',
				'.project-carousel .project-buy-btn:hover',
				'.sc-lightbox__link',
				'button',
				'input[type="button"]',
				'input[type="reset"]',
				'input[type="submit"]',
				'.scroll-to-top:hover',
				'.entry-time--secondary',
				'.team-members-layout-1 .team-members_links a:hover',
				'.sc-testimonial-style-4 .slick-active .slick-dots__icon',
				'.sc-testimonial-style-4 .slick-dots__icon:hover',
				'.sc-demo__cta',
				'.project-sum .project-trailer-normal-btn',
				'.project-sum .project-buy-btn:hover',
				'button[type="submit"]',
				'.woocommerce span.onsale',
            ),
			'function' => 'css',
			'property' => 'background-color',
		),

        /*border color*/
        array(
            'element' => array(
                '.project-carousel .project-buy-btn:hover',
				'.project-carousel .project-trailer-normal-btn',
				'.entry-time:hover',
				'.entry-time--secondary',
				'.project-sum .project-trailer-normal-btn',
				'.project-sum .project-buy-btn:hover',
            ),
            'function' => 'css',
            'property' => 'border-color',
        ),

        // border-bottom-color
        array(
            'element' => array(
                '.wpcf7 .contact-form-field:focus'
            ),
            'property' => 'border-bottom-color',
        ),
	),
) );