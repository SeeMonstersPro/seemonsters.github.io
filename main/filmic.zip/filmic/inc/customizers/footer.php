<?php
  Filmic_Kirki::add_section( 'footer', array(
    'title' => esc_attr__( 'Footer', 'filmic' ),
    'capability' => 'edit_theme_options'
  ) );

    /*on/off footer*/
    Filmic_Kirki::add_field( 'filmic', array(
        'type' => 'switch',
        'settings' => 'footer_layout',
        'label' => esc_attr__( 'On/Off Footer', 'filmic' ),
        'section' => 'footer',
        'default' => '1',
        'choices' => array(
            'yes' => esc_attr__('Yes', 'filmic'),
            'no' => esc_attr__('No', 'filmic'),
        )
    ));

  Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'footer_main_background_color',
    'label' => esc_attr__( 'Footer Main Background Color', 'filmic' ),
    'description' => esc_attr__( 'Choose color', 'filmic' ),
    'section' => 'footer',
    'default' => '#292929',
    'transport' => 'auto',
    'output' => array(
        array(
            'element' => '.site-footer__main',
          'function' => 'css',
          'property' => 'background-color'
        )
    ),
    'active_callback' => array(
        array(
            'setting' => 'footer_layout',
            'operator' => '==',
            'value' => '1'
        )
    )
  ) );

  Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'color',
    'settings' => 'footer_copyright_background_color',
    'label' => esc_attr__( 'Footer Copyright Background Color', 'filmic' ),
    'description' => esc_attr__( 'Choose color', 'filmic' ),
    'section' => 'footer',
    'default' => '#1b1919',
    'transport' => 'auto',
    'output' => array(
        array(
            'element' => '.site-footer__copyright',
          'function' => 'css',
          'property' => 'background-color'
        )
    ),
    'active_callback' => array(
        array(
            'setting' => 'footer_layout',
            'operator' => '==',
            'value' => '1'
        )
    )
  ) );

  Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'textarea',
    'settings' => 'footer_copyright_left',
    'label' => esc_attr__( 'Footer Copyright Left', 'filmic' ),
    'description' => esc_attr__( 'Write left footer copyright description', 'filmic' ),
    'section' => 'footer',
    'default' => esc_attr__( '&copy; 2017 Filmic. All Rights Reserved. Designed by Lee Hari.', 'filmic' ),
    'active_callback' => array(
        array(
            'setting' => 'footer_layout',
            'operator' => '==',
            'value' => '1'
        )
    )
  ) );

  Filmic_Kirki::add_field( 'filmic', array(
    'type' => 'textarea',
    'settings' => 'footer_copyright_right',
    'label' => esc_attr__( 'Footer Copyright Right', 'filmic' ),
    'description' => esc_attr__( 'Write right footer copyright description', 'filmic' ),
    'section' => 'footer',
    'default' => '',
    'active_callback' => array(
        array(
            'setting' => 'footer_layout',
            'operator' => '==',
            'value' => '1'
        )
    )
  ) );
?>