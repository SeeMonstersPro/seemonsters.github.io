<?php
/**
 * Class Plugin
 *
 * Main Plugin class
 * @since 1.2.0
 */
class filmic_Elementor {
    /**
     * Instance
     *
     * @since 1.2.0
     * @access private
     * @static
     *
     * @var Plugin The single instance of the class.
     */
    private static $_instance = null;
    /**
     * Instance
     *
     * Ensures only one instance of the class is loaded or can be loaded.
     *
     * @since 1.2.0
     * @access public
     *
     * @return Plugin An instance of the class.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Register custom widget categories.
     */
    public function add_elementor_widget_categories( $elements_manager ) {
        $elements_manager->add_category(
            'filmic-theme',
            array(
                'title' => esc_html__( 'Filmic Theme', 'filmic' ),
            )
        );
    }
    /**
     * widget_scripts
     *
     * Load required plugin core files.
     *
     * @since 1.2.0
     * @access public
     */
    public function widget_scripts() {
        wp_register_script(
            'filmic-image-slider',
            FILMIC_URI . 'js/elementor/image-slider.js',
            array( 'jquery'),
            FILMIC_VERSION,
            true
        );


        wp_register_script(
            'filmic-studio-widgets',
            FILMIC_URI . 'js/elementor/studio-slide.js',
            array( 'jquery', 'swiper' ),
            FILMIC_VERSION,
            true
        );

        wp_register_script(
            'filmic-project-widgets',
            FILMIC_URI . 'js/elementor/project-filter.js',
            array( 'jquery' ),
            FILMIC_VERSION,
            true
        );
        // Member Slider
        wp_register_script(
            'filmic-members-scripts',
            FILMIC_URI . 'js/elementor/members-slider.js',
            array( 'jquery'),
            FILMIC_VERSION,
            true
        );
        // TESTIMONIAL
        wp_register_script(
            'filmic-testimonial-scripts',
            FILMIC_URI . 'js/elementor/filmic-testimonial.js',
            array( 'jquery'),
            FILMIC_VERSION,
            true
        );
        // GALLERY
        wp_register_script(
            'filmic-gallery-scripts',
            FILMIC_URI . 'js/elementor/filmic-gallery.js',
            array( 'jquery'),
            FILMIC_VERSION,
            true
        );
        // CONTENT SLIDER
        wp_register_script(
            'filmic-content-slider-scripts',
            FILMIC_URI . 'js/elementor/content-slider.js',
            array( 'jquery'),
            FILMIC_VERSION,
            true
        );
        // PROJECT SLIDER
        wp_register_script(
            'filmic-project-slider',
            FILMIC_URI . 'js/elementor/project-slider.js',
            array( 'jquery'),
            FILMIC_VERSION,
            true
        );
    }
    /**
     * Include Widgets files
     *
     * Load widgets files
     *
     * @since 1.2.0
     * @access private
     */
    private function include_widgets_files() {

        $widgets = glob( FILMIC_DIR . 'elementor/widgets/*.php' );

        foreach ( $widgets as $key ) {
            if ( file_exists( $key ) ) {
                require_once $key;
            }
        }
    }
    /**
     * Register Widgets
     *
     * Register new Elementor widgets.
     *
     * @since 1.2.0
     * @access public
     */
    public function register_widgets() {
        // Its is now safe to include Widgets files
        $this->include_widgets_files();

        $widgets = glob( FILMIC_DIR . 'elementor/widgets/*.php' );
        // Register Widgets
        foreach ( $widgets as $key ) {
            if ( file_exists( $key ) ) {
                $paths      = pathinfo( $key );
                $prefix     = str_replace( '-', ' ', $paths['filename'] );
                $prefix     = ucwords( $prefix );
                $class_name = str_replace( ' ', '_', $prefix );
                $class_name = str_replace( 'Class_', '', $class_name );
                \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new $class_name() );
            }
        }
    }

    /**
     *  Plugin class constructor
     *
     * Register plugin action hooks and filters
     *
     * @since 1.2.0
     * @access public
     */
    public function __construct() {
        // Register custom widget categories.
        add_action( 'elementor/elements/categories_registered', array( $this, 'add_elementor_widget_categories' ) );
        // Register widget scripts
        add_action( 'elementor/frontend/after_register_scripts', [ $this, 'widget_scripts' ] );
        // Register widgets
        add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
    }
}
// Instantiate filmic_Elementor Class
filmic_Elementor::instance();
