<?php

/*child shortcode*/
if ( class_exists( 'WPBakeryShortCode' ) ) {

    /*lightbox*/
    class WPBakeryShortCode_lightbox extends WPBakeryShortCode {  
    }

    /*timeline*/
    class WPBakeryShortCode_timeline extends WPBakeryShortCode {
    }

    /*iconbox*/
    class WPBakeryShortCode_iconbox extends WPBakeryShortCode {
    }

    /*carousel*/
    class WPBakeryShortCode_carousel extends WPBakeryShortCode {
    }

    /*project*/
    class WPBakeryShortCode_project extends WPBakeryShortCode {
    }
    
    /*studio*/
    class WPBakeryShortCode_studio extends WPBakeryShortCode {
    }

    class WPBakeryShortCode_team_members extends WPBakeryShortCode {
    }

    /*testimonial*/
    class WPBakeryShortCode_testimonial extends WPBakeryShortCode {
    }

    /*blog*/
    class WPBakeryShortCode_blog extends WPBakeryShortCode {
    }

    /*maps*/
    class WPBakeryShortCode_gmaps extends WPBakeryShortCode {
    }

    /*counter*/
    class WPBakeryShortCode_counter extends WPBakeryShortCode {
    }

    /*landing*/
    class WPBakeryShortCode_landing extends WPBakeryShortCode {
    }
}

/*incluce vc-maps*/
get_template_part('inc/vc', 'maps');

/*modify default shortcode*/
get_template_part('inc/vc', 'modify');

/* disable update noice */
function filmic_vc_disable_updater_noice() {
    vc_manager()->disableUpdater();
}
// add_action( 'vc_before_init', 'filmic_vc_disable_updater_noice' );