/** Isotope **/
! function(t, i, s) {
    "use strict";
    var e, n = t.document,
        o = t.Modernizr,
        r = function(t) {
            return t.charAt(0).toUpperCase() + t.slice(1)
        },
        a = "Moz Webkit O Ms".split(" "),
        h = function(t) {
            var i, s = n.documentElement.style;
            if ("string" == typeof s[t]) return t;
            t = r(t);
            for (var e = 0, o = a.length; o > e; e++)
                if (i = a[e] + t, "string" == typeof s[i]) return i
        },
        l = h("transform"),
        u = h("transitionProperty"),
        c = {
            csstransforms: function() {
                return !!l
            },
            csstransforms3d: function() {
                var t = !!h("perspective");
                if (t) {
                    var s = " -o- -moz- -ms- -webkit- -khtml- ".split(" "),
                        e = "@media (" + s.join("transform-3d),(") + "modernizr)",
                        n = i("<style>" + e + "{#modernizr{height:3px}}</style>").appendTo("head"),
                        o = i('<div id="modernizr" />').appendTo("html");
                    t = 3 === o.height(), o.remove(), n.remove()
                }
                return t
            },
            csstransitions: function() {
                return !!u
            }
        };
    if (o)
        for (e in c) o.hasOwnProperty(e) || o.addTest(e, c[e]);
    else {
        o = t.Modernizr = {
            _version: "1.6ish: miniModernizr for Isotope"
        };
        var d, f = " ";
        for (e in c) d = c[e](), o[e] = d, f += " " + (d ? "" : "no-") + e;
        i("html").addClass(f)
    }
    if (o.csstransforms) {
        var m = o.csstransforms3d ? {
                translate: function(t) {
                    return "translate3d(" + t[0] + "px, " + t[1] + "px, 0) "
                },
                scale: function(t) {
                    return "scale3d(" + t + ", " + t + ", 1) "
                }
            } : {
                translate: function(t) {
                    return "translate(" + t[0] + "px, " + t[1] + "px) "
                },
                scale: function(t) {
                    return "scale(" + t + ") "
                }
            },
            p = function(t, s, e) {
                var n, o, r = i.data(t, "isoTransform") || {},
                    a = {},
                    h = {};
                a[s] = e, i.extend(r, a);
                for (n in r) o = r[n], h[n] = m[n](o);
                var u = h.translate || "",
                    c = h.scale || "",
                    d = u + c;
                i.data(t, "isoTransform", r), t.style[l] = d
            };
        i.cssNumber.scale = !0, i.cssHooks.scale = {
            set: function(t, i) {
                p(t, "scale", i)
            },
            get: function(t, s) {
                var e = i.data(t, "isoTransform");
                return e && e.scale ? e.scale : 1
            }
        }, i.fx.step.scale = function(t) {
            i.cssHooks.scale.set(t.elem, t.now + t.unit)
        }, i.cssNumber.translate = !0, i.cssHooks.translate = {
            set: function(t, i) {
                p(t, "translate", i)
            },
            get: function(t, s) {
                var e = i.data(t, "isoTransform");
                return e && e.translate ? e.translate : [0, 0]
            }
        }
    }
    var y, g;
    o.csstransitions && (y = {
        WebkitTransitionProperty: "webkitTransitionEnd",
        MozTransitionProperty: "transitionend",
        OTransitionProperty: "oTransitionEnd otransitionend",
        transitionProperty: "transitionend"
    }[u], g = h("transitionDuration"));
    var v, _ = i.event,
        A = i.event.handle ? "handle" : "dispatch";
    _.special.smartresize = {
        setup: function() {
            i(this).bind("resize", _.special.smartresize.handler)
        },
        teardown: function() {
            i(this).unbind("resize", _.special.smartresize.handler)
        },
        handler: function(t, i) {
            var s = this,
                e = arguments;
            t.type = "smartresize", v && clearTimeout(v), v = setTimeout(function() {
                _[A].apply(s, e)
            }, "execAsap" === i ? 0 : 100)
        }
    }, i.fn.smartresize = function(t) {
        return t ? this.bind("smartresize", t) : this.trigger("smartresize", ["execAsap"])
    }, i.Isotope = function(t, s, e) {
        this.element = i(s), this._create(t), this._init(e)
    };
    var w = ["width", "height"],
        C = i(t);
    i.Isotope.settings = {
        resizable: !0,
        layoutMode: "masonry",
        containerClass: "isotope",
        itemClass: "isotope-item",
        hiddenClass: "isotope-hidden",
        hiddenStyle: {
            opacity: 0,
            scale: .001
        },
        visibleStyle: {
            opacity: 1,
            scale: 1
        },
        containerStyle: {
            position: "relative",
            overflow: "hidden"
        },
        animationEngine: "best-available",
        animationOptions: {
            queue: !1,
            duration: 800
        },
        sortBy: "original-order",
        sortAscending: !0,
        resizesContainer: !0,
        transformsEnabled: !0,
        itemPositionDataEnabled: !1
    }, i.Isotope.prototype = {
        _create: function(t) {
            this.options = i.extend({}, i.Isotope.settings, t), this.styleQueue = [], this.elemCount = 0;
            var s = this.element[0].style;
            this.originalStyle = {};
            var e = w.slice(0);
            for (var n in this.options.containerStyle) e.push(n);
            for (var o = 0, r = e.length; r > o; o++) n = e[o], this.originalStyle[n] = s[n] || "";
            this.element.css(this.options.containerStyle), this._updateAnimationEngine(), this._updateUsingTransforms();
            var a = {
                "original-order": function(t, i) {
                    return i.elemCount++, i.elemCount
                },
                random: function() {
                    return Math.random()
                }
            };
            this.options.getSortData = i.extend(this.options.getSortData, a), this.reloadItems(), this.offset = {
                left: parseInt(this.element.css("padding-left") || 0, 10),
                top: parseInt(this.element.css("padding-top") || 0, 10)
            };
            var h = this;
            setTimeout(function() {
                h.element.addClass(h.options.containerClass)
            }, 0), this.options.resizable && C.bind("smartresize.isotope", function() {
                h.resize()
            }), this.element.delegate("." + this.options.hiddenClass, "click", function() {
                return !1
            })
        },
        _getAtoms: function(t) {
            var i = this.options.itemSelector,
                s = i ? t.filter(i).add(t.find(i)) : t,
                e = {
                    position: "absolute"
                };
            return s = s.filter(function(t, i) {
                return 1 === i.nodeType
            }), this.usingTransforms && (e.left = 0, e.top = 0), s.css(e).addClass(this.options.itemClass), this.updateSortData(s, !0), s
        },
        _init: function(t) {
            this.$filteredAtoms = this._filter(this.$allAtoms), this._sort(), this.reLayout(t)
        },
        option: function(t) {
            if (i.isPlainObject(t)) {
                this.options = i.extend(!0, this.options, t);
                var s;
                for (var e in t) s = "_update" + r(e), this[s] && this[s]()
            }
        },
        _updateAnimationEngine: function() {
            var t, i = this.options.animationEngine.toLowerCase().replace(/[ _\-]/g, "");
            switch (i) {
                case "css":
                case "none":
                    t = !1;
                    break;
                case "jquery":
                    t = !0;
                    break;
                default:
                    t = !o.csstransitions
            }
            this.isUsingJQueryAnimation = t, this._updateUsingTransforms()
        },
        _updateTransformsEnabled: function() {
            this._updateUsingTransforms()
        },
        _updateUsingTransforms: function() {
            var t = this.usingTransforms = this.options.transformsEnabled && o.csstransforms && o.csstransitions && !this.isUsingJQueryAnimation;
            t || (delete this.options.hiddenStyle.scale, delete this.options.visibleStyle.scale), this.getPositionStyles = t ? this._translate : this._positionAbs
        },
        _filter: function(t) {
            var i = "" === this.options.filter ? "*" : this.options.filter;
            if (!i) return t;
            var s = this.options.hiddenClass,
                e = "." + s,
                n = t.filter(e),
                o = n;
            if ("*" !== i) {
                o = n.filter(i);
                var r = t.not(e).not(i).addClass(s);
                this.styleQueue.push({
                    $el: r,
                    style: this.options.hiddenStyle
                })
            }
            return this.styleQueue.push({
                $el: o,
                style: this.options.visibleStyle
            }), o.removeClass(s), t.filter(i)
        },
        updateSortData: function(t, s) {
            var e, n, o = this,
                r = this.options.getSortData;
            t.each(function() {
                e = i(this), n = {};
                for (var t in r) s || "original-order" !== t ? n[t] = r[t](e, o) : n[t] = i.data(this, "isotope-sort-data")[t];
                i.data(this, "isotope-sort-data", n)
            })
        },
        _sort: function() {
            var t = this.options.sortBy,
                i = this._getSorter,
                s = this.options.sortAscending ? 1 : -1,
                e = function(e, n) {
                    var o = i(e, t),
                        r = i(n, t);
                    return o === r && "original-order" !== t && (o = i(e, "original-order"), r = i(n, "original-order")), (o > r ? 1 : r > o ? -1 : 0) * s
                };
            this.$filteredAtoms.sort(e)
        },
        _getSorter: function(t, s) {
            return i.data(t, "isotope-sort-data")[s]
        },
        _translate: function(t, i) {
            return {
                translate: [t, i]
            }
        },
        _positionAbs: function(t, i) {
            return {
                left: t,
                top: i
            }
        },
        _pushPosition: function(t, i, s) {
            i = Math.round(i + this.offset.left), s = Math.round(s + this.offset.top);
            var e = this.getPositionStyles(i, s);
            this.styleQueue.push({
                $el: t,
                style: e
            }), this.options.itemPositionDataEnabled && t.data("isotope-item-position", {
                x: i,
                y: s
            })
        },
        layout: function(t, i) {
            var s = this.options.layoutMode;
            if (this["_" + s + "Layout"](t), this.options.resizesContainer) {
                var e = this["_" + s + "GetContainerSize"]();
                this.styleQueue.push({
                    $el: this.element,
                    style: e
                })
            }
            this._processStyleQueue(t, i), this.isLaidOut = !0
        },
        _processStyleQueue: function(t, s) {
            var e, n, r, a, h = this.isLaidOut && this.isUsingJQueryAnimation ? "animate" : "css",
                l = this.options.animationOptions,
                u = this.options.onLayout;
            if (n = function(t, i) {
                    i.$el[h](i.style, l)
                }, this._isInserting && this.isUsingJQueryAnimation) n = function(t, i) {
                e = i.$el.hasClass("no-transition") ? "css" : h, i.$el[e](i.style, l)
            };
            else if (s || u || l.complete) {
                var c = !1,
                    d = [s, u, l.complete],
                    f = this;
                if (r = !0, a = function() {
                        if (!c) {
                            for (var i, s = 0, e = d.length; e > s; s++) i = d[s], "function" == typeof i && i.call(f.element, t, f);
                            c = !0
                        }
                    }, this.isUsingJQueryAnimation && "animate" === h) l.complete = a, r = !1;
                else if (o.csstransitions) {
                    for (var m, p = 0, v = this.styleQueue[0], _ = v && v.$el; !_ || !_.length;) {
                        if (m = this.styleQueue[p++], !m) return;
                        _ = m.$el
                    }
                    var A = parseFloat(getComputedStyle(_[0])[g]);
                    A > 0 && (n = function(t, i) {
                        i.$el[h](i.style, l).one(y, a)
                    }, r = !1)
                }
            }
            i.each(this.styleQueue, n), r && a(), this.styleQueue = []
        },
        resize: function() {
            this["_" + this.options.layoutMode + "ResizeChanged"]() && this.reLayout()
        },
        reLayout: function(t) {
            this["_" + this.options.layoutMode + "Reset"](), this.layout(this.$filteredAtoms, t)
        },
        addItems: function(t, i) {
            var s = this._getAtoms(t);
            this.$allAtoms = this.$allAtoms.add(s), i && i(s)
        },
        insert: function(t, i) {
            this.element.append(t);
            var s = this;
            this.addItems(t, function(t) {
                var e = s._filter(t);
                s._addHideAppended(e), s._sort(), s.reLayout(), s._revealAppended(e, i)
            })
        },
        appended: function(t, i) {
            var s = this;
            this.addItems(t, function(t) {
                s._addHideAppended(t), s.layout(t), s._revealAppended(t, i)
            })
        },
        _addHideAppended: function(t) {
            this.$filteredAtoms = this.$filteredAtoms.add(t), t.addClass("no-transition"), this._isInserting = !0, this.styleQueue.push({
                $el: t,
                style: this.options.hiddenStyle
            })
        },
        _revealAppended: function(t, i) {
            var s = this;
            setTimeout(function() {
                t.removeClass("no-transition"), s.styleQueue.push({
                    $el: t,
                    style: s.options.visibleStyle
                }), s._isInserting = !1, s._processStyleQueue(t, i)
            }, 10)
        },
        reloadItems: function() {
            this.$allAtoms = this._getAtoms(this.element.children())
        },
        remove: function(t, i) {
            this.$allAtoms = this.$allAtoms.not(t), this.$filteredAtoms = this.$filteredAtoms.not(t);
            var s = this,
                e = function() {
                    t.remove(), i && i.call(s.element)
                };
            t.filter(":not(." + this.options.hiddenClass + ")").length ? (this.styleQueue.push({
                $el: t,
                style: this.options.hiddenStyle
            }), this._sort(), this.reLayout(e)) : e()
        },
        shuffle: function(t) {
            this.updateSortData(this.$allAtoms), this.options.sortBy = "random", this._sort(), this.reLayout(t)
        },
        destroy: function() {
            var t = this.usingTransforms,
                i = this.options;
            this.$allAtoms.removeClass(i.hiddenClass + " " + i.itemClass).each(function() {
                var i = this.style;
                i.position = "", i.top = "", i.left = "", i.opacity = "", t && (i[l] = "")
            });
            var s = this.element[0].style;
            for (var e in this.originalStyle) s[e] = this.originalStyle[e];
            this.element.unbind(".isotope").undelegate("." + i.hiddenClass, "click").removeClass(i.containerClass).removeData("isotope"), C.unbind(".isotope")
        },
        _getSegments: function(t) {
            var i, s = this.options.layoutMode,
                e = t ? "rowHeight" : "columnWidth",
                n = t ? "height" : "width",
                o = t ? "rows" : "cols",
                a = this.element[n](),
                h = this.options[s] && this.options[s][e] || this.$filteredAtoms["outer" + r(n)](!0) || a;
            i = Math.floor(a / h), i = Math.max(i, 1), this[s][o] = i, this[s][e] = h
        },
        _checkIfSegmentsChanged: function(t) {
            var i = this.options.layoutMode,
                s = t ? "rows" : "cols",
                e = this[i][s];
            return this._getSegments(t), this[i][s] !== e
        },
        _masonryReset: function() {
            this.masonry = {}, this._getSegments();
            var t = this.masonry.cols;
            for (this.masonry.colYs = []; t--;) this.masonry.colYs.push(0)
        },
        _masonryLayout: function(t) {
            var s = this,
                e = s.masonry;
            t.each(function() {
                var t = i(this),
                    n = Math.ceil(t.outerWidth(!0) / e.columnWidth);
                if (n = Math.min(n, e.cols), 1 === n) s._masonryPlaceBrick(t, e.colYs);
                else {
                    var o, r, a = e.cols + 1 - n,
                        h = [];
                    for (r = 0; a > r; r++) o = e.colYs.slice(r, r + n), h[r] = Math.max.apply(Math, o);
                    s._masonryPlaceBrick(t, h)
                }
            })
        },
        _masonryPlaceBrick: function(t, i) {
            for (var s = Math.min.apply(Math, i), e = 0, n = 0, o = i.length; o > n; n++)
                if (i[n] === s) {
                    e = n;
                    break
                }
            var r = this.masonry.columnWidth * e,
                a = s;
            this._pushPosition(t, r, a);
            var h = s + t.outerHeight(!0),
                l = this.masonry.cols + 1 - o;
            for (n = 0; l > n; n++) this.masonry.colYs[e + n] = h
        },
        _masonryGetContainerSize: function() {
            var t = Math.max.apply(Math, this.masonry.colYs);
            return {
                height: t
            }
        },
        _masonryResizeChanged: function() {
            return this._checkIfSegmentsChanged()
        },
        _fitRowsReset: function() {
            this.fitRows = {
                x: 0,
                y: 0,
                height: 0
            }
        },
        _fitRowsLayout: function(t) {
            var s = this,
                e = this.element.width(),
                n = this.fitRows;
            t.each(function() {
                var t = i(this),
                    o = t.outerWidth(!0),
                    r = t.outerHeight(!0);
                0 !== n.x && o + n.x > e && (n.x = 0, n.y = n.height), s._pushPosition(t, n.x, n.y), n.height = Math.max(n.y + r, n.height), n.x += o
            })
        },
        _fitRowsGetContainerSize: function() {
            return {
                height: this.fitRows.height
            }
        },
        _fitRowsResizeChanged: function() {
            return !0
        },
        _cellsByRowReset: function() {
            this.cellsByRow = {
                index: 0
            }, this._getSegments(), this._getSegments(!0)
        },
        _cellsByRowLayout: function(t) {
            var s = this,
                e = this.cellsByRow;
            t.each(function() {
                var t = i(this),
                    n = e.index % e.cols,
                    o = Math.floor(e.index / e.cols),
                    r = (n + .5) * e.columnWidth - t.outerWidth(!0) / 2,
                    a = (o + .5) * e.rowHeight - t.outerHeight(!0) / 2;
                s._pushPosition(t, r, a), e.index++
            })
        },
        _cellsByRowGetContainerSize: function() {
            return {
                height: Math.ceil(this.$filteredAtoms.length / this.cellsByRow.cols) * this.cellsByRow.rowHeight + this.offset.top
            }
        },
        _cellsByRowResizeChanged: function() {
            return this._checkIfSegmentsChanged()
        },
        _straightDownReset: function() {
            this.straightDown = {
                y: 0
            }
        },
        _straightDownLayout: function(t) {
            var s = this;
            t.each(function(t) {
                var e = i(this);
                s._pushPosition(e, 0, s.straightDown.y), s.straightDown.y += e.outerHeight(!0)
            })
        },
        _straightDownGetContainerSize: function() {
            return {
                height: this.straightDown.y
            }
        },
        _straightDownResizeChanged: function() {
            return !0
        },
        _masonryHorizontalReset: function() {
            this.masonryHorizontal = {}, this._getSegments(!0);
            var t = this.masonryHorizontal.rows;
            for (this.masonryHorizontal.rowXs = []; t--;) this.masonryHorizontal.rowXs.push(0)
        },
        _masonryHorizontalLayout: function(t) {
            var s = this,
                e = s.masonryHorizontal;
            t.each(function() {
                var t = i(this),
                    n = Math.ceil(t.outerHeight(!0) / e.rowHeight);
                if (n = Math.min(n, e.rows), 1 === n) s._masonryHorizontalPlaceBrick(t, e.rowXs);
                else {
                    var o, r, a = e.rows + 1 - n,
                        h = [];
                    for (r = 0; a > r; r++) o = e.rowXs.slice(r, r + n), h[r] = Math.max.apply(Math, o);
                    s._masonryHorizontalPlaceBrick(t, h)
                }
            })
        },
        _masonryHorizontalPlaceBrick: function(t, i) {
            for (var s = Math.min.apply(Math, i), e = 0, n = 0, o = i.length; o > n; n++)
                if (i[n] === s) {
                    e = n;
                    break
                }
            var r = s,
                a = this.masonryHorizontal.rowHeight * e;
            this._pushPosition(t, r, a);
            var h = s + t.outerWidth(!0),
                l = this.masonryHorizontal.rows + 1 - o;
            for (n = 0; l > n; n++) this.masonryHorizontal.rowXs[e + n] = h
        },
        _masonryHorizontalGetContainerSize: function() {
            var t = Math.max.apply(Math, this.masonryHorizontal.rowXs);
            return {
                width: t
            }
        },
        _masonryHorizontalResizeChanged: function() {
            return this._checkIfSegmentsChanged(!0)
        },
        _fitColumnsReset: function() {
            this.fitColumns = {
                x: 0,
                y: 0,
                width: 0
            }
        },
        _fitColumnsLayout: function(t) {
            var s = this,
                e = this.element.height(),
                n = this.fitColumns;
            t.each(function() {
                var t = i(this),
                    o = t.outerWidth(!0),
                    r = t.outerHeight(!0);
                0 !== n.y && r + n.y > e && (n.x = n.width, n.y = 0), s._pushPosition(t, n.x, n.y), n.width = Math.max(n.x + o, n.width), n.y += r
            })
        },
        _fitColumnsGetContainerSize: function() {
            return {
                width: this.fitColumns.width
            }
        },
        _fitColumnsResizeChanged: function() {
            return !0
        },
        _cellsByColumnReset: function() {
            this.cellsByColumn = {
                index: 0
            }, this._getSegments(), this._getSegments(!0)
        },
        _cellsByColumnLayout: function(t) {
            var s = this,
                e = this.cellsByColumn;
            t.each(function() {
                var t = i(this),
                    n = Math.floor(e.index / e.rows),
                    o = e.index % e.rows,
                    r = (n + .5) * e.columnWidth - t.outerWidth(!0) / 2,
                    a = (o + .5) * e.rowHeight - t.outerHeight(!0) / 2;
                s._pushPosition(t, r, a), e.index++
            })
        },
        _cellsByColumnGetContainerSize: function() {
            return {
                width: Math.ceil(this.$filteredAtoms.length / this.cellsByColumn.rows) * this.cellsByColumn.columnWidth
            }
        },
        _cellsByColumnResizeChanged: function() {
            return this._checkIfSegmentsChanged(!0)
        },
        _straightAcrossReset: function() {
            this.straightAcross = {
                x: 0
            }
        },
        _straightAcrossLayout: function(t) {
            var s = this;
            t.each(function(t) {
                var e = i(this);
                s._pushPosition(e, s.straightAcross.x, 0), s.straightAcross.x += e.outerWidth(!0)
            })
        },
        _straightAcrossGetContainerSize: function() {
            return {
                width: this.straightAcross.x
            }
        },
        _straightAcrossResizeChanged: function() {
            return !0
        }
    }, i.fn.imagesLoaded = function(t) {
        function s() {
            t.call(n, o)
        }

        function e(t) {
            var n = t.target;
            n.src !== a && -1 === i.inArray(n, h) && (h.push(n), --r <= 0 && (setTimeout(s), o.unbind(".imagesLoaded", e)))
        }
        var n = this,
            o = n.find("img").add(n.filter("img")),
            r = o.length,
            a = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==",
            h = [];
        return r || s(), o.bind("load.imagesLoaded error.imagesLoaded", e).each(function() {
            var t = this.src;
            this.src = a, this.src = t
        }), n
    };
    var z = function(i) {
        t.console && t.console.error(i)
    };
    i.fn.isotope = function(t, s) {
        if ("string" == typeof t) {
            var e = Array.prototype.slice.call(arguments, 1);
            this.each(function() {
                var s = i.data(this, "isotope");
                return s ? i.isFunction(s[t]) && "_" !== t.charAt(0) ? void s[t].apply(s, e) : void z("no such method '" + t + "' for isotope instance") : void z("cannot call methods on isotope prior to initialization; attempted to call method '" + t + "'")
            })
        } else this.each(function() {
            var e = i.data(this, "isotope");
            e ? (e.option(t), e._init(s)) : i.data(this, "isotope", new i.Isotope(t, this, s))
        });
        return this
    }
}(window, jQuery);
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlcyI6WyJpc290b3BlLmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKiBJc290b3BlICoqL1xuISBmdW5jdGlvbih0LCBpLCBzKSB7XG4gICAgXCJ1c2Ugc3RyaWN0XCI7XG4gICAgdmFyIGUsIG4gPSB0LmRvY3VtZW50LFxuICAgICAgICBvID0gdC5Nb2Rlcm5penIsXG4gICAgICAgIHIgPSBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICByZXR1cm4gdC5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIHQuc2xpY2UoMSlcbiAgICAgICAgfSxcbiAgICAgICAgYSA9IFwiTW96IFdlYmtpdCBPIE1zXCIuc3BsaXQoXCIgXCIpLFxuICAgICAgICBoID0gZnVuY3Rpb24odCkge1xuICAgICAgICAgICAgdmFyIGksIHMgPSBuLmRvY3VtZW50RWxlbWVudC5zdHlsZTtcbiAgICAgICAgICAgIGlmIChcInN0cmluZ1wiID09IHR5cGVvZiBzW3RdKSByZXR1cm4gdDtcbiAgICAgICAgICAgIHQgPSByKHQpO1xuICAgICAgICAgICAgZm9yICh2YXIgZSA9IDAsIG8gPSBhLmxlbmd0aDsgbyA+IGU7IGUrKylcbiAgICAgICAgICAgICAgICBpZiAoaSA9IGFbZV0gKyB0LCBcInN0cmluZ1wiID09IHR5cGVvZiBzW2ldKSByZXR1cm4gaVxuICAgICAgICB9LFxuICAgICAgICBsID0gaChcInRyYW5zZm9ybVwiKSxcbiAgICAgICAgdSA9IGgoXCJ0cmFuc2l0aW9uUHJvcGVydHlcIiksXG4gICAgICAgIGMgPSB7XG4gICAgICAgICAgICBjc3N0cmFuc2Zvcm1zOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gISFsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY3NzdHJhbnNmb3JtczNkOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICB2YXIgdCA9ICEhaChcInBlcnNwZWN0aXZlXCIpO1xuICAgICAgICAgICAgICAgIGlmICh0KSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBzID0gXCIgLW8tIC1tb3otIC1tcy0gLXdlYmtpdC0gLWtodG1sLSBcIi5zcGxpdChcIiBcIiksXG4gICAgICAgICAgICAgICAgICAgICAgICBlID0gXCJAbWVkaWEgKFwiICsgcy5qb2luKFwidHJhbnNmb3JtLTNkKSwoXCIpICsgXCJtb2Rlcm5penIpXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBuID0gaShcIjxzdHlsZT5cIiArIGUgKyBcInsjbW9kZXJuaXpye2hlaWdodDozcHh9fTwvc3R5bGU+XCIpLmFwcGVuZFRvKFwiaGVhZFwiKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIG8gPSBpKCc8ZGl2IGlkPVwibW9kZXJuaXpyXCIgLz4nKS5hcHBlbmRUbyhcImh0bWxcIik7XG4gICAgICAgICAgICAgICAgICAgIHQgPSAzID09PSBvLmhlaWdodCgpLCBvLnJlbW92ZSgpLCBuLnJlbW92ZSgpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiB0XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY3NzdHJhbnNpdGlvbnM6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiAhIXVcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICBpZiAobylcbiAgICAgICAgZm9yIChlIGluIGMpIG8uaGFzT3duUHJvcGVydHkoZSkgfHwgby5hZGRUZXN0KGUsIGNbZV0pO1xuICAgIGVsc2Uge1xuICAgICAgICBvID0gdC5Nb2Rlcm5penIgPSB7XG4gICAgICAgICAgICBfdmVyc2lvbjogXCIxLjZpc2g6IG1pbmlNb2Rlcm5penIgZm9yIElzb3RvcGVcIlxuICAgICAgICB9O1xuICAgICAgICB2YXIgZCwgZiA9IFwiIFwiO1xuICAgICAgICBmb3IgKGUgaW4gYykgZCA9IGNbZV0oKSwgb1tlXSA9IGQsIGYgKz0gXCIgXCIgKyAoZCA/IFwiXCIgOiBcIm5vLVwiKSArIGU7XG4gICAgICAgIGkoXCJodG1sXCIpLmFkZENsYXNzKGYpXG4gICAgfVxuICAgIGlmIChvLmNzc3RyYW5zZm9ybXMpIHtcbiAgICAgICAgdmFyIG0gPSBvLmNzc3RyYW5zZm9ybXMzZCA/IHtcbiAgICAgICAgICAgICAgICB0cmFuc2xhdGU6IGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwidHJhbnNsYXRlM2QoXCIgKyB0WzBdICsgXCJweCwgXCIgKyB0WzFdICsgXCJweCwgMCkgXCJcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHNjYWxlOiBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcInNjYWxlM2QoXCIgKyB0ICsgXCIsIFwiICsgdCArIFwiLCAxKSBcIlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gOiB7XG4gICAgICAgICAgICAgICAgdHJhbnNsYXRlOiBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcInRyYW5zbGF0ZShcIiArIHRbMF0gKyBcInB4LCBcIiArIHRbMV0gKyBcInB4KSBcIlxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgc2NhbGU6IGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwic2NhbGUoXCIgKyB0ICsgXCIpIFwiXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHAgPSBmdW5jdGlvbih0LCBzLCBlKSB7XG4gICAgICAgICAgICAgICAgdmFyIG4sIG8sIHIgPSBpLmRhdGEodCwgXCJpc29UcmFuc2Zvcm1cIikgfHwge30sXG4gICAgICAgICAgICAgICAgICAgIGEgPSB7fSxcbiAgICAgICAgICAgICAgICAgICAgaCA9IHt9O1xuICAgICAgICAgICAgICAgIGFbc10gPSBlLCBpLmV4dGVuZChyLCBhKTtcbiAgICAgICAgICAgICAgICBmb3IgKG4gaW4gcikgbyA9IHJbbl0sIGhbbl0gPSBtW25dKG8pO1xuICAgICAgICAgICAgICAgIHZhciB1ID0gaC50cmFuc2xhdGUgfHwgXCJcIixcbiAgICAgICAgICAgICAgICAgICAgYyA9IGguc2NhbGUgfHwgXCJcIixcbiAgICAgICAgICAgICAgICAgICAgZCA9IHUgKyBjO1xuICAgICAgICAgICAgICAgIGkuZGF0YSh0LCBcImlzb1RyYW5zZm9ybVwiLCByKSwgdC5zdHlsZVtsXSA9IGRcbiAgICAgICAgICAgIH07XG4gICAgICAgIGkuY3NzTnVtYmVyLnNjYWxlID0gITAsIGkuY3NzSG9va3Muc2NhbGUgPSB7XG4gICAgICAgICAgICBzZXQ6IGZ1bmN0aW9uKHQsIGkpIHtcbiAgICAgICAgICAgICAgICBwKHQsIFwic2NhbGVcIiwgaSlcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uKHQsIHMpIHtcbiAgICAgICAgICAgICAgICB2YXIgZSA9IGkuZGF0YSh0LCBcImlzb1RyYW5zZm9ybVwiKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZSAmJiBlLnNjYWxlID8gZS5zY2FsZSA6IDFcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSwgaS5meC5zdGVwLnNjYWxlID0gZnVuY3Rpb24odCkge1xuICAgICAgICAgICAgaS5jc3NIb29rcy5zY2FsZS5zZXQodC5lbGVtLCB0Lm5vdyArIHQudW5pdClcbiAgICAgICAgfSwgaS5jc3NOdW1iZXIudHJhbnNsYXRlID0gITAsIGkuY3NzSG9va3MudHJhbnNsYXRlID0ge1xuICAgICAgICAgICAgc2V0OiBmdW5jdGlvbih0LCBpKSB7XG4gICAgICAgICAgICAgICAgcCh0LCBcInRyYW5zbGF0ZVwiLCBpKVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGdldDogZnVuY3Rpb24odCwgcykge1xuICAgICAgICAgICAgICAgIHZhciBlID0gaS5kYXRhKHQsIFwiaXNvVHJhbnNmb3JtXCIpO1xuICAgICAgICAgICAgICAgIHJldHVybiBlICYmIGUudHJhbnNsYXRlID8gZS50cmFuc2xhdGUgOiBbMCwgMF1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICB2YXIgeSwgZztcbiAgICBvLmNzc3RyYW5zaXRpb25zICYmICh5ID0ge1xuICAgICAgICBXZWJraXRUcmFuc2l0aW9uUHJvcGVydHk6IFwid2Via2l0VHJhbnNpdGlvbkVuZFwiLFxuICAgICAgICBNb3pUcmFuc2l0aW9uUHJvcGVydHk6IFwidHJhbnNpdGlvbmVuZFwiLFxuICAgICAgICBPVHJhbnNpdGlvblByb3BlcnR5OiBcIm9UcmFuc2l0aW9uRW5kIG90cmFuc2l0aW9uZW5kXCIsXG4gICAgICAgIHRyYW5zaXRpb25Qcm9wZXJ0eTogXCJ0cmFuc2l0aW9uZW5kXCJcbiAgICB9W3VdLCBnID0gaChcInRyYW5zaXRpb25EdXJhdGlvblwiKSk7XG4gICAgdmFyIHYsIF8gPSBpLmV2ZW50LFxuICAgICAgICBBID0gaS5ldmVudC5oYW5kbGUgPyBcImhhbmRsZVwiIDogXCJkaXNwYXRjaFwiO1xuICAgIF8uc3BlY2lhbC5zbWFydHJlc2l6ZSA9IHtcbiAgICAgICAgc2V0dXA6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgaSh0aGlzKS5iaW5kKFwicmVzaXplXCIsIF8uc3BlY2lhbC5zbWFydHJlc2l6ZS5oYW5kbGVyKVxuICAgICAgICB9LFxuICAgICAgICB0ZWFyZG93bjogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBpKHRoaXMpLnVuYmluZChcInJlc2l6ZVwiLCBfLnNwZWNpYWwuc21hcnRyZXNpemUuaGFuZGxlcilcbiAgICAgICAgfSxcbiAgICAgICAgaGFuZGxlcjogZnVuY3Rpb24odCwgaSkge1xuICAgICAgICAgICAgdmFyIHMgPSB0aGlzLFxuICAgICAgICAgICAgICAgIGUgPSBhcmd1bWVudHM7XG4gICAgICAgICAgICB0LnR5cGUgPSBcInNtYXJ0cmVzaXplXCIsIHYgJiYgY2xlYXJUaW1lb3V0KHYpLCB2ID0gc2V0VGltZW91dChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICBfW0FdLmFwcGx5KHMsIGUpXG4gICAgICAgICAgICB9LCBcImV4ZWNBc2FwXCIgPT09IGkgPyAwIDogMTAwKVxuICAgICAgICB9XG4gICAgfSwgaS5mbi5zbWFydHJlc2l6ZSA9IGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgcmV0dXJuIHQgPyB0aGlzLmJpbmQoXCJzbWFydHJlc2l6ZVwiLCB0KSA6IHRoaXMudHJpZ2dlcihcInNtYXJ0cmVzaXplXCIsIFtcImV4ZWNBc2FwXCJdKVxuICAgIH0sIGkuSXNvdG9wZSA9IGZ1bmN0aW9uKHQsIHMsIGUpIHtcbiAgICAgICAgdGhpcy5lbGVtZW50ID0gaShzKSwgdGhpcy5fY3JlYXRlKHQpLCB0aGlzLl9pbml0KGUpXG4gICAgfTtcbiAgICB2YXIgdyA9IFtcIndpZHRoXCIsIFwiaGVpZ2h0XCJdLFxuICAgICAgICBDID0gaSh0KTtcbiAgICBpLklzb3RvcGUuc2V0dGluZ3MgPSB7XG4gICAgICAgIHJlc2l6YWJsZTogITAsXG4gICAgICAgIGxheW91dE1vZGU6IFwibWFzb25yeVwiLFxuICAgICAgICBjb250YWluZXJDbGFzczogXCJpc290b3BlXCIsXG4gICAgICAgIGl0ZW1DbGFzczogXCJpc290b3BlLWl0ZW1cIixcbiAgICAgICAgaGlkZGVuQ2xhc3M6IFwiaXNvdG9wZS1oaWRkZW5cIixcbiAgICAgICAgaGlkZGVuU3R5bGU6IHtcbiAgICAgICAgICAgIG9wYWNpdHk6IDAsXG4gICAgICAgICAgICBzY2FsZTogLjAwMVxuICAgICAgICB9LFxuICAgICAgICB2aXNpYmxlU3R5bGU6IHtcbiAgICAgICAgICAgIG9wYWNpdHk6IDEsXG4gICAgICAgICAgICBzY2FsZTogMVxuICAgICAgICB9LFxuICAgICAgICBjb250YWluZXJTdHlsZToge1xuICAgICAgICAgICAgcG9zaXRpb246IFwicmVsYXRpdmVcIixcbiAgICAgICAgICAgIG92ZXJmbG93OiBcImhpZGRlblwiXG4gICAgICAgIH0sXG4gICAgICAgIGFuaW1hdGlvbkVuZ2luZTogXCJiZXN0LWF2YWlsYWJsZVwiLFxuICAgICAgICBhbmltYXRpb25PcHRpb25zOiB7XG4gICAgICAgICAgICBxdWV1ZTogITEsXG4gICAgICAgICAgICBkdXJhdGlvbjogODAwXG4gICAgICAgIH0sXG4gICAgICAgIHNvcnRCeTogXCJvcmlnaW5hbC1vcmRlclwiLFxuICAgICAgICBzb3J0QXNjZW5kaW5nOiAhMCxcbiAgICAgICAgcmVzaXplc0NvbnRhaW5lcjogITAsXG4gICAgICAgIHRyYW5zZm9ybXNFbmFibGVkOiAhMCxcbiAgICAgICAgaXRlbVBvc2l0aW9uRGF0YUVuYWJsZWQ6ICExXG4gICAgfSwgaS5Jc290b3BlLnByb3RvdHlwZSA9IHtcbiAgICAgICAgX2NyZWF0ZTogZnVuY3Rpb24odCkge1xuICAgICAgICAgICAgdGhpcy5vcHRpb25zID0gaS5leHRlbmQoe30sIGkuSXNvdG9wZS5zZXR0aW5ncywgdCksIHRoaXMuc3R5bGVRdWV1ZSA9IFtdLCB0aGlzLmVsZW1Db3VudCA9IDA7XG4gICAgICAgICAgICB2YXIgcyA9IHRoaXMuZWxlbWVudFswXS5zdHlsZTtcbiAgICAgICAgICAgIHRoaXMub3JpZ2luYWxTdHlsZSA9IHt9O1xuICAgICAgICAgICAgdmFyIGUgPSB3LnNsaWNlKDApO1xuICAgICAgICAgICAgZm9yICh2YXIgbiBpbiB0aGlzLm9wdGlvbnMuY29udGFpbmVyU3R5bGUpIGUucHVzaChuKTtcbiAgICAgICAgICAgIGZvciAodmFyIG8gPSAwLCByID0gZS5sZW5ndGg7IHIgPiBvOyBvKyspIG4gPSBlW29dLCB0aGlzLm9yaWdpbmFsU3R5bGVbbl0gPSBzW25dIHx8IFwiXCI7XG4gICAgICAgICAgICB0aGlzLmVsZW1lbnQuY3NzKHRoaXMub3B0aW9ucy5jb250YWluZXJTdHlsZSksIHRoaXMuX3VwZGF0ZUFuaW1hdGlvbkVuZ2luZSgpLCB0aGlzLl91cGRhdGVVc2luZ1RyYW5zZm9ybXMoKTtcbiAgICAgICAgICAgIHZhciBhID0ge1xuICAgICAgICAgICAgICAgIFwib3JpZ2luYWwtb3JkZXJcIjogZnVuY3Rpb24odCwgaSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaS5lbGVtQ291bnQrKywgaS5lbGVtQ291bnRcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHJhbmRvbTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBNYXRoLnJhbmRvbSgpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMub3B0aW9ucy5nZXRTb3J0RGF0YSA9IGkuZXh0ZW5kKHRoaXMub3B0aW9ucy5nZXRTb3J0RGF0YSwgYSksIHRoaXMucmVsb2FkSXRlbXMoKSwgdGhpcy5vZmZzZXQgPSB7XG4gICAgICAgICAgICAgICAgbGVmdDogcGFyc2VJbnQodGhpcy5lbGVtZW50LmNzcyhcInBhZGRpbmctbGVmdFwiKSB8fCAwLCAxMCksXG4gICAgICAgICAgICAgICAgdG9wOiBwYXJzZUludCh0aGlzLmVsZW1lbnQuY3NzKFwicGFkZGluZy10b3BcIikgfHwgMCwgMTApXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdmFyIGggPSB0aGlzO1xuICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICBoLmVsZW1lbnQuYWRkQ2xhc3MoaC5vcHRpb25zLmNvbnRhaW5lckNsYXNzKVxuICAgICAgICAgICAgfSwgMCksIHRoaXMub3B0aW9ucy5yZXNpemFibGUgJiYgQy5iaW5kKFwic21hcnRyZXNpemUuaXNvdG9wZVwiLCBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICBoLnJlc2l6ZSgpXG4gICAgICAgICAgICB9KSwgdGhpcy5lbGVtZW50LmRlbGVnYXRlKFwiLlwiICsgdGhpcy5vcHRpb25zLmhpZGRlbkNsYXNzLCBcImNsaWNrXCIsIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiAhMVxuICAgICAgICAgICAgfSlcbiAgICAgICAgfSxcbiAgICAgICAgX2dldEF0b21zOiBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICB2YXIgaSA9IHRoaXMub3B0aW9ucy5pdGVtU2VsZWN0b3IsXG4gICAgICAgICAgICAgICAgcyA9IGkgPyB0LmZpbHRlcihpKS5hZGQodC5maW5kKGkpKSA6IHQsXG4gICAgICAgICAgICAgICAgZSA9IHtcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIlxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICByZXR1cm4gcyA9IHMuZmlsdGVyKGZ1bmN0aW9uKHQsIGkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gMSA9PT0gaS5ub2RlVHlwZVxuICAgICAgICAgICAgfSksIHRoaXMudXNpbmdUcmFuc2Zvcm1zICYmIChlLmxlZnQgPSAwLCBlLnRvcCA9IDApLCBzLmNzcyhlKS5hZGRDbGFzcyh0aGlzLm9wdGlvbnMuaXRlbUNsYXNzKSwgdGhpcy51cGRhdGVTb3J0RGF0YShzLCAhMCksIHNcbiAgICAgICAgfSxcbiAgICAgICAgX2luaXQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgICAgIHRoaXMuJGZpbHRlcmVkQXRvbXMgPSB0aGlzLl9maWx0ZXIodGhpcy4kYWxsQXRvbXMpLCB0aGlzLl9zb3J0KCksIHRoaXMucmVMYXlvdXQodClcbiAgICAgICAgfSxcbiAgICAgICAgb3B0aW9uOiBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICBpZiAoaS5pc1BsYWluT2JqZWN0KHQpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5vcHRpb25zID0gaS5leHRlbmQoITAsIHRoaXMub3B0aW9ucywgdCk7XG4gICAgICAgICAgICAgICAgdmFyIHM7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgZSBpbiB0KSBzID0gXCJfdXBkYXRlXCIgKyByKGUpLCB0aGlzW3NdICYmIHRoaXNbc10oKVxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBfdXBkYXRlQW5pbWF0aW9uRW5naW5lOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHZhciB0LCBpID0gdGhpcy5vcHRpb25zLmFuaW1hdGlvbkVuZ2luZS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL1sgX1xcLV0vZywgXCJcIik7XG4gICAgICAgICAgICBzd2l0Y2ggKGkpIHtcbiAgICAgICAgICAgICAgICBjYXNlIFwiY3NzXCI6XG4gICAgICAgICAgICAgICAgY2FzZSBcIm5vbmVcIjpcbiAgICAgICAgICAgICAgICAgICAgdCA9ICExO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIFwianF1ZXJ5XCI6XG4gICAgICAgICAgICAgICAgICAgIHQgPSAhMDtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgdCA9ICFvLmNzc3RyYW5zaXRpb25zXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLmlzVXNpbmdKUXVlcnlBbmltYXRpb24gPSB0LCB0aGlzLl91cGRhdGVVc2luZ1RyYW5zZm9ybXMoKVxuICAgICAgICB9LFxuICAgICAgICBfdXBkYXRlVHJhbnNmb3Jtc0VuYWJsZWQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgdGhpcy5fdXBkYXRlVXNpbmdUcmFuc2Zvcm1zKClcbiAgICAgICAgfSxcbiAgICAgICAgX3VwZGF0ZVVzaW5nVHJhbnNmb3JtczogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICB2YXIgdCA9IHRoaXMudXNpbmdUcmFuc2Zvcm1zID0gdGhpcy5vcHRpb25zLnRyYW5zZm9ybXNFbmFibGVkICYmIG8uY3NzdHJhbnNmb3JtcyAmJiBvLmNzc3RyYW5zaXRpb25zICYmICF0aGlzLmlzVXNpbmdKUXVlcnlBbmltYXRpb247XG4gICAgICAgICAgICB0IHx8IChkZWxldGUgdGhpcy5vcHRpb25zLmhpZGRlblN0eWxlLnNjYWxlLCBkZWxldGUgdGhpcy5vcHRpb25zLnZpc2libGVTdHlsZS5zY2FsZSksIHRoaXMuZ2V0UG9zaXRpb25TdHlsZXMgPSB0ID8gdGhpcy5fdHJhbnNsYXRlIDogdGhpcy5fcG9zaXRpb25BYnNcbiAgICAgICAgfSxcbiAgICAgICAgX2ZpbHRlcjogZnVuY3Rpb24odCkge1xuICAgICAgICAgICAgdmFyIGkgPSBcIlwiID09PSB0aGlzLm9wdGlvbnMuZmlsdGVyID8gXCIqXCIgOiB0aGlzLm9wdGlvbnMuZmlsdGVyO1xuICAgICAgICAgICAgaWYgKCFpKSByZXR1cm4gdDtcbiAgICAgICAgICAgIHZhciBzID0gdGhpcy5vcHRpb25zLmhpZGRlbkNsYXNzLFxuICAgICAgICAgICAgICAgIGUgPSBcIi5cIiArIHMsXG4gICAgICAgICAgICAgICAgbiA9IHQuZmlsdGVyKGUpLFxuICAgICAgICAgICAgICAgIG8gPSBuO1xuICAgICAgICAgICAgaWYgKFwiKlwiICE9PSBpKSB7XG4gICAgICAgICAgICAgICAgbyA9IG4uZmlsdGVyKGkpO1xuICAgICAgICAgICAgICAgIHZhciByID0gdC5ub3QoZSkubm90KGkpLmFkZENsYXNzKHMpO1xuICAgICAgICAgICAgICAgIHRoaXMuc3R5bGVRdWV1ZS5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgJGVsOiByLFxuICAgICAgICAgICAgICAgICAgICBzdHlsZTogdGhpcy5vcHRpb25zLmhpZGRlblN0eWxlXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0aGlzLnN0eWxlUXVldWUucHVzaCh7XG4gICAgICAgICAgICAgICAgJGVsOiBvLFxuICAgICAgICAgICAgICAgIHN0eWxlOiB0aGlzLm9wdGlvbnMudmlzaWJsZVN0eWxlXG4gICAgICAgICAgICB9KSwgby5yZW1vdmVDbGFzcyhzKSwgdC5maWx0ZXIoaSlcbiAgICAgICAgfSxcbiAgICAgICAgdXBkYXRlU29ydERhdGE6IGZ1bmN0aW9uKHQsIHMpIHtcbiAgICAgICAgICAgIHZhciBlLCBuLCBvID0gdGhpcyxcbiAgICAgICAgICAgICAgICByID0gdGhpcy5vcHRpb25zLmdldFNvcnREYXRhO1xuICAgICAgICAgICAgdC5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIGUgPSBpKHRoaXMpLCBuID0ge307XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgdCBpbiByKSBzIHx8IFwib3JpZ2luYWwtb3JkZXJcIiAhPT0gdCA/IG5bdF0gPSByW3RdKGUsIG8pIDogblt0XSA9IGkuZGF0YSh0aGlzLCBcImlzb3RvcGUtc29ydC1kYXRhXCIpW3RdO1xuICAgICAgICAgICAgICAgIGkuZGF0YSh0aGlzLCBcImlzb3RvcGUtc29ydC1kYXRhXCIsIG4pXG4gICAgICAgICAgICB9KVxuICAgICAgICB9LFxuICAgICAgICBfc29ydDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICB2YXIgdCA9IHRoaXMub3B0aW9ucy5zb3J0QnksXG4gICAgICAgICAgICAgICAgaSA9IHRoaXMuX2dldFNvcnRlcixcbiAgICAgICAgICAgICAgICBzID0gdGhpcy5vcHRpb25zLnNvcnRBc2NlbmRpbmcgPyAxIDogLTEsXG4gICAgICAgICAgICAgICAgZSA9IGZ1bmN0aW9uKGUsIG4pIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIG8gPSBpKGUsIHQpLFxuICAgICAgICAgICAgICAgICAgICAgICAgciA9IGkobiwgdCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBvID09PSByICYmIFwib3JpZ2luYWwtb3JkZXJcIiAhPT0gdCAmJiAobyA9IGkoZSwgXCJvcmlnaW5hbC1vcmRlclwiKSwgciA9IGkobiwgXCJvcmlnaW5hbC1vcmRlclwiKSksIChvID4gciA/IDEgOiByID4gbyA/IC0xIDogMCkgKiBzXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMuJGZpbHRlcmVkQXRvbXMuc29ydChlKVxuICAgICAgICB9LFxuICAgICAgICBfZ2V0U29ydGVyOiBmdW5jdGlvbih0LCBzKSB7XG4gICAgICAgICAgICByZXR1cm4gaS5kYXRhKHQsIFwiaXNvdG9wZS1zb3J0LWRhdGFcIilbc11cbiAgICAgICAgfSxcbiAgICAgICAgX3RyYW5zbGF0ZTogZnVuY3Rpb24odCwgaSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICB0cmFuc2xhdGU6IFt0LCBpXVxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBfcG9zaXRpb25BYnM6IGZ1bmN0aW9uKHQsIGkpIHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgbGVmdDogdCxcbiAgICAgICAgICAgICAgICB0b3A6IGlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgX3B1c2hQb3NpdGlvbjogZnVuY3Rpb24odCwgaSwgcykge1xuICAgICAgICAgICAgaSA9IE1hdGgucm91bmQoaSArIHRoaXMub2Zmc2V0LmxlZnQpLCBzID0gTWF0aC5yb3VuZChzICsgdGhpcy5vZmZzZXQudG9wKTtcbiAgICAgICAgICAgIHZhciBlID0gdGhpcy5nZXRQb3NpdGlvblN0eWxlcyhpLCBzKTtcbiAgICAgICAgICAgIHRoaXMuc3R5bGVRdWV1ZS5wdXNoKHtcbiAgICAgICAgICAgICAgICAkZWw6IHQsXG4gICAgICAgICAgICAgICAgc3R5bGU6IGVcbiAgICAgICAgICAgIH0pLCB0aGlzLm9wdGlvbnMuaXRlbVBvc2l0aW9uRGF0YUVuYWJsZWQgJiYgdC5kYXRhKFwiaXNvdG9wZS1pdGVtLXBvc2l0aW9uXCIsIHtcbiAgICAgICAgICAgICAgICB4OiBpLFxuICAgICAgICAgICAgICAgIHk6IHNcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIGxheW91dDogZnVuY3Rpb24odCwgaSkge1xuICAgICAgICAgICAgdmFyIHMgPSB0aGlzLm9wdGlvbnMubGF5b3V0TW9kZTtcbiAgICAgICAgICAgIGlmICh0aGlzW1wiX1wiICsgcyArIFwiTGF5b3V0XCJdKHQpLCB0aGlzLm9wdGlvbnMucmVzaXplc0NvbnRhaW5lcikge1xuICAgICAgICAgICAgICAgIHZhciBlID0gdGhpc1tcIl9cIiArIHMgKyBcIkdldENvbnRhaW5lclNpemVcIl0oKTtcbiAgICAgICAgICAgICAgICB0aGlzLnN0eWxlUXVldWUucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICRlbDogdGhpcy5lbGVtZW50LFxuICAgICAgICAgICAgICAgICAgICBzdHlsZTogZVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLl9wcm9jZXNzU3R5bGVRdWV1ZSh0LCBpKSwgdGhpcy5pc0xhaWRPdXQgPSAhMFxuICAgICAgICB9LFxuICAgICAgICBfcHJvY2Vzc1N0eWxlUXVldWU6IGZ1bmN0aW9uKHQsIHMpIHtcbiAgICAgICAgICAgIHZhciBlLCBuLCByLCBhLCBoID0gdGhpcy5pc0xhaWRPdXQgJiYgdGhpcy5pc1VzaW5nSlF1ZXJ5QW5pbWF0aW9uID8gXCJhbmltYXRlXCIgOiBcImNzc1wiLFxuICAgICAgICAgICAgICAgIGwgPSB0aGlzLm9wdGlvbnMuYW5pbWF0aW9uT3B0aW9ucyxcbiAgICAgICAgICAgICAgICB1ID0gdGhpcy5vcHRpb25zLm9uTGF5b3V0O1xuICAgICAgICAgICAgaWYgKG4gPSBmdW5jdGlvbih0LCBpKSB7XG4gICAgICAgICAgICAgICAgICAgIGkuJGVsW2hdKGkuc3R5bGUsIGwpXG4gICAgICAgICAgICAgICAgfSwgdGhpcy5faXNJbnNlcnRpbmcgJiYgdGhpcy5pc1VzaW5nSlF1ZXJ5QW5pbWF0aW9uKSBuID0gZnVuY3Rpb24odCwgaSkge1xuICAgICAgICAgICAgICAgIGUgPSBpLiRlbC5oYXNDbGFzcyhcIm5vLXRyYW5zaXRpb25cIikgPyBcImNzc1wiIDogaCwgaS4kZWxbZV0oaS5zdHlsZSwgbClcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBlbHNlIGlmIChzIHx8IHUgfHwgbC5jb21wbGV0ZSkge1xuICAgICAgICAgICAgICAgIHZhciBjID0gITEsXG4gICAgICAgICAgICAgICAgICAgIGQgPSBbcywgdSwgbC5jb21wbGV0ZV0sXG4gICAgICAgICAgICAgICAgICAgIGYgPSB0aGlzO1xuICAgICAgICAgICAgICAgIGlmIChyID0gITAsIGEgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghYykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGksIHMgPSAwLCBlID0gZC5sZW5ndGg7IGUgPiBzOyBzKyspIGkgPSBkW3NdLCBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIGkgJiYgaS5jYWxsKGYuZWxlbWVudCwgdCwgZik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYyA9ICEwXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0sIHRoaXMuaXNVc2luZ0pRdWVyeUFuaW1hdGlvbiAmJiBcImFuaW1hdGVcIiA9PT0gaCkgbC5jb21wbGV0ZSA9IGEsIHIgPSAhMTtcbiAgICAgICAgICAgICAgICBlbHNlIGlmIChvLmNzc3RyYW5zaXRpb25zKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIG0sIHAgPSAwLCB2ID0gdGhpcy5zdHlsZVF1ZXVlWzBdLCBfID0gdiAmJiB2LiRlbDsgIV8gfHwgIV8ubGVuZ3RoOykge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG0gPSB0aGlzLnN0eWxlUXVldWVbcCsrXSwgIW0pIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgIF8gPSBtLiRlbFxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHZhciBBID0gcGFyc2VGbG9hdChnZXRDb21wdXRlZFN0eWxlKF9bMF0pW2ddKTtcbiAgICAgICAgICAgICAgICAgICAgQSA+IDAgJiYgKG4gPSBmdW5jdGlvbih0LCBpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpLiRlbFtoXShpLnN0eWxlLCBsKS5vbmUoeSwgYSlcbiAgICAgICAgICAgICAgICAgICAgfSwgciA9ICExKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGkuZWFjaCh0aGlzLnN0eWxlUXVldWUsIG4pLCByICYmIGEoKSwgdGhpcy5zdHlsZVF1ZXVlID0gW11cbiAgICAgICAgfSxcbiAgICAgICAgcmVzaXplOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHRoaXNbXCJfXCIgKyB0aGlzLm9wdGlvbnMubGF5b3V0TW9kZSArIFwiUmVzaXplQ2hhbmdlZFwiXSgpICYmIHRoaXMucmVMYXlvdXQoKVxuICAgICAgICB9LFxuICAgICAgICByZUxheW91dDogZnVuY3Rpb24odCkge1xuICAgICAgICAgICAgdGhpc1tcIl9cIiArIHRoaXMub3B0aW9ucy5sYXlvdXRNb2RlICsgXCJSZXNldFwiXSgpLCB0aGlzLmxheW91dCh0aGlzLiRmaWx0ZXJlZEF0b21zLCB0KVxuICAgICAgICB9LFxuICAgICAgICBhZGRJdGVtczogZnVuY3Rpb24odCwgaSkge1xuICAgICAgICAgICAgdmFyIHMgPSB0aGlzLl9nZXRBdG9tcyh0KTtcbiAgICAgICAgICAgIHRoaXMuJGFsbEF0b21zID0gdGhpcy4kYWxsQXRvbXMuYWRkKHMpLCBpICYmIGkocylcbiAgICAgICAgfSxcbiAgICAgICAgaW5zZXJ0OiBmdW5jdGlvbih0LCBpKSB7XG4gICAgICAgICAgICB0aGlzLmVsZW1lbnQuYXBwZW5kKHQpO1xuICAgICAgICAgICAgdmFyIHMgPSB0aGlzO1xuICAgICAgICAgICAgdGhpcy5hZGRJdGVtcyh0LCBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICAgICAgdmFyIGUgPSBzLl9maWx0ZXIodCk7XG4gICAgICAgICAgICAgICAgcy5fYWRkSGlkZUFwcGVuZGVkKGUpLCBzLl9zb3J0KCksIHMucmVMYXlvdXQoKSwgcy5fcmV2ZWFsQXBwZW5kZWQoZSwgaSlcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIGFwcGVuZGVkOiBmdW5jdGlvbih0LCBpKSB7XG4gICAgICAgICAgICB2YXIgcyA9IHRoaXM7XG4gICAgICAgICAgICB0aGlzLmFkZEl0ZW1zKHQsIGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgICAgICAgICBzLl9hZGRIaWRlQXBwZW5kZWQodCksIHMubGF5b3V0KHQpLCBzLl9yZXZlYWxBcHBlbmRlZCh0LCBpKVxuICAgICAgICAgICAgfSlcbiAgICAgICAgfSxcbiAgICAgICAgX2FkZEhpZGVBcHBlbmRlZDogZnVuY3Rpb24odCkge1xuICAgICAgICAgICAgdGhpcy4kZmlsdGVyZWRBdG9tcyA9IHRoaXMuJGZpbHRlcmVkQXRvbXMuYWRkKHQpLCB0LmFkZENsYXNzKFwibm8tdHJhbnNpdGlvblwiKSwgdGhpcy5faXNJbnNlcnRpbmcgPSAhMCwgdGhpcy5zdHlsZVF1ZXVlLnB1c2goe1xuICAgICAgICAgICAgICAgICRlbDogdCxcbiAgICAgICAgICAgICAgICBzdHlsZTogdGhpcy5vcHRpb25zLmhpZGRlblN0eWxlXG4gICAgICAgICAgICB9KVxuICAgICAgICB9LFxuICAgICAgICBfcmV2ZWFsQXBwZW5kZWQ6IGZ1bmN0aW9uKHQsIGkpIHtcbiAgICAgICAgICAgIHZhciBzID0gdGhpcztcbiAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgdC5yZW1vdmVDbGFzcyhcIm5vLXRyYW5zaXRpb25cIiksIHMuc3R5bGVRdWV1ZS5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgJGVsOiB0LFxuICAgICAgICAgICAgICAgICAgICBzdHlsZTogcy5vcHRpb25zLnZpc2libGVTdHlsZVxuICAgICAgICAgICAgICAgIH0pLCBzLl9pc0luc2VydGluZyA9ICExLCBzLl9wcm9jZXNzU3R5bGVRdWV1ZSh0LCBpKVxuICAgICAgICAgICAgfSwgMTApXG4gICAgICAgIH0sXG4gICAgICAgIHJlbG9hZEl0ZW1zOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHRoaXMuJGFsbEF0b21zID0gdGhpcy5fZ2V0QXRvbXModGhpcy5lbGVtZW50LmNoaWxkcmVuKCkpXG4gICAgICAgIH0sXG4gICAgICAgIHJlbW92ZTogZnVuY3Rpb24odCwgaSkge1xuICAgICAgICAgICAgdGhpcy4kYWxsQXRvbXMgPSB0aGlzLiRhbGxBdG9tcy5ub3QodCksIHRoaXMuJGZpbHRlcmVkQXRvbXMgPSB0aGlzLiRmaWx0ZXJlZEF0b21zLm5vdCh0KTtcbiAgICAgICAgICAgIHZhciBzID0gdGhpcyxcbiAgICAgICAgICAgICAgICBlID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgIHQucmVtb3ZlKCksIGkgJiYgaS5jYWxsKHMuZWxlbWVudClcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgdC5maWx0ZXIoXCI6bm90KC5cIiArIHRoaXMub3B0aW9ucy5oaWRkZW5DbGFzcyArIFwiKVwiKS5sZW5ndGggPyAodGhpcy5zdHlsZVF1ZXVlLnB1c2goe1xuICAgICAgICAgICAgICAgICRlbDogdCxcbiAgICAgICAgICAgICAgICBzdHlsZTogdGhpcy5vcHRpb25zLmhpZGRlblN0eWxlXG4gICAgICAgICAgICB9KSwgdGhpcy5fc29ydCgpLCB0aGlzLnJlTGF5b3V0KGUpKSA6IGUoKVxuICAgICAgICB9LFxuICAgICAgICBzaHVmZmxlOiBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVNvcnREYXRhKHRoaXMuJGFsbEF0b21zKSwgdGhpcy5vcHRpb25zLnNvcnRCeSA9IFwicmFuZG9tXCIsIHRoaXMuX3NvcnQoKSwgdGhpcy5yZUxheW91dCh0KVxuICAgICAgICB9LFxuICAgICAgICBkZXN0cm95OiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHZhciB0ID0gdGhpcy51c2luZ1RyYW5zZm9ybXMsXG4gICAgICAgICAgICAgICAgaSA9IHRoaXMub3B0aW9ucztcbiAgICAgICAgICAgIHRoaXMuJGFsbEF0b21zLnJlbW92ZUNsYXNzKGkuaGlkZGVuQ2xhc3MgKyBcIiBcIiArIGkuaXRlbUNsYXNzKS5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIHZhciBpID0gdGhpcy5zdHlsZTtcbiAgICAgICAgICAgICAgICBpLnBvc2l0aW9uID0gXCJcIiwgaS50b3AgPSBcIlwiLCBpLmxlZnQgPSBcIlwiLCBpLm9wYWNpdHkgPSBcIlwiLCB0ICYmIChpW2xdID0gXCJcIilcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdmFyIHMgPSB0aGlzLmVsZW1lbnRbMF0uc3R5bGU7XG4gICAgICAgICAgICBmb3IgKHZhciBlIGluIHRoaXMub3JpZ2luYWxTdHlsZSkgc1tlXSA9IHRoaXMub3JpZ2luYWxTdHlsZVtlXTtcbiAgICAgICAgICAgIHRoaXMuZWxlbWVudC51bmJpbmQoXCIuaXNvdG9wZVwiKS51bmRlbGVnYXRlKFwiLlwiICsgaS5oaWRkZW5DbGFzcywgXCJjbGlja1wiKS5yZW1vdmVDbGFzcyhpLmNvbnRhaW5lckNsYXNzKS5yZW1vdmVEYXRhKFwiaXNvdG9wZVwiKSwgQy51bmJpbmQoXCIuaXNvdG9wZVwiKVxuICAgICAgICB9LFxuICAgICAgICBfZ2V0U2VnbWVudHM6IGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgICAgIHZhciBpLCBzID0gdGhpcy5vcHRpb25zLmxheW91dE1vZGUsXG4gICAgICAgICAgICAgICAgZSA9IHQgPyBcInJvd0hlaWdodFwiIDogXCJjb2x1bW5XaWR0aFwiLFxuICAgICAgICAgICAgICAgIG4gPSB0ID8gXCJoZWlnaHRcIiA6IFwid2lkdGhcIixcbiAgICAgICAgICAgICAgICBvID0gdCA/IFwicm93c1wiIDogXCJjb2xzXCIsXG4gICAgICAgICAgICAgICAgYSA9IHRoaXMuZWxlbWVudFtuXSgpLFxuICAgICAgICAgICAgICAgIGggPSB0aGlzLm9wdGlvbnNbc10gJiYgdGhpcy5vcHRpb25zW3NdW2VdIHx8IHRoaXMuJGZpbHRlcmVkQXRvbXNbXCJvdXRlclwiICsgcihuKV0oITApIHx8IGE7XG4gICAgICAgICAgICBpID0gTWF0aC5mbG9vcihhIC8gaCksIGkgPSBNYXRoLm1heChpLCAxKSwgdGhpc1tzXVtvXSA9IGksIHRoaXNbc11bZV0gPSBoXG4gICAgICAgIH0sXG4gICAgICAgIF9jaGVja0lmU2VnbWVudHNDaGFuZ2VkOiBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICB2YXIgaSA9IHRoaXMub3B0aW9ucy5sYXlvdXRNb2RlLFxuICAgICAgICAgICAgICAgIHMgPSB0ID8gXCJyb3dzXCIgOiBcImNvbHNcIixcbiAgICAgICAgICAgICAgICBlID0gdGhpc1tpXVtzXTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9nZXRTZWdtZW50cyh0KSwgdGhpc1tpXVtzXSAhPT0gZVxuICAgICAgICB9LFxuICAgICAgICBfbWFzb25yeVJlc2V0OiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHRoaXMubWFzb25yeSA9IHt9LCB0aGlzLl9nZXRTZWdtZW50cygpO1xuICAgICAgICAgICAgdmFyIHQgPSB0aGlzLm1hc29ucnkuY29scztcbiAgICAgICAgICAgIGZvciAodGhpcy5tYXNvbnJ5LmNvbFlzID0gW107IHQtLTspIHRoaXMubWFzb25yeS5jb2xZcy5wdXNoKDApXG4gICAgICAgIH0sXG4gICAgICAgIF9tYXNvbnJ5TGF5b3V0OiBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICB2YXIgcyA9IHRoaXMsXG4gICAgICAgICAgICAgICAgZSA9IHMubWFzb25yeTtcbiAgICAgICAgICAgIHQuZWFjaChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICB2YXIgdCA9IGkodGhpcyksXG4gICAgICAgICAgICAgICAgICAgIG4gPSBNYXRoLmNlaWwodC5vdXRlcldpZHRoKCEwKSAvIGUuY29sdW1uV2lkdGgpO1xuICAgICAgICAgICAgICAgIGlmIChuID0gTWF0aC5taW4obiwgZS5jb2xzKSwgMSA9PT0gbikgcy5fbWFzb25yeVBsYWNlQnJpY2sodCwgZS5jb2xZcyk7XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBvLCByLCBhID0gZS5jb2xzICsgMSAtIG4sXG4gICAgICAgICAgICAgICAgICAgICAgICBoID0gW107XG4gICAgICAgICAgICAgICAgICAgIGZvciAociA9IDA7IGEgPiByOyByKyspIG8gPSBlLmNvbFlzLnNsaWNlKHIsIHIgKyBuKSwgaFtyXSA9IE1hdGgubWF4LmFwcGx5KE1hdGgsIG8pO1xuICAgICAgICAgICAgICAgICAgICBzLl9tYXNvbnJ5UGxhY2VCcmljayh0LCBoKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIF9tYXNvbnJ5UGxhY2VCcmljazogZnVuY3Rpb24odCwgaSkge1xuICAgICAgICAgICAgZm9yICh2YXIgcyA9IE1hdGgubWluLmFwcGx5KE1hdGgsIGkpLCBlID0gMCwgbiA9IDAsIG8gPSBpLmxlbmd0aDsgbyA+IG47IG4rKylcbiAgICAgICAgICAgICAgICBpZiAoaVtuXSA9PT0gcykge1xuICAgICAgICAgICAgICAgICAgICBlID0gbjtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgciA9IHRoaXMubWFzb25yeS5jb2x1bW5XaWR0aCAqIGUsXG4gICAgICAgICAgICAgICAgYSA9IHM7XG4gICAgICAgICAgICB0aGlzLl9wdXNoUG9zaXRpb24odCwgciwgYSk7XG4gICAgICAgICAgICB2YXIgaCA9IHMgKyB0Lm91dGVySGVpZ2h0KCEwKSxcbiAgICAgICAgICAgICAgICBsID0gdGhpcy5tYXNvbnJ5LmNvbHMgKyAxIC0gbztcbiAgICAgICAgICAgIGZvciAobiA9IDA7IGwgPiBuOyBuKyspIHRoaXMubWFzb25yeS5jb2xZc1tlICsgbl0gPSBoXG4gICAgICAgIH0sXG4gICAgICAgIF9tYXNvbnJ5R2V0Q29udGFpbmVyU2l6ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICB2YXIgdCA9IE1hdGgubWF4LmFwcGx5KE1hdGgsIHRoaXMubWFzb25yeS5jb2xZcyk7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGhlaWdodDogdFxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBfbWFzb25yeVJlc2l6ZUNoYW5nZWQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX2NoZWNrSWZTZWdtZW50c0NoYW5nZWQoKVxuICAgICAgICB9LFxuICAgICAgICBfZml0Um93c1Jlc2V0OiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHRoaXMuZml0Um93cyA9IHtcbiAgICAgICAgICAgICAgICB4OiAwLFxuICAgICAgICAgICAgICAgIHk6IDAsXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAwXG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIF9maXRSb3dzTGF5b3V0OiBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICB2YXIgcyA9IHRoaXMsXG4gICAgICAgICAgICAgICAgZSA9IHRoaXMuZWxlbWVudC53aWR0aCgpLFxuICAgICAgICAgICAgICAgIG4gPSB0aGlzLmZpdFJvd3M7XG4gICAgICAgICAgICB0LmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgdmFyIHQgPSBpKHRoaXMpLFxuICAgICAgICAgICAgICAgICAgICBvID0gdC5vdXRlcldpZHRoKCEwKSxcbiAgICAgICAgICAgICAgICAgICAgciA9IHQub3V0ZXJIZWlnaHQoITApO1xuICAgICAgICAgICAgICAgIDAgIT09IG4ueCAmJiBvICsgbi54ID4gZSAmJiAobi54ID0gMCwgbi55ID0gbi5oZWlnaHQpLCBzLl9wdXNoUG9zaXRpb24odCwgbi54LCBuLnkpLCBuLmhlaWdodCA9IE1hdGgubWF4KG4ueSArIHIsIG4uaGVpZ2h0KSwgbi54ICs9IG9cbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIF9maXRSb3dzR2V0Q29udGFpbmVyU2l6ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGhlaWdodDogdGhpcy5maXRSb3dzLmhlaWdodFxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBfZml0Um93c1Jlc2l6ZUNoYW5nZWQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgcmV0dXJuICEwXG4gICAgICAgIH0sXG4gICAgICAgIF9jZWxsc0J5Um93UmVzZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgdGhpcy5jZWxsc0J5Um93ID0ge1xuICAgICAgICAgICAgICAgIGluZGV4OiAwXG4gICAgICAgICAgICB9LCB0aGlzLl9nZXRTZWdtZW50cygpLCB0aGlzLl9nZXRTZWdtZW50cyghMClcbiAgICAgICAgfSxcbiAgICAgICAgX2NlbGxzQnlSb3dMYXlvdXQ6IGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgICAgIHZhciBzID0gdGhpcyxcbiAgICAgICAgICAgICAgICBlID0gdGhpcy5jZWxsc0J5Um93O1xuICAgICAgICAgICAgdC5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIHZhciB0ID0gaSh0aGlzKSxcbiAgICAgICAgICAgICAgICAgICAgbiA9IGUuaW5kZXggJSBlLmNvbHMsXG4gICAgICAgICAgICAgICAgICAgIG8gPSBNYXRoLmZsb29yKGUuaW5kZXggLyBlLmNvbHMpLFxuICAgICAgICAgICAgICAgICAgICByID0gKG4gKyAuNSkgKiBlLmNvbHVtbldpZHRoIC0gdC5vdXRlcldpZHRoKCEwKSAvIDIsXG4gICAgICAgICAgICAgICAgICAgIGEgPSAobyArIC41KSAqIGUucm93SGVpZ2h0IC0gdC5vdXRlckhlaWdodCghMCkgLyAyO1xuICAgICAgICAgICAgICAgIHMuX3B1c2hQb3NpdGlvbih0LCByLCBhKSwgZS5pbmRleCsrXG4gICAgICAgICAgICB9KVxuICAgICAgICB9LFxuICAgICAgICBfY2VsbHNCeVJvd0dldENvbnRhaW5lclNpemU6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IE1hdGguY2VpbCh0aGlzLiRmaWx0ZXJlZEF0b21zLmxlbmd0aCAvIHRoaXMuY2VsbHNCeVJvdy5jb2xzKSAqIHRoaXMuY2VsbHNCeVJvdy5yb3dIZWlnaHQgKyB0aGlzLm9mZnNldC50b3BcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgX2NlbGxzQnlSb3dSZXNpemVDaGFuZ2VkOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9jaGVja0lmU2VnbWVudHNDaGFuZ2VkKClcbiAgICAgICAgfSxcbiAgICAgICAgX3N0cmFpZ2h0RG93blJlc2V0OiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHRoaXMuc3RyYWlnaHREb3duID0ge1xuICAgICAgICAgICAgICAgIHk6IDBcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgX3N0cmFpZ2h0RG93bkxheW91dDogZnVuY3Rpb24odCkge1xuICAgICAgICAgICAgdmFyIHMgPSB0aGlzO1xuICAgICAgICAgICAgdC5lYWNoKGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgICAgICAgICB2YXIgZSA9IGkodGhpcyk7XG4gICAgICAgICAgICAgICAgcy5fcHVzaFBvc2l0aW9uKGUsIDAsIHMuc3RyYWlnaHREb3duLnkpLCBzLnN0cmFpZ2h0RG93bi55ICs9IGUub3V0ZXJIZWlnaHQoITApXG4gICAgICAgICAgICB9KVxuICAgICAgICB9LFxuICAgICAgICBfc3RyYWlnaHREb3duR2V0Q29udGFpbmVyU2l6ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGhlaWdodDogdGhpcy5zdHJhaWdodERvd24ueVxuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBfc3RyYWlnaHREb3duUmVzaXplQ2hhbmdlZDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gITBcbiAgICAgICAgfSxcbiAgICAgICAgX21hc29ucnlIb3Jpem9udGFsUmVzZXQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgdGhpcy5tYXNvbnJ5SG9yaXpvbnRhbCA9IHt9LCB0aGlzLl9nZXRTZWdtZW50cyghMCk7XG4gICAgICAgICAgICB2YXIgdCA9IHRoaXMubWFzb25yeUhvcml6b250YWwucm93cztcbiAgICAgICAgICAgIGZvciAodGhpcy5tYXNvbnJ5SG9yaXpvbnRhbC5yb3dYcyA9IFtdOyB0LS07KSB0aGlzLm1hc29ucnlIb3Jpem9udGFsLnJvd1hzLnB1c2goMClcbiAgICAgICAgfSxcbiAgICAgICAgX21hc29ucnlIb3Jpem9udGFsTGF5b3V0OiBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICB2YXIgcyA9IHRoaXMsXG4gICAgICAgICAgICAgICAgZSA9IHMubWFzb25yeUhvcml6b250YWw7XG4gICAgICAgICAgICB0LmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgdmFyIHQgPSBpKHRoaXMpLFxuICAgICAgICAgICAgICAgICAgICBuID0gTWF0aC5jZWlsKHQub3V0ZXJIZWlnaHQoITApIC8gZS5yb3dIZWlnaHQpO1xuICAgICAgICAgICAgICAgIGlmIChuID0gTWF0aC5taW4obiwgZS5yb3dzKSwgMSA9PT0gbikgcy5fbWFzb25yeUhvcml6b250YWxQbGFjZUJyaWNrKHQsIGUucm93WHMpO1xuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB2YXIgbywgciwgYSA9IGUucm93cyArIDEgLSBuLFxuICAgICAgICAgICAgICAgICAgICAgICAgaCA9IFtdO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHIgPSAwOyBhID4gcjsgcisrKSBvID0gZS5yb3dYcy5zbGljZShyLCByICsgbiksIGhbcl0gPSBNYXRoLm1heC5hcHBseShNYXRoLCBvKTtcbiAgICAgICAgICAgICAgICAgICAgcy5fbWFzb25yeUhvcml6b250YWxQbGFjZUJyaWNrKHQsIGgpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgfSxcbiAgICAgICAgX21hc29ucnlIb3Jpem9udGFsUGxhY2VCcmljazogZnVuY3Rpb24odCwgaSkge1xuICAgICAgICAgICAgZm9yICh2YXIgcyA9IE1hdGgubWluLmFwcGx5KE1hdGgsIGkpLCBlID0gMCwgbiA9IDAsIG8gPSBpLmxlbmd0aDsgbyA+IG47IG4rKylcbiAgICAgICAgICAgICAgICBpZiAoaVtuXSA9PT0gcykge1xuICAgICAgICAgICAgICAgICAgICBlID0gbjtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgciA9IHMsXG4gICAgICAgICAgICAgICAgYSA9IHRoaXMubWFzb25yeUhvcml6b250YWwucm93SGVpZ2h0ICogZTtcbiAgICAgICAgICAgIHRoaXMuX3B1c2hQb3NpdGlvbih0LCByLCBhKTtcbiAgICAgICAgICAgIHZhciBoID0gcyArIHQub3V0ZXJXaWR0aCghMCksXG4gICAgICAgICAgICAgICAgbCA9IHRoaXMubWFzb25yeUhvcml6b250YWwucm93cyArIDEgLSBvO1xuICAgICAgICAgICAgZm9yIChuID0gMDsgbCA+IG47IG4rKykgdGhpcy5tYXNvbnJ5SG9yaXpvbnRhbC5yb3dYc1tlICsgbl0gPSBoXG4gICAgICAgIH0sXG4gICAgICAgIF9tYXNvbnJ5SG9yaXpvbnRhbEdldENvbnRhaW5lclNpemU6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgdmFyIHQgPSBNYXRoLm1heC5hcHBseShNYXRoLCB0aGlzLm1hc29ucnlIb3Jpem9udGFsLnJvd1hzKTtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgd2lkdGg6IHRcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgX21hc29ucnlIb3Jpem9udGFsUmVzaXplQ2hhbmdlZDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fY2hlY2tJZlNlZ21lbnRzQ2hhbmdlZCghMClcbiAgICAgICAgfSxcbiAgICAgICAgX2ZpdENvbHVtbnNSZXNldDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICB0aGlzLmZpdENvbHVtbnMgPSB7XG4gICAgICAgICAgICAgICAgeDogMCxcbiAgICAgICAgICAgICAgICB5OiAwLFxuICAgICAgICAgICAgICAgIHdpZHRoOiAwXG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIF9maXRDb2x1bW5zTGF5b3V0OiBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICB2YXIgcyA9IHRoaXMsXG4gICAgICAgICAgICAgICAgZSA9IHRoaXMuZWxlbWVudC5oZWlnaHQoKSxcbiAgICAgICAgICAgICAgICBuID0gdGhpcy5maXRDb2x1bW5zO1xuICAgICAgICAgICAgdC5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIHZhciB0ID0gaSh0aGlzKSxcbiAgICAgICAgICAgICAgICAgICAgbyA9IHQub3V0ZXJXaWR0aCghMCksXG4gICAgICAgICAgICAgICAgICAgIHIgPSB0Lm91dGVySGVpZ2h0KCEwKTtcbiAgICAgICAgICAgICAgICAwICE9PSBuLnkgJiYgciArIG4ueSA+IGUgJiYgKG4ueCA9IG4ud2lkdGgsIG4ueSA9IDApLCBzLl9wdXNoUG9zaXRpb24odCwgbi54LCBuLnkpLCBuLndpZHRoID0gTWF0aC5tYXgobi54ICsgbywgbi53aWR0aCksIG4ueSArPSByXG4gICAgICAgICAgICB9KVxuICAgICAgICB9LFxuICAgICAgICBfZml0Q29sdW1uc0dldENvbnRhaW5lclNpemU6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICB3aWR0aDogdGhpcy5maXRDb2x1bW5zLndpZHRoXG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIF9maXRDb2x1bW5zUmVzaXplQ2hhbmdlZDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gITBcbiAgICAgICAgfSxcbiAgICAgICAgX2NlbGxzQnlDb2x1bW5SZXNldDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICB0aGlzLmNlbGxzQnlDb2x1bW4gPSB7XG4gICAgICAgICAgICAgICAgaW5kZXg6IDBcbiAgICAgICAgICAgIH0sIHRoaXMuX2dldFNlZ21lbnRzKCksIHRoaXMuX2dldFNlZ21lbnRzKCEwKVxuICAgICAgICB9LFxuICAgICAgICBfY2VsbHNCeUNvbHVtbkxheW91dDogZnVuY3Rpb24odCkge1xuICAgICAgICAgICAgdmFyIHMgPSB0aGlzLFxuICAgICAgICAgICAgICAgIGUgPSB0aGlzLmNlbGxzQnlDb2x1bW47XG4gICAgICAgICAgICB0LmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgdmFyIHQgPSBpKHRoaXMpLFxuICAgICAgICAgICAgICAgICAgICBuID0gTWF0aC5mbG9vcihlLmluZGV4IC8gZS5yb3dzKSxcbiAgICAgICAgICAgICAgICAgICAgbyA9IGUuaW5kZXggJSBlLnJvd3MsXG4gICAgICAgICAgICAgICAgICAgIHIgPSAobiArIC41KSAqIGUuY29sdW1uV2lkdGggLSB0Lm91dGVyV2lkdGgoITApIC8gMixcbiAgICAgICAgICAgICAgICAgICAgYSA9IChvICsgLjUpICogZS5yb3dIZWlnaHQgLSB0Lm91dGVySGVpZ2h0KCEwKSAvIDI7XG4gICAgICAgICAgICAgICAgcy5fcHVzaFBvc2l0aW9uKHQsIHIsIGEpLCBlLmluZGV4KytcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIF9jZWxsc0J5Q29sdW1uR2V0Q29udGFpbmVyU2l6ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIHdpZHRoOiBNYXRoLmNlaWwodGhpcy4kZmlsdGVyZWRBdG9tcy5sZW5ndGggLyB0aGlzLmNlbGxzQnlDb2x1bW4ucm93cykgKiB0aGlzLmNlbGxzQnlDb2x1bW4uY29sdW1uV2lkdGhcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgX2NlbGxzQnlDb2x1bW5SZXNpemVDaGFuZ2VkOiBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9jaGVja0lmU2VnbWVudHNDaGFuZ2VkKCEwKVxuICAgICAgICB9LFxuICAgICAgICBfc3RyYWlnaHRBY3Jvc3NSZXNldDogZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICB0aGlzLnN0cmFpZ2h0QWNyb3NzID0ge1xuICAgICAgICAgICAgICAgIHg6IDBcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgX3N0cmFpZ2h0QWNyb3NzTGF5b3V0OiBmdW5jdGlvbih0KSB7XG4gICAgICAgICAgICB2YXIgcyA9IHRoaXM7XG4gICAgICAgICAgICB0LmVhY2goZnVuY3Rpb24odCkge1xuICAgICAgICAgICAgICAgIHZhciBlID0gaSh0aGlzKTtcbiAgICAgICAgICAgICAgICBzLl9wdXNoUG9zaXRpb24oZSwgcy5zdHJhaWdodEFjcm9zcy54LCAwKSwgcy5zdHJhaWdodEFjcm9zcy54ICs9IGUub3V0ZXJXaWR0aCghMClcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIF9zdHJhaWdodEFjcm9zc0dldENvbnRhaW5lclNpemU6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICB3aWR0aDogdGhpcy5zdHJhaWdodEFjcm9zcy54XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIF9zdHJhaWdodEFjcm9zc1Jlc2l6ZUNoYW5nZWQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgcmV0dXJuICEwXG4gICAgICAgIH1cbiAgICB9LCBpLmZuLmltYWdlc0xvYWRlZCA9IGZ1bmN0aW9uKHQpIHtcbiAgICAgICAgZnVuY3Rpb24gcygpIHtcbiAgICAgICAgICAgIHQuY2FsbChuLCBvKVxuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gZSh0KSB7XG4gICAgICAgICAgICB2YXIgbiA9IHQudGFyZ2V0O1xuICAgICAgICAgICAgbi5zcmMgIT09IGEgJiYgLTEgPT09IGkuaW5BcnJheShuLCBoKSAmJiAoaC5wdXNoKG4pLCAtLXIgPD0gMCAmJiAoc2V0VGltZW91dChzKSwgby51bmJpbmQoXCIuaW1hZ2VzTG9hZGVkXCIsIGUpKSlcbiAgICAgICAgfVxuICAgICAgICB2YXIgbiA9IHRoaXMsXG4gICAgICAgICAgICBvID0gbi5maW5kKFwiaW1nXCIpLmFkZChuLmZpbHRlcihcImltZ1wiKSksXG4gICAgICAgICAgICByID0gby5sZW5ndGgsXG4gICAgICAgICAgICBhID0gXCJkYXRhOmltYWdlL2dpZjtiYXNlNjQsUjBsR09EbGhBUUFCQUlBQUFBQUFBUC8vL3l3QUFBQUFBUUFCQUFBQ0FVd0FPdz09XCIsXG4gICAgICAgICAgICBoID0gW107XG4gICAgICAgIHJldHVybiByIHx8IHMoKSwgby5iaW5kKFwibG9hZC5pbWFnZXNMb2FkZWQgZXJyb3IuaW1hZ2VzTG9hZGVkXCIsIGUpLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICB2YXIgdCA9IHRoaXMuc3JjO1xuICAgICAgICAgICAgdGhpcy5zcmMgPSBhLCB0aGlzLnNyYyA9IHRcbiAgICAgICAgfSksIG5cbiAgICB9O1xuICAgIHZhciB6ID0gZnVuY3Rpb24oaSkge1xuICAgICAgICB0LmNvbnNvbGUgJiYgdC5jb25zb2xlLmVycm9yKGkpXG4gICAgfTtcbiAgICBpLmZuLmlzb3RvcGUgPSBmdW5jdGlvbih0LCBzKSB7XG4gICAgICAgIGlmIChcInN0cmluZ1wiID09IHR5cGVvZiB0KSB7XG4gICAgICAgICAgICB2YXIgZSA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cywgMSk7XG4gICAgICAgICAgICB0aGlzLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgdmFyIHMgPSBpLmRhdGEodGhpcywgXCJpc290b3BlXCIpO1xuICAgICAgICAgICAgICAgIHJldHVybiBzID8gaS5pc0Z1bmN0aW9uKHNbdF0pICYmIFwiX1wiICE9PSB0LmNoYXJBdCgwKSA/IHZvaWQgc1t0XS5hcHBseShzLCBlKSA6IHZvaWQgeihcIm5vIHN1Y2ggbWV0aG9kICdcIiArIHQgKyBcIicgZm9yIGlzb3RvcGUgaW5zdGFuY2VcIikgOiB2b2lkIHooXCJjYW5ub3QgY2FsbCBtZXRob2RzIG9uIGlzb3RvcGUgcHJpb3IgdG8gaW5pdGlhbGl6YXRpb247IGF0dGVtcHRlZCB0byBjYWxsIG1ldGhvZCAnXCIgKyB0ICsgXCInXCIpXG4gICAgICAgICAgICB9KVxuICAgICAgICB9IGVsc2UgdGhpcy5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgdmFyIGUgPSBpLmRhdGEodGhpcywgXCJpc290b3BlXCIpO1xuICAgICAgICAgICAgZSA/IChlLm9wdGlvbih0KSwgZS5faW5pdChzKSkgOiBpLmRhdGEodGhpcywgXCJpc290b3BlXCIsIG5ldyBpLklzb3RvcGUodCwgdGhpcywgcykpXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdGhpc1xuICAgIH1cbn0od2luZG93LCBqUXVlcnkpOyJdLCJmaWxlIjoiaXNvdG9wZS5qcyJ9
