/* slim custom */
var $=jQuery.noConflict();

(function ($, window, document, undefined) {
    "use strict";

    var pluginName = 'filmicMenu',
        oldWindowWidth = 0,
        defaults = {
            resizeWidth: '992',
            animSpeed: 'fast',
            easingEffect: 'linear'
        };

    function Plugin(element, options) {
        this.element = element;
        this.$elem = $(this.element);
        this.options = $.extend(defaults, options);
        this.init();
    }

    Plugin.prototype = {

        init: function () {
            var $window = $(window),
                options = this.options,
                $menu = this.$elem,
                $collapser = '<div class="menu-collapse-btn"><span></span></div>',
                $menuCollapser;

            $menu.before($collapser);
            $menuCollapser = $menu.prev('.menu-collapse-btn');

            $menu.on('click', '.has-submenu > a', function (e) {
                e.preventDefault();
                e.stopPropagation();

                var $li = $(this).closest('li');

                if ($(this).hasClass('expanded')) {
                    $(this).removeClass('expanded');
                    $li.find('>ul').slideUp(options.animSpeed, options.easingEffect);
                } else {
                    $(this).addClass('expanded');
                    $li.find('>ul').slideDown(options.animSpeed, options.easingEffect);
                }
            });

            $menuCollapser.on('click', function (e) {
                e.preventDefault();
                $menu.toggleClass('menu-opened');
                $menuCollapser.toggleClass('active-btn');
                $(document.body).toggleClass('has-menu-opened');
            });

            this.resizeMenu();
            $window.on('resize', this.resizeMenu.bind(this));
            $window.trigger('resize');
        },

        resizeMenu: function () {
            var self = this,
                $window = $(window),
                windowWidth = $window.width(),
                $options = this.options,
                $menu = $(this.element),
                $menuCollapser = $(document.body).find('.menu-collapse-btn');

            if (window['innerWidth'] !== undefined) {
                if (window['innerWidth'] > windowWidth) {
                    windowWidth = window['innerWidth'];
                }
            }

            if (windowWidth != oldWindowWidth) {
                oldWindowWidth = windowWidth;

                $menu.find('li').each(function () {
                    if ($(this).has('a+ul').length) {
                        /*add `has-submenu` class | add `menu-icon-arrow` class*/
                        $(this).addClass('has-submenu').find('>a').addClass('menu-icon-arrow');
                    }
                    $(this).children('a+ul').hide();
                });

                if ($options.resizeWidth >= windowWidth) {
                    $menu.addClass('collapsed').find('li').has('a+ul').off('mouseenter mouseleave');
                    /*hide menu content when `resize`*/
                    $menu.removeClass('menu-opened');
                    $menuCollapser.removeClass('active-btn');
                }else{
                    $menu.find('.sub-menu').removeProp('style');
                    $menu.removeClass('collapsed');
                }
            }
        }
    };

    $.fn[pluginName] = function (options) {
        return this.each(function () {
            if (!$.data(this, 'plugin_' + pluginName)) {
                $.data(this, 'plugin_' + pluginName,
                    new Plugin(this, options));
            }
        });
    };

}(jQuery, window, document));