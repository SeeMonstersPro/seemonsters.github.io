
(function ($) {
    'use strict';
  
    /**
     * @param $scope The widget wrapper element as a jQuery element
     * @param $ The jQuery alias
     */

    var WidgetFilmicTesti = function ($scope, $) {
        var show = $scope.find('.filmic-testimonial-list').attr('data-show') || 2,
        showtablet = $scope.find('.filmic-testimonial-list').attr('data-show-tablet') || show,
        showmobile = $scope.find('.filmic-testimonial-list').attr('data-show-mobile') || show,
        showdot = ($scope.find('.filmic-testimonial-list').attr('data-dots') == 'yes') ? true : false;
        $('.filmic-testimonial-list').not('.slick-initialized').slick({
            slidesToShow: show,
            slideToScroll: 1,
            autoplay: true,
            autoplaySpeed: 3000,
            infinite: true,
            dots:showdot,
            centerMode: false,
            arrows:false,
            responsive: [
                {
                breakpoint: 992,
                settings: {
                    slidesToShow: showtablet,
                    slidesToScroll: 1
                }
                },
                {
                breakpoint: 576,
                settings: {
                    slidesToShow: showmobile,
                    slidesToScroll: 1,
                    arrows: false
                }
                }
            ]
        });
    };
    $('.filmic-testimonial-list__left').click(function(){ 
		$('.filmic-testimonial-list').slick('slickPrev');
    } );
    $('.filmic-testimonial-list__right').click(function(){ 
		$('.filmic-testimonial-list').slick('slickNext');
    } );
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/filmic_testimonial.default', WidgetFilmicTesti);
    });
})(jQuery);