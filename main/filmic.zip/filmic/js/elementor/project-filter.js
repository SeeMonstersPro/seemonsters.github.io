'use strict';

//Isotope Nav Filter
function leadcon_portfolio_isotopenav() {

    var $container = jQuery('#gallery-isotope');
    jQuery('.category-isotope a').on('click', function() {
        jQuery('.category-isotope .active').removeClass('active');
        jQuery(this).addClass('active');

        var selector = jQuery(this).attr('data-filter');
            $container.isotope({
            filter: selector,
            animationOptions: {
                duration: 750,
                easing: 'linear',
                queue: false
            }
        });
        return false;
    });
}

//Isotope

function leadcon_portfolio_isotope() {

    var $container = jQuery('#gallery-isotope'),
        $colum = jQuery('.leadcon-portfolio-widget').attr('data-colum');

        console.log( $colum );
        $container.isotope( {
            filter: '*',
            animationOptions: {
                duration: 750,
                easing: 'linear',
                queue: false,
                layoutMode: 'masonry',
            }
        } );

    jQuery(window).smartresize(function() {
        $container.isotope({
            itemSelector: '.project-items',
            columnWidth: '.col-sm-3'
        });
    });
}

jQuery( document ).ready(function() {
    // For frontend.

    jQuery( window ).on( 'load', function() {
        leadcon_portfolio_isotopenav();
        leadcon_portfolio_isotope();
    } );

    if ( undefined !== window.elementorFrontend && undefined !== window.elementorFrontend.hooks ) {

        window.elementorFrontend.hooks.addAction( 'frontend/element_ready/global', function() {
            leadcon_portfolio_isotopenav();
            leadcon_portfolio_isotope();
        } );
    }
} );
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiIiwic291cmNlcyI6WyJlbGVtZW50b3IvaXNvdG9wLmpzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc3RyaWN0JztcblxuLy9Jc290b3BlIE5hdiBGaWx0ZXJcbmZ1bmN0aW9uIGxlYWRjb25fcG9ydGZvbGlvX2lzb3RvcGVuYXYoKSB7XG5cbiAgICB2YXIgJGNvbnRhaW5lciA9IGpRdWVyeSgnI2dhbGxlcnktaXNvdG9wZScpO1xuICAgIGpRdWVyeSgnLmNhdGVnb3J5LWlzb3RvcGUgYScpLm9uKCdjbGljaycsIGZ1bmN0aW9uKCkge1xuICAgICAgICBqUXVlcnkoJy5jYXRlZ29yeS1pc290b3BlIC5hY3RpdmUnKS5yZW1vdmVDbGFzcygnYWN0aXZlJyk7XG4gICAgICAgIGpRdWVyeSh0aGlzKS5hZGRDbGFzcygnYWN0aXZlJyk7XG5cbiAgICAgICAgdmFyIHNlbGVjdG9yID0galF1ZXJ5KHRoaXMpLmF0dHIoJ2RhdGEtZmlsdGVyJyk7XG4gICAgICAgICAgICAkY29udGFpbmVyLmlzb3RvcGUoe1xuICAgICAgICAgICAgZmlsdGVyOiBzZWxlY3RvcixcbiAgICAgICAgICAgIGFuaW1hdGlvbk9wdGlvbnM6IHtcbiAgICAgICAgICAgICAgICBkdXJhdGlvbjogNzUwLFxuICAgICAgICAgICAgICAgIGVhc2luZzogJ2xpbmVhcicsXG4gICAgICAgICAgICAgICAgcXVldWU6IGZhbHNlXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSk7XG59XG5cbi8vSXNvdG9wZVxuXG5mdW5jdGlvbiBsZWFkY29uX3BvcnRmb2xpb19pc290b3BlKCkge1xuXG4gICAgdmFyICRjb250YWluZXIgPSBqUXVlcnkoJyNnYWxsZXJ5LWlzb3RvcGUnKSxcbiAgICAgICAgJGNvbHVtID0galF1ZXJ5KCcubGVhZGNvbi1wb3J0Zm9saW8td2lkZ2V0JykuYXR0cignZGF0YS1jb2x1bScpO1xuXG4gICAgICAgIGNvbnNvbGUubG9nKCAkY29sdW0gKTtcbiAgICAgICAgJGNvbnRhaW5lci5pc290b3BlKCB7XG4gICAgICAgICAgICBmaWx0ZXI6ICcqJyxcbiAgICAgICAgICAgIGFuaW1hdGlvbk9wdGlvbnM6IHtcbiAgICAgICAgICAgICAgICBkdXJhdGlvbjogNzUwLFxuICAgICAgICAgICAgICAgIGVhc2luZzogJ2xpbmVhcicsXG4gICAgICAgICAgICAgICAgcXVldWU6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGxheW91dE1vZGU6ICdtYXNvbnJ5JyxcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSApO1xuXG4gICAgalF1ZXJ5KHdpbmRvdykuc21hcnRyZXNpemUoZnVuY3Rpb24oKSB7XG4gICAgICAgICRjb250YWluZXIuaXNvdG9wZSh7XG4gICAgICAgICAgICBpdGVtU2VsZWN0b3I6ICcuaXNvdG9wZS1pdGVtJyxcbiAgICAgICAgICAgIGNvbHVtbldpZHRoOiAnLmNvbC1zbS0zJ1xuICAgICAgICB9KTtcbiAgICB9KTtcbn1cblxualF1ZXJ5KCBkb2N1bWVudCApLnJlYWR5KGZ1bmN0aW9uKCkge1xuICAgIC8vIEZvciBmcm9udGVuZC5cblxuICAgIGpRdWVyeSggd2luZG93ICkub24oICdsb2FkJywgZnVuY3Rpb24oKSB7XG4gICAgICAgIGxlYWRjb25fcG9ydGZvbGlvX2lzb3RvcGVuYXYoKTtcbiAgICAgICAgbGVhZGNvbl9wb3J0Zm9saW9faXNvdG9wZSgpO1xuICAgIH0gKTtcblxuICAgIGlmICggdW5kZWZpbmVkICE9PSB3aW5kb3cuZWxlbWVudG9yRnJvbnRlbmQgJiYgdW5kZWZpbmVkICE9PSB3aW5kb3cuZWxlbWVudG9yRnJvbnRlbmQuaG9va3MgKSB7XG5cbiAgICAgICAgd2luZG93LmVsZW1lbnRvckZyb250ZW5kLmhvb2tzLmFkZEFjdGlvbiggJ2Zyb250ZW5kL2VsZW1lbnRfcmVhZHkvZ2xvYmFsJywgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBsZWFkY29uX3BvcnRmb2xpb19pc290b3BlbmF2KCk7XG4gICAgICAgICAgICBsZWFkY29uX3BvcnRmb2xpb19pc290b3BlKCk7XG4gICAgICAgIH0gKTtcbiAgICB9XG59ICk7Il0sImZpbGUiOiJlbGVtZW50b3IvaXNvdG9wLmpzIn0=
