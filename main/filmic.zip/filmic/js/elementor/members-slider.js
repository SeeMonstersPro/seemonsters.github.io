(function ($) {
  'use strict';

  /**
   * @param $scope The widget wrapper element as a jQuery element
   * @param $ The jQuery alias
   */

  var WidgetFilmicMemberSlider = function ($scope, $) {
    var show = $scope.find('.filmic-members-widget').attr('data-show') || 5,
    showtablet = $scope.find('.filmic-members-widget').attr('data-show-tablet') || show,
    showmobile = $scope.find('.filmic-members-widget').attr('data-show-mobile') || show;
    $(".member-slide-mode .row").slick({
        slidesToShow: show,
        slideToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
        infinite: true,
        centerMode: false,
        arrows:false,  
        responsive: [
          {
            breakpoint: 992,
            settings: {
              slidesToShow: showtablet,
              slidesToScroll: 1
            }
          },
          {
            breakpoint: 576,
            settings: {
              slidesToShow: showmobile,
              slidesToScroll: 1,
              arrows: false
            }
          }
        ]
    });
  };
  
  $(window).on('elementor/frontend/init', function () {
      elementorFrontend.hooks.addAction('frontend/element_ready/filmic_member.default', WidgetFilmicMemberSlider);
  });
})(jQuery);