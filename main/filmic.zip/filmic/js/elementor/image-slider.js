(function($) {
  "use strict";
  $(window).on("load", function() {
    $(".image-slider-js").slick({
      slidesToShow: 2,
      slideToScroll: 1,
      autoplay: true,
      autoplaySpeed: 3000,
      infinite: false,
      responsive: [
        {
          breakpoint: 992,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1
          }
        },

        {
          breakpoint: 576,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false
          }
        }
      ]
    });
  });
})(jQuery);