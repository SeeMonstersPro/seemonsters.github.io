(function ($) {
    'use strict';
  
    /**
     * @param $scope The widget wrapper element as a jQuery element
     * @param $ The jQuery alias
     */

    var WidgetFilmicContentGallery = function ($scope, $) {

        const breakpoint = window.matchMedia( '(max-width:767px)' );
        let contentswiper;
        const breakpointChecker = function() {
            if ( breakpoint.matches === true ) {
                if ( contentswiper !== undefined ) contentswiper.destroy( true, true );
                return;
            } else if ( breakpoint.matches === false ) {
                return enableSwiper();
            }
        };
        const enableSwiper = function() {
            contentswiper = new Swiper(
                '.filmic-slider-section .swiper-container', 
                {
                    direction: 'vertical',
                    slidesPerView: 1,
                    mousewheel: true,
                    speed: 600,
                    pagination: {
                    el: '.content-slider-pagination',
                    clickable: true,
                    },
                    keyboard: {
                        enabled: true,
                        onlyInViewport: false,
                    },
                }
            ); 
        };
        breakpoint.addListener(breakpointChecker);
        breakpointChecker();
    };
    $(window).on('elementor/frontend/init', function () {
        elementorFrontend.hooks.addAction('frontend/element_ready/filmic_content_slider.default', WidgetFilmicContentGallery);
    });
})(jQuery);