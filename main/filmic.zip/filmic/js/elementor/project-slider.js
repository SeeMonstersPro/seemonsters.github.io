(function ($) {
	'use strict';
	/**
	 * @param $scope The widget wrapper element as a jQuery element
	 * @param $ The jQuery alias
	 */
	var WidgetProjectSlider = function ($scope, $) {
		$('.js-project-slider').slick( {
			arrows: true,
			slidesToShow: 1,
			slidesToScroll: 1,
			infinite: false,
		});
	};

	$(window).on('elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction('frontend/element_ready/filmic-project-slider.default', WidgetProjectSlider);
	});
})(jQuery);