(function ($) {
	'use strict';
	/**
	 * @param $scope The widget wrapper element as a jQuery element
	 * @param $ The jQuery alias
	 */
	var WidgetStudioWidget = function ($scope, $) {
		var showDesktop = $scope.find('.filmic-studio-widgets').attr('data-columns_desk');
        var swiper = new Swiper('.filmic-studio-layout-1', {
      		slidesPerView: showDesktop,
      		spaceBetween: 30,
      		watchSlidesVisibility: true,
	        scrollbar: {
	            el: '.swiper-scrollbar',
	            draggable: true
	        },
	        breakpoints: {
	            767: {
	                slidesPerView: 1
	            },
	            991: {
	                slidesPerView: 2
	            }
	        }
    	});
	};

	$(window).on('elementor/frontend/init', function () {
		elementorFrontend.hooks.addAction('frontend/element_ready/filmic-studio-widgets.default', WidgetStudioWidget);
	});
})(jQuery);