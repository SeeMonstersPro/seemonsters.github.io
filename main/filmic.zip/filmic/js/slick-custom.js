(function($) {
  "use-strict";

  $(window).on("load", function() {
    $(".sc-carousel").slick({
      slidesToShow: 5,
      slideToScroll: 1,
      autoplay: true,
      autoplaySpeed: 3000,
      infinite: false,
      responsive: [
        {
          breakpoint: 992,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1
          }
        },

        {
          breakpoint: 576,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            arrows: false
          }
        }
      ]
    });

    $(".sc-testimonial-style-1").slick({
      dots: false,
      infinite: true,
      arrows: false,
      fade: true,
      speed: 500,
      cssEase: "linear",
      autoplay: true,
      autoplaySpeed: 8000
    });

    $(".sc-testimonial-style-3").slick({
      dots: false,
      infinite: false,
      arrows: true,
      fade: true,
      speed: 500,
      cssEase: "linear",
      autoplay: true,
      autoplaySpeed: 8000
    });

    $(".sc-testimonial-style-2").slick({
      slidesToShow: 2,
      slidesToScroll: 1,
      dots: false,
      infinite: false,
      arrows: false,
      autoplay: true,
      autoplaySpeed: 2000,
      responsive: [
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false
          }
        }
      ]
    });

    $(".sc-testimonial-style-4").slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      dots: true,
      infinite: true,
      arrows: false,
      autoplay: true,
      autoplaySpeed: 8000,
      customPaging: function(slider, i) {
        var thumb = $(slider.$slides[i]).data();
        return '<span class="slick-dots__icon"></span>';
      }
    });
  });
})(jQuery);
