(function ($) {
  "use strict";
  var HT = {},
    body = $(document.body);

  /*mobile menu*/
    HT.mobileMenu = function () {
        if( window.matchMedia( '( max-width: 991px )' ).matches ){
            $( ".main-navigation" ).filmicMenu({
                resizeWidth: "991",
                initiallyVisible: false,
                animSpeed: "fast",
                easingEffect: "linear"
            });
        }
    };

  // Menu for header layout 3
  HT.toggleMenu = function () {
    $(".js-menu-link").on("click", function (event) {
      event.preventDefault();

      $(".menu-overlay").toggleClass("open");
      $(".toggle-menu").toggleClass("open");
      $("html").toggleClass("hide-scrollbar");
    });

    $(".menu-overlay a:not(:only-child)").on("click", function (event) {
      event.preventDefault();
      $(this)
        .next()
        .slideToggle(350);

      $(this).toggleClass("is-active");
    });
  };

  // Counter Up
  HT.counterUp = function () {
    if ($('.sc-counter__number').length > 0) {
      $('.sc-counter__number').counterUp({
        delay: 10,
        time: 2000
      });
    }
  }

  /*desktop search form*/
  HT.desktop_search_form = function () {
    /*search form button*/
    var _search_box = body.find(".theme-search-box"),
      _textfiled = _search_box.find("input"),
      /*action when quickview close*/
      search_closed_action = function () {
        body.removeClass("desktop-search-form-opened");
        _textfiled.val("");
      };

    $("#theme-search-btn").on("click", function () {
      body.addClass("desktop-search-form-opened");
      setTimeout(function () {
        _textfiled.focus();
      }, 300);
    });

    /*Close box by click overlay*/
    _search_box.on("click", function (e) {
      if (e.target !== this) return;
      search_closed_action();
    });

    /*Close box by click `ESC` or `ENTER` key*/
    $(document).keyup(function (e) {
      if (e.keyCode === 27 || e.keyCode === 13) search_closed_action();
    });
  };

  /*scroll to top onclick*/
  $(".scroll-to-top").on("click", function () {
    $("html, body").animate({ scrollTop: 0 }, 300);
  });

  /* READY =====================================================*/
  $(document).ready(function () {
    HT.mobileMenu();
    HT.desktop_search_form();
    HT.toggleMenu();
    HT.counterUp();
  });

  /* LOAD ======================================================*/
  $(window).on("load", function () { });

  /* SCROLL =====================================================*/
  $(window).on("scroll", function () {
    /*scroll to top action*/
    if ($(this).scrollTop() > 100) {
      $(".scroll-to-top").addClass("scroll-visible");
    } else {
      $(".scroll-to-top").removeClass("scroll-visible");
    }
  });

  /* FULLPAGE =====================================================*/
  $("#fullpage").fullpage({
    sectionSelector: ".vertical-scrolling",
    slideSelector: ".horizontal-scrolling",
    navigation: true,
    controlArrows: false,
    slidesNavigation: true,
    responsiveWidth: 768
  });

  /* CUSTOM SELECT ELEMENT =====================================================*/
  $(".contact-form-select").dropkick({
    mobile: true
  });

  /* STICKY MENU =====================================================*/
  var sticky = jQuery( '.header-sticky' );
  if ( sticky ) {
    var position = sticky.offset();
    if ( position ) {
      var height = position.top
    }
      
    jQuery(window).scroll(function() {

        var navTop = jQuery(window).scrollTop();
        if ( navTop > height ) {

          jQuery( sticky ).addClass('sticky-menu');
        }else{

          jQuery( sticky ).removeClass( 'sticky-menu' );

        }
      
    });
  }
})(jQuery);
