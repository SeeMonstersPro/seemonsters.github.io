<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'bg' => array(
		'label' => esc_html__('Background image', 'filmic'),
		'desc' => esc_html__('Choose image', 'filmic'),
		'type' => 'upload',
	),
);