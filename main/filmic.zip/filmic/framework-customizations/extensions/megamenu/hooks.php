<?php if (!defined('FW')) die('Forbidden');

// replace default walker
{
    remove_filter('wp_nav_menu_args', '_filter_fw_ext_mega_menu_wp_nav_menu_args');

    /** @internal */
    function filmic_filter_theme_ext_mega_menu_wp_nav_menu_args($args) {
        $args['walker'] = new Filmic_Mega_Menu_Custom_Walker();

        return $args;
    }
    add_filter('wp_nav_menu_args', 'filmic_filter_theme_ext_mega_menu_wp_nav_menu_args');
}