<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' );}

$options = array(
    'testi_option' => array(
        'title'   => esc_html__('Tesimonials Options', 'filmic'),
        'type'    => 'box',
        'options' => array(
            'name' => array(
                'type' => 'text',
                'title' => esc_html__( 'Name', 'filmic' ),
                'desc' => esc_html__( 'Enter the testimonial name', 'filmic' ),
                'value' => ''
            ),  
            'position' => array(
                'type' => 'text',
                'title' => esc_html__( 'Position', 'filmic' ),
                'desc' => esc_html__( 'Enter the testimonial position', 'filmic' ),
                'value' => ''
            )
        )
    )
);