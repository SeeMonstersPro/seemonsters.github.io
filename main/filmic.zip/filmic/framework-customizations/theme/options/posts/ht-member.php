<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' );}

$options = array(
    'member_infomation' => array(
        'title'   => esc_html__('Member Infomation', 'filmic'),
        'type'    => 'box',
        'options' => array(  
            'position' => array(
                'type' => 'text',
                'title' => esc_html__( 'Position', 'filmic' ),
                'desc' => esc_html__( 'Enter the Member position', 'filmic' ),
                'value' => 'Director'
            ),
            'facebook' => array(
                'type' => 'text',
                'title' => esc_html__( 'Facebook', 'filmic' ),
                'desc' => esc_html__( 'Enter the Member address', 'filmic' ),
                'value' => '#'
            ),  
            'twitter' => array(
                'type' => 'text',
                'title' => esc_html__( 'Twitter', 'filmic' ),
                'desc' => esc_html__( 'Enter the Twitter address', 'filmic' ),
                'value' => '#'
            ),
            'instagram' => array(
                'type' => 'text',
                'title' => esc_html__( 'Instagram', 'filmic' ),
                'desc' => esc_html__( 'Enter the Instagram address', 'filmic' ),
                'value' => '#'
            ),
        )
    )
);
