<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' );}

$project_options = array(
    /*GENERAL*/
    'general' => array(
        'title'   => esc_html__( 'General', 'filmic' ),
        'type'    => 'tab',
        'options' => array(
            /*trailer*/
            'trailer' => array(
                'label'   => esc_html__( 'Trailer', 'filmic' ),
                'desc' => esc_html__( 'Enter a URL in your trailer', 'filmic' ),
                'type' => 'text',
                'value' => '#'
            ),

            /*description*/
            'description' => array(
                'label'   => esc_html__( 'Description', 'filmic' ),
                'desc' => esc_html__( 'Enter the description for the project', 'filmic' ),
                'type' => 'textarea',
                'value' => ''
            ),
        )
    ),

    /*PAGE HEADER*/
    'page_breadcrumbs' => array(
        'title' => esc_html__('Page Header', 'filmic'),
        'type' => 'tab',
        'options' => array(
            'p_bread' => array(
                'label'   => false,
                'desc'   => false,
                'type'    => 'multi-picker',
                'picker' => array(
                    'gadget' => array(
                        'label' => esc_html__('Layout', 'filmic'),
                        'type' => 'short-select',
                        'choices' => array(
                            'default' => esc_html__('Default', 'filmic'),
                            'custom' => esc_html__('Custom', 'filmic'),
                            'disable' => esc_html__('Disable', 'filmic'),
                        ),
                        'value' => 'default',
                    ),
                ),
                'choices' => array(
                    'custom' => array(
                        'p_bread_align' => array(
                            'label' => esc_html__('Text align', 'filmic'),
                            'type' => 'short-select',
                            'choices' => array(
                                'left' => esc_html__( 'Left', 'filmic' ),
                                'center' => esc_html__( 'Center', 'filmic' ),
                                'right' => esc_html__( 'Right', 'filmic' ),
                            ),
                            'value' => 'center'
                        ),
                        'p_bread_title' => array(
                            'label' => esc_html__('Alternative title', 'filmic'),
                            'desc' => esc_html__('This will replace heading page title', 'filmic'),
                            'type' => 'text',
                            'value' => ''
                        ),
                        'p_bread_bg' => array(
                            'label' => false,
                            'desc' => false,
                            'type' => 'multi-picker',
                            'picker' => array(
                                'gadget' => array(
                                    'label' => esc_html__('Background', 'filmic'),
                                    'desc' => esc_html__('If select background image option, the theme recommends a header size of at least 1170 width pixels', 'filmic'),
                                    'type' => 'short-select',
                                    'choices' => array(
                                        'img_bg' => esc_html__('Use image', 'filmic'),
                                        'color_bg' => esc_html__('Use solid color', 'filmic'),
                                    ),
                                    'value' => 'color_bg'
                                )
                            ),
                            'choices' => array(
                                'img_bg' => array(
                                    'img_bg_data' => array(
                                        'label' => esc_html__('Image upload', 'filmic'),
                                        'type' => 'upload'
                                    )
                                ),
                                'color_bg' => array(
                                    'color_bg_data' => array(
                                        'label' => esc_html__('Choose color', 'filmic'),
                                        'type' => 'color-picker',
                                        'value' => '#e9eceb'
                                    )
                                )
                            ),
                        )
                    ),
                ),
            ),
        )
    ),

    /*INFOMATION*/
    'info' => array(
        'title'   => esc_html__( 'Infomation', 'filmic' ),
        'type'    => 'tab',
        'options' => array(
            /*button link*/
            'btn_link' => array(
                'label'   => esc_html__( 'Buy button link', 'filmic' ),
                'help'  => esc_html__( 'Add this option for shortcode Project with Carousel style', 'filmic' ),
                'type' => 'text',
                'value' => '#'
            ),

            /*button label*/
            'btn_label' => array(
                'label'   => esc_html__( 'Buy button label', 'filmic' ),
                'help'  => esc_html__( 'Add this option for shortcode Project with Carousel style', 'filmic' ),
                'type' => 'text',
                'value' => esc_html__( 'Buy on Amazon', 'filmic' )
            ),

            /*infomation*/
            'infomation' => array(
                'type'  => 'addable-box',
                'value' => array(
                    array(
                        'pro_name' => 'Director:',
                        'pro_value' => 'Anthony Brown',
                    ),
                    array(
                        'pro_name' => 'Year:',
                        'pro_value' => '2016',
                    ),
                    array(
                        'pro_name' => 'Genre:',
                        'pro_value' => 'Romance',
                    ),
                ),
                'label' => esc_html__( 'Infomation', 'filmic' ),
                'help'  => esc_html__( 'Add this option for shortcode Project with Carousel style', 'filmic' ),
                'box-options' => array(
                    'pro_name' => array(
                        'label' => esc_html__( 'Name', 'filmic' ),
                        'type' => 'text'
                    ),
                    'pro_value' => array(
                        'label' => esc_html__( 'Value', 'filmic' ),
                        'type' => 'text'
                    ),
                ),
                'template' => '{{- pro_name }} {{- pro_value }}',
                'add-button-text' => esc_html__( 'Add', 'filmic' ),
                'sortable' => true,
            )
        )
    ),
);


$options = array(
    'project_layout_box' => array(
        'title'   => esc_html__( 'Project Customizing', 'filmic'),
        'type'    => 'box',
        'options' => $project_options
    ),
);