<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' );}

$studio_options = array(
    /*PAGE HEADER*/
    'page_breadcrumbs' => array(
        'title' => esc_html__('Page Header', 'filmic'),
        'type' => 'tab',
        'options' => array(
            'p_bread' => array(
                'label'   => false,
                'desc'   => false,
                'type'    => 'multi-picker',
                'picker' => array(
                    'gadget' => array(
                        'label' => esc_html__('Layout', 'filmic'),
                        'type' => 'short-select',
                        'choices' => array(
                            'default' => esc_html__('Default', 'filmic'),
                            'custom' => esc_html__('Custom', 'filmic'),
                            'disable' => esc_html__('Disable', 'filmic'),
                        ),
                        'value' => 'default',
                    ),
                ),
                'choices' => array(
                    'custom' => array(
                        'p_bread_align' => array(
                            'label' => esc_html__('Text align', 'filmic'),
                            'type' => 'short-select',
                            'choices' => array(
                                'left' => esc_html__( 'Left', 'filmic' ),
                                'center' => esc_html__( 'Center', 'filmic' ),
                                'right' => esc_html__( 'Right', 'filmic' ),
                            ),
                            'value' => 'center'
                        ),
                        'p_bread_title' => array(
                            'label' => esc_html__('Alternative title', 'filmic'),
                            'desc' => esc_html__('This will replace heading page title', 'filmic'),
                            'type' => 'text',
                            'value' => ''
                        ),
                        'p_bread_bg' => array(
                            'label' => false,
                            'desc' => false,
                            'type' => 'multi-picker',
                            'picker' => array(
                                'gadget' => array(
                                    'label' => esc_html__('Background', 'filmic'),
                                    'desc' => esc_html__('If select background image option, the theme recommends a header size of at least 1170 width pixels', 'filmic'),
                                    'type' => 'short-select',
                                    'choices' => array(
                                        'img_bg' => esc_html__('Use image', 'filmic'),
                                        'color_bg' => esc_html__('Use solid color', 'filmic'),
                                    ),
                                    'value' => 'color_bg'
                                )
                            ),
                            'choices' => array(
                                'img_bg' => array(
                                    'img_bg_data' => array(
                                        'label' => esc_html__('Image upload', 'filmic'),
                                        'type' => 'upload'
                                    )
                                ),
                                'color_bg' => array(
                                    'color_bg_data' => array(
                                        'label' => esc_html__('Choose color', 'filmic'),
                                        'type' => 'color-picker',
                                        'value' => '#e9eceb'
                                    )
                                )
                            ),
                        )
                    ),
                ),
            ),
        )
    ),
);


$options = array(
    'studio_layout_box' => array(
        'title'   => esc_html__( 'Studio Customizing', 'filmic'),
        'type'    => 'box',
        'options' => $studio_options
    ),
);