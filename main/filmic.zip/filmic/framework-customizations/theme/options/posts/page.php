<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' );}

/*get revolution slider*/
global $wpdb;
$tablename = $wpdb->prefix."revslider_sliders";
$id = 'id';
$sql = $wpdb->prepare("SELECT id, title, alias FROM $tablename  ORDER BY %s ASC LIMIT 999", $id);
$rs = $wpdb->get_results(
    $sql
);
$revsliders = array();

if ( $rs ) {
    foreach ( $rs as $slider ) {
        $revsliders[$slider->alias] = $slider->title;
    }
} else {
    $revsliders['0'] = esc_html__('No sliders found', 'filmic');
}


/*PAGE OPTIONS*/
$page_options = array(
    /*HEADER*/
    'page_header' => array(
        'title'   => esc_html__('Header', 'filmic'),
        'type'    => 'tab',
        'options' => array(
            'page_header_layout' => array(
                'label' => false,
                'desc' => false,
                'type' => 'multi-picker',
                'picker' => array(
                    'gadget' => array(
                        'label' => esc_html__('Layout', 'filmic'),
                        'type' => 'short-select',
                        'choices' => array(
                            'default' => esc_html__('Default', 'filmic'),
                            'layout-1' => esc_html__('Layout 1', 'filmic'),
                            'layout-2' => esc_html__('Layout 2', 'filmic'),
                            'layout-3' => esc_html__('Layout 3', 'filmic'),
                        ),
                        'value' => 'default',
                    )
                ),
                'choices' => array(
                    'layout-1' => array(
                        'rev_slider' => array(
                            'label' => false,
                            'desc' => false,
                            'type' => 'multi-picker',
                            'picker' => array(
                                'gadget' => array(
                                    'type' => 'switch',
                                    'label' => esc_html__('Slider Revolution', 'filmic'),
                                    'left-choice' => array(
                                        'label' => esc_html__('No', 'filmic'),
                                        'value' => 'no'
                                    ),
                                    'right-choice' => array(
                                        'label' => esc_html__('Yes', 'filmic'),
                                        'value' => 'yes'
                                    ),
                                    'value' => 'no'
                                )
                            ),
                            'choices' => array(
                                'yes' => array(
                                    'slider' => array(
                                        'label' => esc_html__('Pick slider', 'filmic'),
                                        'type' => 'short-select',
                                        'choices' => $revsliders
                                    )
                                )
                            )
                        ),
                        'menu_bg' => array(
                            'label' => esc_html__( 'Menu background color', 'filmic' ),
                            'type' => 'rgba-color-picker',
                            'value' => '#ffffff'
                        )
                    )
                ),
            ),
        ),
    ),

    /*LOGO*/
    'page_logo' => array(
        'title' => esc_html__('Logo', 'filmic'),
        'type' => 'tab',
        'options' => array(
            'p_lg' => array(
                'label' => false,
                'desc' => false,
                'type' => 'multi-picker',
                'picker' => array(
                    'gadget' => array(
                        'type' => 'short-select',
                        'label' => esc_html__('Logo', 'filmic'),
                        'desc' => false,
                        'choices' => array(
                            'default' => esc_html__('Default', 'filmic'),
                            'custom' => esc_html__('Custom', 'filmic'),
                        ),
                        'value' => 'default'
                    )
                ),
                'choices' => array(
                    'custom' => array(
                        'lg_data' => array(
                            'label' => esc_html__('Choose image', 'filmic'),
                            'type' => 'upload',
                            'images_only' => true
                        )
                    )
                ),
            ),
        )
    ),

    /*PAGE HEADER*/
    'page_breadcrumbs' => array(
        'title' => esc_html__('Page Header', 'filmic'),
        'type' => 'tab',
        'options' => array(
            'p_bread' => array(
                'label'   => false,
                'desc'   => false,
                'type'    => 'multi-picker',
                'picker' => array(
                    'gadget' => array(
                        'label' => esc_html__('Layout', 'filmic'),
                        'type' => 'short-select',
                        'choices' => array(
                            'default' => esc_html__('Default', 'filmic'),
                            'custom' => esc_html__('Custom', 'filmic'),
                            'disable' => esc_html__('Disable', 'filmic'),
                        ),
                        'value' => 'default',
                    ),
                ),
                'choices' => array(
                    'custom' => array(
                        'p_bread_align' => array(
                            'label' => esc_html__('Text align', 'filmic'),
                            'type' => 'short-select',
                            'choices' => array(
                                'left' => esc_html__( 'Left', 'filmic' ),
                                'center' => esc_html__( 'Center', 'filmic' ),
                                'right' => esc_html__( 'Right', 'filmic' ),
                            ),
                            'value' => 'center'
                        ),
                        'p_bread_title' => array(
                            'label' => esc_html__('Alternative title', 'filmic'),
                            'desc' => esc_html__('This will replace heading page title', 'filmic'),
                            'type' => 'text',
                            'value' => ''
                        ),
                        'p_bread_bg' => array(
                            'label' => false,
                            'desc' => false,
                            'type' => 'multi-picker',
                            'picker' => array(
                                'gadget' => array(
                                    'label' => esc_html__('Background', 'filmic'),
                                    'desc' => esc_html__('If select background image option, the theme recommends a header size of at least 1170 width pixels', 'filmic'),
                                    'type' => 'short-select',
                                    'choices' => array(
                                        'img_bg' => esc_html__('Use image', 'filmic'),
                                        'color_bg' => esc_html__('Use solid color', 'filmic'),
                                    ),
                                    'value' => 'color_bg'
                                )
                            ),
                            'choices' => array(
                                'img_bg' => array(
                                    'img_bg_data' => array(
                                        'label' => esc_html__('Image upload', 'filmic'),
                                        'type' => 'upload'
                                    )
                                ),
                                'color_bg' => array(
                                    'color_bg_data' => array(
                                        'label' => esc_html__('Choose color', 'filmic'),
                                        'type' => 'color-picker',
                                        'value' => '#e9eceb'
                                    )
                                )
                            ),
                        )
                    ),
                ),
            ),
        )
    ),

    /*FOOTER*/
    'page_footer' => array(
        'title' => esc_html__('Footer', 'filmic'),
        'type' => 'tab',
        'options' => array(
            'p_footer' => array(
                'label' => false,
                'desc' => false,
                'type' => 'multi-picker',
                'picker' => array(
                    'gadget' => array(
                        'type' => 'short-select',
                        'label' => esc_html__('Layout', 'filmic'),
                        'desc' => false,
                        'choices' => array(
                            'default' => esc_html__('Default', 'filmic'),
                            'custom' => esc_html__('Custom', 'filmic'),
                            'disable' => esc_html__('Disabled', 'filmic'),
                        ),
                        'value' => 'default'
                    )
                ),
                'choices' => array(
                    'custom' => array(
                        'widget_bg' => array(
                            'label' => esc_html__('Widget background', 'filmic'),
                            'type' => 'color-picker',
                            'value' => '#292929'
                        ),
                        'coppy_bg' => array(
                            'label' => esc_html__('Coppyright background', 'filmic'),
                            'type' => 'color-picker',
                            'value' => '#1b1919'
                        )
                    )
                ),
            ),
        )
    ),
);

$options = array(
    'page_layout_box' => array(
        'title'   => esc_html__( 'Page Customizing', 'filmic'),
        'type'    => 'box',
        'options' => $page_options
    ),
);
