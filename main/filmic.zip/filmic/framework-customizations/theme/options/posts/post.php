<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' ); }

$post_options = array(
    'pf-gallery' => array(
        'type' => 'tab',
        'title' => esc_html__( 'Gallery', 'filmic' ),
        'options' => array(
            'gallery' => array(
                'type' => 'multi-upload',
                'label' => false,
                'desc' => esc_html__( 'Gallery Images', 'filmic' )
            )
        )
    ),
    'pf-audio' => array(
        'type' => 'tab',
        'title' => esc_html__( 'Audio', 'filmic' ),
        'priority' => 'default',
        'options' => array(
            'audio' => array(
                'type' => 'textarea',
                'label' => false,
                'desc' => esc_html__( 'Paste the embed code from SoundCloud here.', 'filmic' )
            )
        )
    ),
    'pf-quote' => array(
        'type' => 'tab',
        'title' => esc_html__( 'Quote', 'filmic' ),
        'options' => array(
            'quote' => array(
                'type' => 'textarea',
                'label' => false,
                'desc' => esc_html__( 'You can use tags: del, span, strong', 'filmic' ),
            ),
        )
    ),
    'pf-video' => array(
        'type' => 'tab',
        'title' => esc_html__( 'Video', 'filmic' ),
        'options' => array(
            'video' => array(
                'type' => 'text',
                'label' => false,
                'desc' => esc_html__( 'Video ID here', 'filmic' ),
            ),
        )
    ),
);


$options = array(
    'post_layout_box' => array(
        'title'   => esc_html__( 'Post Customizing', 'filmic'),
        'type'    => 'box',
        'options' => $post_options
    ),
);