<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['id'] = 'filmic';

$manifest['supported_extensions'] = array(
	'breadcrumbs' => array(),
	'backups' => array(),
    'sidebars' => array(),
    'testimonial' => array(),
    'project' => array(),
    'studio' => array(),
    'member' => array(),
);
